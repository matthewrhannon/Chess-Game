/* Matthew Hannon 2217853 skinnym2@ku.edu */

//Piece3D class
#include "Board3D.h"
#include "ShaderIF.h"

//Initalize static variables
GLuint cBoard3D::shaderProgram = 0;
GLint cBoard3D::aLoc_vColor = -1;
GLint cBoard3D::aLoc_vPosition = -1;
GLint cBoard3D::uLoc_scaleTrans = -1;

GLint cBoard3D::uLoc_modelViewMatrix = -1;
GLint cBoard3D::uLoc_projectionMatrix = -1;
GLint cBoard3D::uLoc_normalMatrix = -1;

//Lighting stuff
GLint cBoard3D::uLoc_actualNumLights = -1;

GLint cBoard3D::uLoc_ecLightPosition = -1;
GLint cBoard3D::uLoc_lightStrength = -1;
GLint cBoard3D::uLoc_globalAmbient = -1;

GLint cBoard3D::uLoc_spotDir = -1;
GLint cBoard3D::uLoc_spotParams = -1;

GLint cBoard3D::uLoc_kakdks = -1;
GLint cBoard3D::uLoc_shininess = -1;

//Positon, texels, normals
GLint cBoard3D::aLoc_mcPosition = -1;
GLint cBoard3D::aLoc_mcNormal = -1;
GLint cBoard3D::aLoc_mctexCoords = -1;

//Chess stuff
GLint cBoard3D::uLoc_haveTextureMap = -1; 
GLint cBoard3D::uLoc_textureMap = -1;

GLint cBoard3D::uLoc_teamColor = -1;

//*******************************//

cBoard3D::cBoard3D(const vec3 origin, int _iColor, ObjModel *_Model, int _Start, int _End, char *_strPieceName)
{
	if (cBoard3D::shaderProgram == 0)
		cBoard3D::shaderProgram = ShaderIF::initShader("Board3D.vsh", "Board3D.fsh");

	nextVAOIndex = 0;
	nextFFBufferIndex = 0;

	// Now do instance-specific initialization:
	PieceOrigin[0] = origin[0]; PieceOrigin[1] = origin[1]; PieceOrigin[2] = origin[2];
		
	//Initalize variables that will reprsent the bounding box for this piece
	xmin = -20;
	xmax = 20;
	ymin = -5;
	ymax = 5;
	zmin = -20;
	zmax = 20;

	//Set the color for each block
	iColor = _iColor;
	iNumVertices = 0;
	PieceIndex = 0;

	//Set invalid value so board is skipped in search
	GridX = GridY = -1;

	//Store triangle offset information
	Start = _Start;
	End = _End;
	Model = _Model;

	//Calculate number of triangles that make up object
	Delta = (End - Start)-1;

	if(Delta < 0)
		return;

	//Set piece name
	strcpy(strPieceName, _strPieceName);

	//Texture
	//strcpy(strTexturePath, "Models\\blackmarble.bmp");
	strcpy(strTexturePath, "Models\\jade.bmp");

	doInitialize();
}

cBoard3D::~cBoard3D()
{
	if(kakdks)
	{
		delete []kakdks;
		kakdks = NULL;
	}

	glDeleteVertexArrays(1, vao);
	glDeleteBuffers(3, DataBuffers);
}

void cBoard3D::definePieceGeometry()
{
	//Create vertex array and assosicative buffers
	glGenVertexArrays(1, &vao[0]);
	glGenBuffers(3, DataBuffers);

	//Need to create triangles now out of this data, so define the variables that will hold them, and then traverse the ObjModel structure
	//	to fill the indicies for the triangles/faces.
	vec3 *Indexed_Vertices = new vec3[Delta*3]; //Times 3 because each face represents a triangle so need 3x number vertices to represent
	vec3 *Indexed_Normals = new vec3[Delta*3];
	vec2 *Indexed_UV = new vec2[Delta*3];

	//Now lets fill the array with triangles that will componse the object being created
	int iCounter = 0;

	if(Model == NULL)
		return;

	//Print to file
	FILE *fOutputfile = fopen("KingIndices.txt", "w");

	if(!fOutputfile)
	{
		cout << "Error Opening file! Filename: " << "KingIndices.txt" << "\n";
		return;
	}
		
	for(int x = 0; x < Delta*3; x++)
	{
		//Vertices to triangles
		Indexed_Vertices[x][0] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[0]-1].x;
		Indexed_Vertices[x][1] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[0]-1].y;
		Indexed_Vertices[x][2] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[0]-1].z;

		Indexed_Normals[x][0] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[0]-1].x;
		Indexed_Normals[x][1] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[0]-1].y;
		Indexed_Normals[x][2] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[0]-1].z;

		Indexed_UV[x][0] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[0]-1].u;
		Indexed_UV[x][1] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[0]-1].v;

		fprintf(fOutputfile, "%f %f %f\n", Indexed_Vertices[x][0], Indexed_Vertices[x][1], Indexed_Vertices[x][2]);
		fprintf(fOutputfile, "%f %f %f\n", Indexed_Normals[x][0], Indexed_Normals[x][1], Indexed_Normals[x][2]);
		fprintf(fOutputfile, "%f %f\n", Indexed_UV[x][0], Indexed_UV[x][1]);

		Indexed_Vertices[++x][0] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[1]-1].x;
		Indexed_Vertices[x][1] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[1]-1].y;
		Indexed_Vertices[x][2] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[1]-1].z;

		Indexed_Normals[x][0] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[1]-1].x;
		Indexed_Normals[x][1] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[1]-1].y;
		Indexed_Normals[x][2] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[1]-1].z;

		Indexed_UV[x][0] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[1]-1].u;
		Indexed_UV[x][1] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[1]-1].v;

		fprintf(fOutputfile, "%f %f %f\n", Indexed_Vertices[x][0], Indexed_Vertices[x][1], Indexed_Vertices[x][2]);
		fprintf(fOutputfile, "%f %f %f\n", Indexed_Normals[x][0], Indexed_Normals[x][1], Indexed_Normals[x][2]);
		fprintf(fOutputfile, "%f %f\n", Indexed_UV[x][0], Indexed_UV[x][1]);


		Indexed_Vertices[++x][0] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[2]-1].x;
		Indexed_Vertices[x][1] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[2]-1].y;
		Indexed_Vertices[x][2] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[2]-1].z;
		
		Indexed_Normals[x][0] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[2]-1].x;
		Indexed_Normals[x][1] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[2]-1].y;
		Indexed_Normals[x][2] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[2]-1].z;

		Indexed_UV[x][0] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[2]-1].u;
		Indexed_UV[x][1] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[2]-1].v;

		fprintf(fOutputfile, "%f %f %f\n", Indexed_Vertices[x][0], Indexed_Vertices[x][1], Indexed_Vertices[x][2]);
		fprintf(fOutputfile, "%f %f %f\n", Indexed_Normals[x][0], Indexed_Normals[x][1], Indexed_Normals[x][2]);
		fprintf(fOutputfile, "%f %f\n", Indexed_UV[x][0], Indexed_UV[x][1]);

		//Increment to keep track of where at in face list
		iCounter++;
	}

	fclose(fOutputfile);

	//Reset counter
	iCounter = 0;

	// Vertex Array:
	PieceIndex = nextVAOIndex++;
	glBindVertexArray(vao[0]);
	nVerticesInVAO[0] = Delta*3;

	// color buffer
	glDisableVertexAttribArray(cBoard3D::aLoc_vColor);

	// vertex buffer
	glBindBuffer(GL_ARRAY_BUFFER, DataBuffers[nextFFBufferIndex++]);
	glBufferData(GL_ARRAY_BUFFER, Delta*3*sizeof(vec3), Indexed_Vertices, GL_STATIC_DRAW);
	glVertexAttribPointer(cBoard3D::aLoc_mcPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(cBoard3D::aLoc_mcPosition);

	//normal buffer
	glBindBuffer(GL_ARRAY_BUFFER, DataBuffers[nextFFBufferIndex++]);
	glBufferData(GL_ARRAY_BUFFER, 3*Delta*sizeof(vec3), Indexed_Normals, GL_STATIC_DRAW);
	glVertexAttribPointer(cBoard3D::aLoc_mcNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(cBoard3D::aLoc_mcNormal);
	
	//uv buffer
	glBindBuffer(GL_ARRAY_BUFFER, DataBuffers[nextFFBufferIndex++]);
	glBufferData(GL_ARRAY_BUFFER, 3*Delta*sizeof(vec2), Indexed_UV, GL_STATIC_DRAW);
	glVertexAttribPointer(cBoard3D::aLoc_mctexCoords, 2, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(cBoard3D::aLoc_mctexCoords);

	if(Indexed_Vertices)
	{
		delete []Indexed_Vertices;
		Indexed_Vertices = NULL;
	}
	
	if(Indexed_Normals)
	{
		delete []Indexed_Normals;
		Indexed_Normals = NULL;
	}
	
	if(Indexed_UV)
	{
		delete []Indexed_UV;
		Indexed_UV = NULL;
	}
	
}

void cBoard3D::doInitialize()
{
	//Set material properties for ambient, diffuse, and specular
	kakdks = new vec4[3];

	kakdks[0][0] = 0.5f; kakdks[0][1] = 0.5f; kakdks[0][2] = 0.5f; kakdks[0][3] = 1.0f;
	kakdks[1][0] = 0.8f; kakdks[1][1] = 0.0f; kakdks[1][2] = 0.0f; kakdks[1][3] = 1.0f;
	kakdks[2][0] = 0.2f; kakdks[2][1] = 0.0f; kakdks[2][2] = 0.0f; kakdks[2][3] = 1.0f;

	shininess = 20.0f;

	//Try to load the texture
	if(Texture.LoadTexture(strTexturePath) < 0)
	{
		cout << "ERROR - Loading texture in king: " << strTexturePath << endl;
		return;
	}

	if (cBoard3D::shaderProgram > 0)
	{
		//Position, normal, color
		cBoard3D::aLoc_vColor = glGetAttribLocation(shaderProgram, "vColor");
		cBoard3D::aLoc_vPosition = glGetAttribLocation(shaderProgram, "vPosition");
		cBoard3D::aLoc_mcPosition = glGetAttribLocation(shaderProgram, "mcPosition");
		cBoard3D::aLoc_mcNormal = glGetAttribLocation(shaderProgram, "mcNormal");
		cBoard3D::aLoc_mctexCoords = glGetAttribLocation(shaderProgram, "texCoords");
		
		//Texture stuff
		cBoard3D::uLoc_haveTextureMap = glGetUniformLocation(shaderProgram, "haveTextureMap");
		cBoard3D::uLoc_textureMap = glGetUniformLocation(shaderProgram, "textureMap");

		//Viewing Matricies
		cBoard3D::uLoc_modelViewMatrix = glGetUniformLocation(shaderProgram, "modelViewMatrix");
		cBoard3D::uLoc_projectionMatrix = glGetUniformLocation(shaderProgram, "projectionMatrix");
		cBoard3D::uLoc_normalMatrix = glGetUniformLocation(shaderProgram, "normalMatrix");

		//Lighting
		cBoard3D::uLoc_ecLightPosition = glGetUniformLocation(shaderProgram, "ecLightPosition");
		cBoard3D::uLoc_lightStrength = glGetUniformLocation(shaderProgram, "lightStrength");
		cBoard3D::uLoc_globalAmbient = glGetUniformLocation(shaderProgram, "globalAmbient");
		cBoard3D::uLoc_kakdks = glGetUniformLocation(shaderProgram, "kakdks");
		cBoard3D::uLoc_shininess = glGetUniformLocation(shaderProgram, "shininess");
		cBoard3D::uLoc_actualNumLights = glGetUniformLocation(shaderProgram, "actualNumLights");
		cBoard3D::uLoc_spotDir = glGetUniformLocation(shaderProgram, "spotDir");
		cBoard3D::uLoc_spotParams = glGetUniformLocation(shaderProgram, "spotParams");

		//Chess
		cBoard3D::uLoc_teamColor = glGetUniformLocation(shaderProgram, "iColor");
	}

	definePieceGeometry();
}

void cBoard3D::getWCBoundingBox(float* xyzLimits) const // {xmin, xmax, ymin, ymax, zmin, zmax}
{
	xyzLimits[0] = xmin; xyzLimits[1] = xmax; // (xmin, xmax)
	xyzLimits[2] = ymin; xyzLimits[3] = ymax; // (ymin, ymax)
	xyzLimits[4] = zmin; xyzLimits[5] = zmax; // (zmin, zmax)
}

void cBoard3D::render()
{
	GLint pgm;
	glGetIntegerv(GL_CURRENT_PROGRAM, &pgm);
	
	// activate our vertex-fragment shader program
	glUseProgram(shaderProgram);

	//Retrieve camera matrices from camera class
	cCamera::Get()->getMatrices(&modelViewMatrix[0], &normalMatrix[0], &projectionMatrix[0]);

	bool matrixIsStoredInRowMajorOrder = true; // is it?
	glUniformMatrix4fv(uLoc_modelViewMatrix, 1, matrixIsStoredInRowMajorOrder, modelViewMatrix);
	glUniformMatrix4fv(uLoc_projectionMatrix, 1, matrixIsStoredInRowMajorOrder, projectionMatrix);
	glUniformMatrix3fv(uLoc_normalMatrix, 1, matrixIsStoredInRowMajorOrder, normalMatrix);

	//Query lighting model, and pass to shader
	cLighting::Get()->QueryLightingVariables(actualNumLights, &ecLightPosition[0], &lightStrength[0], &spotDir[0], &spotParams[0], globalAmbient);

	//Pass info to shader
	glUniform1i(uLoc_actualNumLights, actualNumLights);

	glUniform4fv(uLoc_kakdks, 3, (GLfloat *)kakdks);
	glUniform1f(uLoc_shininess, shininess);

	glUniform4fv(uLoc_ecLightPosition, actualNumLights, (GLfloat *)ecLightPosition); 
    glUniform4fv(uLoc_lightStrength, actualNumLights, (GLfloat *)lightStrength); 
    glUniform4fv(uLoc_globalAmbient, 1, globalAmbient);

	glUniform3fv(uLoc_spotDir, actualNumLights, (GLfloat *)spotDir);
	glUniform2fv(uLoc_spotParams, actualNumLights, (GLfloat *)spotParams);

	//Chess stuff
	glUniform1i(uLoc_teamColor, iColor);

	//Texture stuff
	if(Texture.IsValid())
	{
		//Tell shader that textureMap is valid
		glUniform1i(uLoc_haveTextureMap, 1);
		
		//Use texture
		Texture.UseTexture();

		glUniform1i(uLoc_textureMap, 0); // refers to texture unit '0', the only one this program uses
	}
	else //Tell shader that this object doesnt have texture map
		glUniform1i(uLoc_haveTextureMap, 0);
			
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	//Draw object, and pass along normals to GL with it
	GLenum mode = GL_TRIANGLES;
	glBindVertexArray(vao[0]);
	glDrawArrays(mode, 0, nVerticesInVAO[0]);

	//cCamera::Get()->addTosGlobalScale(-10);

	// Done drawing; restore the previous program
	if (pgm > 0)
		glUseProgram(pgm);
}
