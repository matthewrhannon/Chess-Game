/* Matthew Hannon 2217853 skinnym2@ku.edu */

//Piece3D class
#include "Board_King.h"
#include "ShaderIF.h"

//Initalize static variables
GLuint cRenderer_King::shaderProgram = 0;
GLint cRenderer_King::aLoc_vColor = -1;
GLint cRenderer_King::aLoc_vPosition = -1;
GLint cRenderer_King::uLoc_scaleTrans = -1;

GLint cRenderer_King::uLoc_modelViewMatrix = -1;
GLint cRenderer_King::uLoc_projectionMatrix = -1;
GLint cRenderer_King::uLoc_normalMatrix = -1;

//Lighting stuff
GLint cRenderer_King::uLoc_actualNumLights = -1;

GLint cRenderer_King::uLoc_ecLightPosition = -1;
GLint cRenderer_King::uLoc_lightStrength = -1;
GLint cRenderer_King::uLoc_globalAmbient = -1;

GLint cRenderer_King::uLoc_spotDir = -1;
GLint cRenderer_King::uLoc_spotParams = -1;

GLint cRenderer_King::uLoc_kakdks = -1;
GLint cRenderer_King::uLoc_shininess = -1;

//Positon, texels, normals
GLint cRenderer_King::aLoc_mcPosition = -1;
GLint cRenderer_King::aLoc_mcNormal = -1;
GLint cRenderer_King::aLoc_mctexCoords = -1;

//Texture stuff
GLint cRenderer_King::uLoc_haveTextureMap = -1; 
GLint cRenderer_King::uLoc_textureMap = -1;

//*******************************//


//King specifications -- KingB------9570-7582=1988-1 = 1987 delta
cRenderer_King::cRenderer_King(const vec3 origin, int _iColor, ObjModel *_Model, int _Start, int _End)
{
	if (cRenderer_King::shaderProgram == 0)
		cRenderer_King::shaderProgram = ShaderIF::initShader("King.vsh", "King.fsh");

	nextVAOIndex = 0;
	nextFFBufferIndex = 0;

	// Now do instance-specific initialization:
	PieceOrigin[0] = origin[0]; PieceOrigin[1] = origin[1]; PieceOrigin[2] = origin[2];
		
	//Initalize variables that will reprsent the bounding box for this piece
	xmin = -5;
	xmax = 5;
	ymin = -5;
	ymax = 5;
	zmin = -5;
	zmax = 5;

	//Set the color for each block
	iColor = _iColor;

	pTerrain_Vertices = NULL;
	pTerrain_Normals = NULL;
	iNumVertices = 0;
	PieceIndex = 0;

	//Path to verticese file
	//strPath = "Data/TestTerrain.raw";

	//Store triangle offset information
	Start = _Start;
	End = _End;
	Model = _Model;

	//Calculate number of triangles that make up object
	Delta = (End - Start)-1;

	if(Delta < 0)
		return;

	//Texture
	strcpy(strTexturePath, "Models\\blackmarble.bmp");
	//strcpy(strTexturePath, "Models\\jade.bmp");
	doInitialize();
}

cRenderer_King::~cRenderer_King()
{
	if(kakdks)
	{
		delete []kakdks;
		kakdks = NULL;
	}
	
	if(pTerrain_Normals)
	{
		delete []pTerrain_Normals;
		pTerrain_Normals = NULL;
	}


	glDeleteVertexArrays(1, vao);
	glDeleteBuffers(3, DataBuffers);
}



void cRenderer_King::definePieceGeometry()
{
	//Create vertex array and assosicative buffers
	glGenVertexArrays(1, &vao[0]);
	glGenBuffers(3, DataBuffers);

	//Need to create triangles now out of this data, so define the variables that will hold them, and then traverse the ObjModel structure
	//	to fill the indicies for the triangles/faces.
	vec3 *Indexed_Vertices = new vec3[Delta*3]; //Times 3 because each face represents a triangle so need 3x number vertices to represent
	vec3 *Indexed_Normals = new vec3[Delta*3];
	vec2 *Indexed_UV = new vec2[Delta*3];


	//Now lets fill the array with triangles that will componse the object being created
	int iCounter = 0;

	if(Model == NULL)
		return;

	//Print to file
	FILE *fOutputfile = fopen("KingIndices.txt", "w");

	if(!fOutputfile)
	{
		cout << "Error Opening file! Filename: " << "KingIndices.txt" << "\n";
		return;
	}
		
	for(int x = 0; x < Delta*3; x++)
	{
		//Vertices to triangles
		Indexed_Vertices[x][0] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[0]-1].x;
		Indexed_Vertices[x][1] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[0]-1].y;
		Indexed_Vertices[x][2] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[0]-1].z;

		Indexed_Normals[x][0] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[0]-1].x;
		Indexed_Normals[x][1] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[0]-1].y;
		Indexed_Normals[x][2] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[0]-1].z;

		Indexed_UV[x][0] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[0]-1].u;
		Indexed_UV[x][1] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[0]-1].v;

		fprintf(fOutputfile, "%f %f %f\n", Indexed_Vertices[x][0], Indexed_Vertices[x][1], Indexed_Vertices[x][2]);
		fprintf(fOutputfile, "%f %f %f\n", Indexed_Normals[x][0], Indexed_Normals[x][1], Indexed_Normals[x][2]);
		fprintf(fOutputfile, "%f %f\n", Indexed_UV[x][0], Indexed_UV[x][1]);

		Indexed_Vertices[++x][0] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[1]-1].x;
		Indexed_Vertices[x][1] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[1]-1].y;
		Indexed_Vertices[x][2] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[1]-1].z;

		Indexed_Normals[x][0] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[1]-1].x;
		Indexed_Normals[x][1] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[1]-1].y;
		Indexed_Normals[x][2] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[1]-1].z;

		Indexed_UV[x][0] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[1]-1].u;
		Indexed_UV[x][1] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[1]-1].v;

		fprintf(fOutputfile, "%f %f %f\n", Indexed_Vertices[x][0], Indexed_Vertices[x][1], Indexed_Vertices[x][2]);
		fprintf(fOutputfile, "%f %f %f\n", Indexed_Normals[x][0], Indexed_Normals[x][1], Indexed_Normals[x][2]);
		fprintf(fOutputfile, "%f %f\n", Indexed_UV[x][0], Indexed_UV[x][1]);


		Indexed_Vertices[++x][0] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[2]-1].x;
		Indexed_Vertices[x][1] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[2]-1].y;
		Indexed_Vertices[x][2] = Model->VertexArray[Model->TriangleArray[Start+iCounter].Vertex[2]-1].z;
		
		Indexed_Normals[x][0] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[2]-1].x;
		Indexed_Normals[x][1] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[2]-1].y;
		Indexed_Normals[x][2] = Model->NormalArray[Model->TriangleArray[Start+iCounter].Normal[2]-1].z;

		Indexed_UV[x][0] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[2]-1].u;
		Indexed_UV[x][1] =  Model->TexCoordArray[Model->TriangleArray[Start+iCounter].TexCoord[2]-1].v;

		fprintf(fOutputfile, "%f %f %f\n", Indexed_Vertices[x][0], Indexed_Vertices[x][1], Indexed_Vertices[x][2]);
		fprintf(fOutputfile, "%f %f %f\n", Indexed_Normals[x][0], Indexed_Normals[x][1], Indexed_Normals[x][2]);
		fprintf(fOutputfile, "%f %f\n", Indexed_UV[x][0], Indexed_UV[x][1]);

		//Increment to keep track of where at in face list
		iCounter++;
	}

	fclose(fOutputfile);

	//**EDIT** (BAD) PLAN: For now, lets have each face have a single normal. Each face is represented by 3 vertices down the array to the end.
	//		Could calculate the center of these triangles and place this as the normal origin, and then have the calculated normal create a line to show it

	//Do Normals nows
	//vec3 *Indexed_Normals = new vec3[Delta*3];
	//vec3 *Indexed_Draw_Normals = new vec3[Delta*6]; //x2 because need room to store each point for each line/vector representation
	/*
iCounter = 0;
	
	cryph::AffVector tempVector1, tempVector2, tempNormal;
	for(int x = 0; x < Delta*3; x++)
	{
		tempVector1 = cryph::AffVector(( Indexed_Vertices[x][0] - Indexed_Vertices[x+1][0] ), ( Indexed_Vertices[x][1] - Indexed_Vertices[x+1][1] ), ( Indexed_Vertices[x][2] - Indexed_Vertices[x+1][2] ));
		tempVector2 = cryph::AffVector(( Indexed_Vertices[x+1][0] - Indexed_Vertices[x+2][0] ), ( Indexed_Vertices[x+1][1] - Indexed_Vertices[x+2][1] ), ( Indexed_Vertices[x+1][2] - Indexed_Vertices[x+2][2] ));
		
		tempNormal = tempVector1.cross(tempVector2);  
		tempNormal.normalize();

		//Fill in normal to match with each triangle
		Indexed_Normals[x][0] = tempNormal[0];
		Indexed_Normals[x][1] = tempNormal[1];
		Indexed_Normals[x][2] = tempNormal[2];

		Indexed_Normals[++x][0] = tempNormal[0];
		Indexed_Normals[x][1] = tempNormal[1];
		Indexed_Normals[x][2] = tempNormal[2];
				
		Indexed_Normals[++x][0] = tempNormal[0];
		Indexed_Normals[x][1] = tempNormal[1];
		Indexed_Normals[x][2] = tempNormal[2];


		//FIXME: Calculate normals for each vertex!
		//x++;// x++;

		//Increment counter to keep track of what normal goes to what triangle
	//	iCounter++;
	}
	*/
	//Reset counter
	iCounter = 0;
	/*
	//Now fill in the draw normal array for visualization
	for(int x = 0; x < Delta*6; x++)
	{
		Indexed_Draw_Normals[x][0] = Indexed_Vertices[iCounter][0];
		Indexed_Draw_Normals[x][1] = Indexed_Vertices[iCounter][1];
		Indexed_Draw_Normals[x][2] = Indexed_Vertices[iCounter][2];

		Indexed_Draw_Normals[++x][0] = Indexed_Normals[iCounter][0];
		Indexed_Draw_Normals[x][1] = Indexed_Normals[iCounter][1];
		Indexed_Draw_Normals[x][2] = Indexed_Normals[iCounter][2];
		


		iCounter++;
	}
	*/
	//****
	
	/*
		glGenBuffers(1, &normalBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, normalBuffer);
	*/

	// Vertex Array:
	PieceIndex = nextVAOIndex++;
	glBindVertexArray(vao[0]);
	nVerticesInVAO[0] = Delta*3;

	// color buffer
	glDisableVertexAttribArray(cRenderer_King::aLoc_vColor);

	// vertex buffer
	glBindBuffer(GL_ARRAY_BUFFER, DataBuffers[nextFFBufferIndex++]);
	glBufferData(GL_ARRAY_BUFFER, Delta*3*sizeof(vec3), Indexed_Vertices, GL_STATIC_DRAW);
	glVertexAttribPointer(cRenderer_King::aLoc_mcPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(cRenderer_King::aLoc_mcPosition);

	//normal buffer
	glBindBuffer(GL_ARRAY_BUFFER, DataBuffers[nextFFBufferIndex++]);
	glBufferData(GL_ARRAY_BUFFER, 3*Delta*sizeof(vec3), Indexed_Normals, GL_STATIC_DRAW);
	glVertexAttribPointer(cRenderer_King::aLoc_mcNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(cRenderer_King::aLoc_mcNormal);
	
	//uv buffer
	glBindBuffer(GL_ARRAY_BUFFER, DataBuffers[nextFFBufferIndex++]);
	glBufferData(GL_ARRAY_BUFFER, 3*Delta*sizeof(vec2), Indexed_UV, GL_STATIC_DRAW);
	glVertexAttribPointer(cRenderer_King::aLoc_mctexCoords, 2, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(cRenderer_King::aLoc_mctexCoords);
	
	
	/*
	// Vertex Array:
	PieceIndex = nextVAOIndex++;
	glBindVertexArray(vao[1]);
	nVerticesInVAO[1] = Delta*6;

	//normal visualization buffer
	glDisableVertexAttribArray(cRenderer_King::aLoc_vColor);

	glBindBuffer(GL_ARRAY_BUFFER, DataBuffers[0]);
	glBufferData(GL_ARRAY_BUFFER, Delta*6*sizeof(vec3), Indexed_Draw_Normals, GL_STATIC_DRAW);
	glVertexAttribPointer(cRenderer_King::aLoc_mcPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(cRenderer_King::aLoc_mcPosition);
	*/
	//Done with indice data so get rid of it cause in the GPU
	
	if(Indexed_Vertices)
	{
		delete []Indexed_Vertices;
		Indexed_Vertices = NULL;
	}
	
	if(Indexed_Normals)
	{
		delete []Indexed_Normals;
		Indexed_Normals = NULL;
	}
	
	if(Indexed_UV)
	{
		delete []Indexed_UV;
		Indexed_UV = NULL;
	}
	
}

void cRenderer_King::doInitialize()
{
	//Set material properties for ambient, diffuse, and specular
	kakdks = new vec4[3];

	kakdks[0][0] = 0.5f; kakdks[0][1] = 0.5f; kakdks[0][2] = 0.5f; kakdks[0][3] = 1.0f;
	kakdks[1][0] = 0.8f; kakdks[1][1] = 0.0f; kakdks[1][2] = 0.0f; kakdks[1][3] = 1.0f;
	kakdks[2][0] = 0.2f; kakdks[2][1] = 0.0f; kakdks[2][2] = 0.0f; kakdks[2][3] = 1.0f;

	shininess = 20.0f;

	//Try to load the texture
	if(Texture.LoadTexture(strTexturePath) < 0)
	{
		cout << "ERROR - Loading texture in king: " << strTexturePath << endl;
		return;
	}

	if (cRenderer_King::shaderProgram > 0)
	{
		//Position, normal, color
		cRenderer_King::aLoc_vColor = glGetAttribLocation(shaderProgram, "vColor");
		cRenderer_King::aLoc_vPosition = glGetAttribLocation(shaderProgram, "vPosition");
		cRenderer_King::aLoc_mcPosition = glGetAttribLocation(shaderProgram, "mcPosition");
		cRenderer_King::aLoc_mcNormal = glGetAttribLocation(shaderProgram, "mcNormal");
		cRenderer_King::aLoc_mctexCoords = glGetAttribLocation(shaderProgram, "texCoords");
		
		//Texture stuff
		cRenderer_King::uLoc_haveTextureMap = glGetUniformLocation(shaderProgram, "haveTextureMap");
		cRenderer_King::uLoc_textureMap = glGetUniformLocation(shaderProgram, "textureMap");

		//Viewing Matricies
		cRenderer_King::uLoc_modelViewMatrix = glGetUniformLocation(shaderProgram, "modelViewMatrix");
		cRenderer_King::uLoc_projectionMatrix = glGetUniformLocation(shaderProgram, "projectionMatrix");
		cRenderer_King::uLoc_normalMatrix = glGetUniformLocation(shaderProgram, "normalMatrix");

		//Lighting
		cRenderer_King::uLoc_ecLightPosition = glGetUniformLocation(shaderProgram, "ecLightPosition");
		cRenderer_King::uLoc_lightStrength = glGetUniformLocation(shaderProgram, "lightStrength");
		cRenderer_King::uLoc_globalAmbient = glGetUniformLocation(shaderProgram, "globalAmbient");
		cRenderer_King::uLoc_kakdks = glGetUniformLocation(shaderProgram, "kakdks");
		cRenderer_King::uLoc_shininess = glGetUniformLocation(shaderProgram, "shininess");
		cRenderer_King::uLoc_actualNumLights = glGetUniformLocation(shaderProgram, "actualNumLights");
		cRenderer_King::uLoc_spotDir = glGetUniformLocation(shaderProgram, "spotDir");
		cRenderer_King::uLoc_spotParams = glGetUniformLocation(shaderProgram, "spotParams");
	}

	definePieceGeometry();
}

void cRenderer_King::getWCBoundingBox(float* xyzLimits) const // {xmin, xmax, ymin, ymax, zmin, zmax}
{
	xyzLimits[0] = xmin; xyzLimits[1] = xmax; // (xmin, xmax)
	xyzLimits[2] = ymin; xyzLimits[3] = ymax; // (ymin, ymax)
	xyzLimits[4] = zmin; xyzLimits[5] = zmax; // (zmin, zmax)
}

void cRenderer_King::render()
{
	//cout << "In render inside cRenderer_King\n";
	// save the current GLSL program in use
	GLint pgm;
	glGetIntegerv(GL_CURRENT_PROGRAM, &pgm);
	
	// activate our vertex-fragment shader program
	glUseProgram(shaderProgram);

	//Retrieve camera matrices from camera class
	cCamera::Get()->getMatrices(&modelViewMatrix[0], &normalMatrix[0], &projectionMatrix[0]);

	bool matrixIsStoredInRowMajorOrder = true; // is it?
	glUniformMatrix4fv(uLoc_modelViewMatrix, 1, matrixIsStoredInRowMajorOrder, modelViewMatrix);
	glUniformMatrix4fv(uLoc_projectionMatrix, 1, matrixIsStoredInRowMajorOrder, projectionMatrix);
	glUniformMatrix3fv(uLoc_normalMatrix, 1, matrixIsStoredInRowMajorOrder, normalMatrix);

	//Query lighting model, and pass to shader
	cLighting::Get()->QueryLightingVariables(actualNumLights, &ecLightPosition[0], &lightStrength[0], &spotDir[0], &spotParams[0], globalAmbient);

	//Pass info to shader
	glUniform1i(uLoc_actualNumLights, actualNumLights);

	glUniform4fv(uLoc_kakdks, 3, (GLfloat *)kakdks);
	glUniform1f(uLoc_shininess, shininess);

	glUniform4fv(uLoc_ecLightPosition, actualNumLights, (GLfloat *)ecLightPosition); 
    glUniform4fv(uLoc_lightStrength, actualNumLights, (GLfloat *)lightStrength); 
    glUniform4fv(uLoc_globalAmbient, 1, globalAmbient);

	glUniform3fv(uLoc_spotDir, actualNumLights, (GLfloat *)spotDir);
	glUniform2fv(uLoc_spotParams, actualNumLights, (GLfloat *)spotParams);

	//Texture stuff
	if(Texture.IsValid())
	{
		//Tell shader that textureMap is valid
		glUniform1i(uLoc_haveTextureMap, 1);
		
		//Use texture
		Texture.UseTexture();

		glUniform1i(uLoc_textureMap, 0); // refers to texture unit '0', the only one this program uses
	}
	else //Tell shader that this object doesnt have texture map
		glUniform1i(uLoc_haveTextureMap, 0);
			

   // glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	//cCamera::Get()->addTosGlobalScale(0);

	//Draw object, and pass along normals to GL with it
	//GLenum mode = GL_TRIANGLE_STRIP;

	GLenum mode = GL_TRIANGLES;
	//glPointSize(4);
	glBindVertexArray(vao[0]);
	glDrawArrays(mode, 0, nVerticesInVAO[0]);
	
	//Actually draw normals
//	cCamera::Get()->addTosGlobalScale(-10);
	/*
	mode = GL_LINES;
	glBindVertexArray(vao[1]);

	glDrawArrays(mode, 0, nVerticesInVAO[1]);
	*/
	// Done drawing; restore the previous program
	if (pgm > 0)
		glUseProgram(pgm);

}
