//Terrain header
/* Matthew Hannon 2217853 skinnym2@ku.edu */

#ifndef TERRAIN_H
#define TERRAIN_H

#include "Externals.h"
#include "ModelView.h"

#include "AffPoint.h"
#include "AffVector.h"
#include "MatrixUtil.h"

//Include camera class
#include "Camera.h"

//Include structures for obj files
#include "OBJ_Loader.h"

//Texture loader class
#include "Texture.h"

//Include lighting
#include "Lighting.h"

//use the cryph namespace so dont have to type cryph::
using namespace cryph;


#define MAX_NUM_LIGHTS 3

#define TERRAIN_SIZE 1023
#define INDEXED_TERRAIN_SIZE ((TERRAIN_SIZE-1)*(TERRAIN_SIZE-1))*6 //Use 6 because drawing two triangles w/ 3 vertices each

class cRenderer_King : public ModelView
{
public:
	cRenderer_King();

	cRenderer_King(const vec3 origin, int _iColor, ObjModel *_Model, int _Start, int _End);
	virtual ~cRenderer_King();

	void getWCBoundingBox(float* xyzLimits) const; // {xmin, xmax, ymin, ymax, zmin, zmax}
	void render();


private:
	//Variables about placement of meshes within the ObjModel structure
	int Start, End, Delta;
	ObjModel *Model;

	//Texture object
	cTexture Texture;
	char strTexturePath[128];

	GLuint vao[2], nVerticesInVAO[2];
	int nextVAOIndex;

	GLuint DataBuffers[3];
	int nextFFBufferIndex;
	
	static GLuint shaderProgram; // all instances use same shader program
	static GLint aLoc_vColor;
	static GLint aLoc_vPosition;
	static GLint uLoc_scaleTrans;

	//Coordinates
	GLfloat xmin, xmax, ymin, ymax, zmin, zmax;
	static GLint  uLoc_modelViewMatrix;
	static GLint  uLoc_projectionMatrix;
	static GLint  uLoc_normalMatrix;

	GLfloat modelViewMatrix[16];
	GLfloat projectionMatrix[16];
	GLfloat normalMatrix[9];

	//Position and normal vectors
	static GLint aLoc_mcPosition;
	static GLint aLoc_mcNormal;
	static GLint aLoc_mctexCoords;

	vec3 mcPosition, mcNormal, texCoords;

	//Texture defines
	static GLint uLoc_haveTextureMap;;
	static GLint uLoc_textureMap;

	//Lighting
	static GLint uLoc_actualNumLights;
	int actualNumLights;

	static GLint uLoc_ecLightPosition;
	static GLint uLoc_lightStrength;
	static GLint uLoc_globalAmbient;

	vec4 ecLightPosition[3];
	vec4 lightStrength[3];
	vec4 globalAmbient;
	
	static GLint uLoc_spotDir;
	static GLint uLoc_spotParams;

	vec3 spotDir[3];
	vec2 spotParams[3];

	static GLint uLoc_kakdks;
	static GLint uLoc_shininess;

	vec4 *kakdks;
	float shininess;


	/*
//Lighting stuff
uniform vec4 ecLightPosition[MAX_NUM_LIGHTS]; // position assumed to be in eye coordinates
uniform vec4 lightStrength[MAX_NUM_LIGHTS];
uniform vec4 globalAmbient;

// positional sources can be spotlights:
uniform vec3 spotDir[MAX_NUM_LIGHTS]; // only used if this really is a spot light
uniform vec2 spotParams[MAX_NUM_LIGHTS]; // [i][0]: cutoffAngleInDegrees (spotlight if and only if < 90); [i][1]: exponent

//material properties
uniform vec4 kakdks[3];
uniform float shininess;


*/




















	/////////////////////////////////////////
	void definePieceGeometry();
	void doInitialize();
	bool LoadVertices();

	//Variables

	int iNumVertices;
	string strPath;
	int iColor;

	int PieceIndex;
	
	//Terrain variables
	vec3 *pTerrain_Vertices, *pTerrain_Normals;

};

#endif
