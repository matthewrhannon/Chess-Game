/* Matthew Hannon 2217853 skinnym2@ku.edu */

// Board_Renderer

#include "Board_Renderer.h"


cBoard_Renderer::cBoard_Renderer(const vec3 origin)
{
	// Now do instance-specific initialization:
	MapOrigin[0] = origin[0]; MapOrigin[1] = origin[1]; MapOrigin[2] = origin[2];
	
	//strcpy(strChessModelPath, "Models\\UpdatedChessBoard.obj");
	//strcpy(strChessModelPath, "Models\\King_Model_Update.obj");
	//strcpy(strChessModelPath, "Models\\New_King_Model_UV.obj");
	strcpy(strChessModelPath, "Models\\Piece_Models\\Board_Model.obj");
}

cBoard_Renderer::~cBoard_Renderer()
{

}


bool cBoard_Renderer::ConvertOrigintoGrid(int x, int y, vec3 &retOrigin)
{
	if(x <= 0)
		return false;
	if(y <= 0)
		return false;

	retOrigin[0] = 8.8 - ((y-1)*2.5);
	retOrigin[1] = 0.5;
	retOrigin[2] = 8.8 - ((x-1)*2.5);

	return true;
}



bool cBoard_Renderer::InitalizeMap(Controller *curController)
{
	cout << "Initalize\n";
	//Define variables
	float xStart = 0.0f, yStart = 0.0f; // arbitrary starting point
	vec3 origin = { xStart, yStart , 0 };
	
	ModelView* m = NULL;
	float xyz[6], rowSize = -1.0;

	int iPieceColor = -1;


	char* memory = NULL;
	size_t bytes = ObjLoadFile((char *)strChessModelPath, &memory);
	model = ObjLoadModel(memory, bytes);

	printf("\nLoading OBJ file: %s\n", strChessModelPath);
	/*
	printf("Object Model has: %d faces/triangles!\n", model->nTriangle);
	printf("Object Model has: %d vertices!\n", model->nVertex);
	printf("Object Model has: %d normals!\n", model->nNormal);
	printf("Object Model has: %d texcoords!\n", model->nTexCoord);
	*/
	//system("PAUSE");


	 //Define camera matricies
	 cCamera::Get()->defineMatrices(true);

	 //Initalize lighting class
	 cLighting::Get()->InitalizeLightingVariables();

//	yStart += 1.05 * rowSize;
//	origin[0] = xStart; origin[1] = yStart; origin[2] = 0;

	//KingB------9570-7582=1988-1 = 1987
//	m = new cRenderer_King(origin, false, model, 7582, 9570);
//	m = new cRenderer_King(origin, false, model, 0, 46674);


	 //Draw board
	cCamera::Get()->addToGlobalRotateDegrees(0, -90, 0);
	cCamera::Get()->addTosGlobalScale(-1);
	m = new cBoard3D(origin, 0, model, 0, model->nTriangle, "Board");
	if (m != NULL)
	{
		curController->addModel(m);
		m->getWCBoundingBox(xyz);
		//origin[0] += (xyz[1] - xyz[0]);
	}
		
	if(model != NULL)
	{
		free(model->NormalArray);
		free(model->TexCoordArray);
		free(model->TriangleArray);
		free(model->VertexArray);
		free(model);
	}

	//Load pieces now

	//First load kings
	if(memory != NULL)
	{
		free(memory);
		memory = NULL;
	}
	ModelView* King = NULL;
	strcpy(strChessModelPath, "Models\\Piece_Models\\New_King_Model_UV.obj");

	bytes = ObjLoadFile((char *)strChessModelPath, &memory);
	model = ObjLoadModel(memory, bytes);

	printf("\nLoading OBJ file: %s\n", strChessModelPath);
	/*
	printf("Object Model has: %d faces/triangles!\n", model->nTriangle);
	printf("Object Model has: %d vertices!\n", model->nVertex);
	printf("Object Model has: %d normals!\n", model->nNormal);
	printf("Object Model has: %d texcoords!\n", model->nTexCoord);
	*/

	ConvertOrigintoGrid(5, 1, origin);
	//origin[0] = 6.5;
	//origin[1] = 0.5;
	//origin[2] = 6.3;


	King = new cPiece3D(origin, 0, model, 0, model->nTriangle, "KingWhite", 5, 1);
	if (King != NULL)
	{
		curController->addModel(King);
		King->getWCBoundingBox(xyz);
		//origin[0] += (xyz[1] - xyz[0]);
	}

	ConvertOrigintoGrid(5, 8, origin);
	King = new cPiece3D(origin, 1, model, 0, model->nTriangle, "KingBlack", 5, 8);
	if (King != NULL)
	{
		curController->addModel(King);
		King->getWCBoundingBox(xyz);
		//origin[0] += (xyz[1] - xyz[0]);
	}

	if(model != NULL)
	{
		free(model->NormalArray);
		free(model->TexCoordArray);
		free(model->TriangleArray);
		free(model->VertexArray);
		free(model);
	}



	//Load Pawns next
	if(memory != NULL)
	{
		free(memory);
		memory = NULL;
	}
	ModelView* Pawn = NULL;
	strcpy(strChessModelPath, "Models\\Piece_Models\\Pawn_Model.obj");

	bytes = ObjLoadFile((char *)strChessModelPath, &memory);
	model = ObjLoadModel(memory, bytes);


	printf("\nLoading OBJ file: %s\n", strChessModelPath);
	/*
	printf("Object Model has: %d faces/triangles!\n", model->nTriangle);
	printf("Object Model has: %d vertices!\n", model->nVertex);
	printf("Object Model has: %d normals!\n", model->nNormal);
	printf("Object Model has: %d texcoords!\n", model->nTexCoord);
	*/

	//Load white pawns
	for(int x = 1; x < 9; x++)
	{
		ConvertOrigintoGrid(x, 2, origin);

		Pawn = new cPiece3D(origin, 0, model, 0, model->nTriangle, "PawnWhite", x, 2);
		if (Pawn != NULL)
		{
			curController->addModel(Pawn);
			Pawn->getWCBoundingBox(xyz);
		}

	}
	
	//Load black pawns
	for(int x = 1; x < 9; x++)
	{
		ConvertOrigintoGrid(x, 7, origin);

		Pawn = new cPiece3D(origin, 1, model, 0, model->nTriangle, "PawnBlack", x, 7);
		if (Pawn != NULL)
		{
			curController->addModel(Pawn);
			Pawn->getWCBoundingBox(xyz);
		}

	}

	if(model != NULL)
	{
		free(model->NormalArray);
		free(model->TexCoordArray);
		free(model->TriangleArray);
		free(model->VertexArray);
		free(model);
	}

	//Load rooks
	if(memory != NULL)
	{
		free(memory);
		memory = NULL;
	}

	ModelView* Rook = NULL;
	strcpy(strChessModelPath, "Models\\Piece_Models\\Rook_Model.obj");

	bytes = ObjLoadFile((char *)strChessModelPath, &memory);
	model = ObjLoadModel(memory, bytes);


	printf("\nLoading OBJ file: %s\n", strChessModelPath);
	/*
	printf("Object Model has: %d faces/triangles!\n", model->nTriangle);
	printf("Object Model has: %d vertices!\n", model->nVertex);
	printf("Object Model has: %d normals!\n", model->nNormal);
	printf("Object Model has: %d texcoords!\n", model->nTexCoord);
	*/
	//Do whites 
	ConvertOrigintoGrid(1, 1, origin);

	Rook = new cPiece3D(origin, 0, model, 0, model->nTriangle, "Rook1White", 1, 1);
	if (King != NULL)
	{
		curController->addModel(Rook);
		Rook->getWCBoundingBox(xyz);
	}

	ConvertOrigintoGrid(8, 1, origin);
	Rook = new cPiece3D(origin, 0, model, 0, model->nTriangle, "Rook2White", 8, 1);
	if (King != NULL)
	{
		curController->addModel(Rook);
		Rook->getWCBoundingBox(xyz);
	}

	//Do Blacks 
	ConvertOrigintoGrid(1, 8, origin);

	Rook = new cPiece3D(origin, 1, model, 0, model->nTriangle, "Rook1Black", 1, 8);
	if (King != NULL)
	{
		curController->addModel(Rook);
		Rook->getWCBoundingBox(xyz);
	}

	ConvertOrigintoGrid(8, 8, origin);
	Rook = new cPiece3D(origin, 1, model, 0, model->nTriangle, "Rook2Black", 8, 8);
	if (King != NULL)
	{
		curController->addModel(Rook);
		Rook->getWCBoundingBox(xyz);
	}

	if(model != NULL)
	{
		free(model->NormalArray);
		free(model->TexCoordArray);
		free(model->TriangleArray);
		free(model->VertexArray);
		free(model);
	}

	//Draw bishops
	if(memory != NULL)
	{
		free(memory);
		memory = NULL;
	}

	ModelView* Bishop = NULL;
	strcpy(strChessModelPath, "Models\\Piece_Models\\Bishop_Model.obj");

	bytes = ObjLoadFile((char *)strChessModelPath, &memory);
	model = ObjLoadModel(memory, bytes);

	printf("\nLoading OBJ file: %s\n", strChessModelPath);

	//Do whites 
	ConvertOrigintoGrid(3, 1, origin);

	Bishop = new cPiece3D(origin, 0, model, 0, model->nTriangle, "Bishop1White", 3, 1);
	if (Bishop != NULL)
	{
		curController->addModel(Bishop);
		Bishop->getWCBoundingBox(xyz);
	}

	ConvertOrigintoGrid(6, 1, origin);
	Bishop = new cPiece3D(origin, 0, model, 0, model->nTriangle, "Bishop2White", 6, 1);
	if (Bishop != NULL)
	{
		curController->addModel(Bishop);
		Bishop->getWCBoundingBox(xyz);
	}

	//Do Blacks 
	ConvertOrigintoGrid(3, 8, origin);

	Bishop = new cPiece3D(origin, 1, model, 0, model->nTriangle, "Bishop1Black", 3, 8);
	if (Bishop != NULL)
	{
		curController->addModel(Bishop);
		Bishop->getWCBoundingBox(xyz);
	}

	ConvertOrigintoGrid(6, 8, origin);
	Bishop = new cPiece3D(origin, 1, model, 0, model->nTriangle, "Bishop2Black", 6, 8);
	if (Bishop != NULL)
	{
		curController->addModel(Bishop);
		Bishop->getWCBoundingBox(xyz);
	}

	if(model != NULL)
	{
		free(model->NormalArray);
		free(model->TexCoordArray);
		free(model->TriangleArray);
		free(model->VertexArray);
		free(model);
	}

	//Draw knights
	if(memory != NULL)
	{
		free(memory);
		memory = NULL;
	}

	ModelView* Knight = NULL;
	strcpy(strChessModelPath, "Models\\Piece_Models\\Knight_Model.obj");

	bytes = ObjLoadFile((char *)strChessModelPath, &memory);
	model = ObjLoadModel(memory, bytes);

	printf("\nLoading OBJ file: %s\n", strChessModelPath);

	//Do whites 
	ConvertOrigintoGrid(2, 1, origin);

	Knight = new cPiece3D(origin, 0, model, 0, model->nTriangle, "Knight1White", 2, 1);
	if (Knight != NULL)
	{
		curController->addModel(Knight);
		Knight->getWCBoundingBox(xyz);
	}

	ConvertOrigintoGrid(7, 1, origin);
	Knight = new cPiece3D(origin, 0, model, 0, model->nTriangle, "Knight2White", 7, 1);
	if (Knight != NULL)
	{
		curController->addModel(Knight);
		Knight->getWCBoundingBox(xyz);
	}

	//Do Blacks 
	ConvertOrigintoGrid(2, 8, origin);

	Knight = new cPiece3D(origin, 1, model, 0, model->nTriangle, "Knight1Black", 2, 8);
	if (Knight != NULL)
	{
		curController->addModel(Knight);
		Knight->getWCBoundingBox(xyz);
	}

	ConvertOrigintoGrid(7, 8, origin);
	Knight = new cPiece3D(origin, 1, model, 0, model->nTriangle, "Knight2Black", 7, 8);
	if (Knight != NULL)
	{
		curController->addModel(Knight);
		Knight->getWCBoundingBox(xyz);
	}

	if(model != NULL)
	{
		free(model->NormalArray);
		free(model->TexCoordArray);
		free(model->TriangleArray);
		free(model->VertexArray);
		free(model);
	}

	//Draw queens
	if(memory != NULL)
	{
		free(memory);
		memory = NULL;
	}

	ModelView* Queen = NULL;
	strcpy(strChessModelPath, "Models\\Piece_Models\\Queen_Model.obj");

	bytes = ObjLoadFile((char *)strChessModelPath, &memory);
	model = ObjLoadModel(memory, bytes);

	printf("\nLoading OBJ file: %s\n", strChessModelPath);

	//Do whites 
	ConvertOrigintoGrid(4, 1, origin);

	Queen = new cPiece3D(origin, 0, model, 0, model->nTriangle, "QueenWhite", 4, 1);
	if (Queen != NULL)
	{
		curController->addModel(Queen);
		Queen->getWCBoundingBox(xyz);
	}


	//Do Blacks 
	ConvertOrigintoGrid(4, 8, origin);

	Queen = new cPiece3D(origin, 1, model, 0, model->nTriangle, "QueenBlack", 4, 8);
	if (Queen != NULL)
	{
		curController->addModel(Queen);
		Queen->getWCBoundingBox(xyz);
	}

	if(model != NULL)
	{
		free(model->NormalArray);
		free(model->TexCoordArray);
		free(model->TriangleArray);
		free(model->VertexArray);
		free(model);
	}
	return true;
}
