/* Matthew Hannon 2217853 skinnym2@ku.edu */

#ifndef BOARD_RENDERER
#define BOARD_RENDERER

#include "Externals.h"

#include "Controller.h"
#include "ModelView.h"

#include "OBJ_Loader.h"
#include "Camera.h"

//Include board
#include "Board3D.h"

//Include pieces
//#include "Board_King.h"
#include "Piece3D.h"

//Include lighting
#include "Lighting.h"

class cBoard_Renderer
{
	public:
		cBoard_Renderer(const vec3 origin);
		virtual ~cBoard_Renderer();


		bool InitalizeMap(Controller *curController);
		bool ConvertOrigintoGrid(int x, int y, vec3 &retOrigin);
	private:
		vec3 MapOrigin;
		ObjModel* model;

		char strChessModelPath[128];
};

#endif
