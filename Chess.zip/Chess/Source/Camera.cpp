//Matt H 11/26/2011

#include "Camera.h"

//Static declarations
cCamera *cCamera::Instance = NULL;

bool cCamera::AdjustAspectRatio(float fVPAspectRatio, float _winXmin, float _winXmax, float _winYmin, float _winYmax)
{
	//Need to equate the viewport and world coordinate aspect ratios
	
	float fWAspectRatio = ( (ymax - ymin) / (xmax - xmin) );

	if(fWAspectRatio > fVPAspectRatio)
	{
		float fnewWidth = (ymax - ymin) / fVPAspectRatio;
		fnewWidth /= 2;
		xmax = fnewWidth;
		xmin = -fnewWidth;
	}
	else
	{
		float fnewHeight = fVPAspectRatio*(xmax - xmin);
		fnewHeight /= 2;
		ymax = fnewHeight;
		ymin = -fnewHeight;
	}

	//Set viewport variables
	winXmin = _winXmin;
	winXmax = _winXmax, 
	winYmin = _winYmin;
	winYmax = _winYmax;


	defineMatrices(projection_type);
	return true;
}


void cCamera::addTosGlobalScale(float _scaleIncrement)
{
	globalScale += _scaleIncrement;

	if(globalScale <= 0)
		globalScale = 0;
}

void cCamera::addToGlobalPan(float _panX, float _panY, float _panZ)
{
	panX += _panX;
	panY += _panY;
	panZ += _panZ;
}
void cCamera::setToGlobalPan(vec3 &oldValues, float _panX, float _panY, float _panZ)
{
	oldValues[0] = panX;
	oldValues[1] = panY;
	oldValues[2] = panZ;

	panX = _panX;
	panY = _panY;
	panZ = _panZ;

}
void cCamera::addToGlobalRotateDegrees(float rx, float ry, float rz)
{
	//First create rotation matricies for the x,y,z axis

	//Limit to 0-360
	if(rx >= 360)
		rx -= 360;
	if(ry >= 360)
		ry -= 360;
	if(rz >= 360)
		rx -= 360;

	//Convert to radians
	rx *= DEGTORAD;
	ry *= DEGTORAD;
	rz *= DEGTORAD;

	//Create the matrix for rot. x,y,z
	float Rotation_X[4][4] =
	{
		{1,			0,			0,			0},
		{0,			cos(rx),	-sin(rx),	0},
		{0,			sin(rx),	cos(rx),	0},
		{0,			0,			0,			1}
	};

	float Rotation_Y[4][4] =
	{
		{cos(ry),	0,			sin(ry),	0},
		{0,			1,			0,			0},
		{-sin(ry),	0,			cos(ry),	0},
		{0,			0,			0,			1}
	};

	float Rotation_Z[4][4] =
	{
		{cos(rz),	-sin(rz),	0,			0},
		{sin(rz),	cos(rz),	0,			0},
		{0,			0,			1,			0},
		{0,			0,			0,			1}
	};

	//Multiply the matricies now
	float tempMatrix[4][4];

	//Equation to calculate: dynamicRotation =	rxM	*	ryM	*	rzM	*	dynamicRotation
	multiply(Rotation_X, Rotation_Y, tempMatrix);
	multiply(tempMatrix, Rotation_Z, Rotation_X);
	multiply(Rotation_X, Dynamic_Rotation, tempMatrix);

	//cout << "\nInital Matrix:\n";
	//showMatrix(std::cout, tempMatrix);

	for(int y = 0; y < 4; y++)
		for(int x = 0; x < 4; x++)
			Dynamic_Rotation[y][x] = tempMatrix[y][x];

	//cout << "\After Matrix:\n";
	//showMatrix(std::cout, Dynamic_Rotation);

}

bool cCamera::ResetCamera()
{
	cout << "Resetting Camera!\n";
	_up_vector = cryph::AffVector(0, 1, 0);
	_center_of_attention = cryph::AffVector(0, 0, 0);
	//_eye_point = cryph::AffVector(0.5, 0.5, 1);
	_eye_point = cryph::AffVector(0.0, 0.0, 1.0);
			
	//Calculate distance from eye to center
	cryph::AffVector tempVector = cryph::AffVector(_eye_point - _center_of_attention);
	distanceEyeCenter = tempVector.length();

	//Define projection type: true = perspective and false = ortho
	projection_type = true;
			
	//zpp = -1.5;
	zpp = -1.5;
	zmin = -2;
	zmax = -0.1;
	xmin = ymin = -4;
	xmax = ymax = 4;
		
	//Initalize camera variables
	panX = panY = panZ = 0;
	globalScale = 1.1; scaleIncrement = 0.1;

	//Create dynamic rotation matrix to identity
	Dynamic_Rotation[0][0] = 1; Dynamic_Rotation[0][1] = 0; Dynamic_Rotation[0][2] = 0; Dynamic_Rotation[0][3] = 0;
	Dynamic_Rotation[1][0] = 0; Dynamic_Rotation[1][1] = 1; Dynamic_Rotation[1][2] = 0; Dynamic_Rotation[1][3] = 0;	
	Dynamic_Rotation[2][0] = 0; Dynamic_Rotation[2][1] = 0; Dynamic_Rotation[2][2] = 1; Dynamic_Rotation[2][3] = 0;	
	Dynamic_Rotation[3][0] = 0; Dynamic_Rotation[3][1] = 0; Dynamic_Rotation[3][2] = 0; Dynamic_Rotation[3][3] = 1;

	//Default is perspective
	defineMatrices(true);

	addToGlobalRotateDegrees(0, -90, 0);
	addTosGlobalScale(-1);

	return true;
}

bool cCamera::defineMatrices(bool projection)
{
	//Set projection local var
	projection_type = projection;

 	//Define the model view matrix
	cryph::AffVector direction = _eye_point - _center_of_attention;
	direction.normalize();
 
    cryph::AffVector side = direction.cross(_up_vector);
	side.normalize();
 
	cryph::AffVector up = side.cross(direction);
	up.normalize();
	
	/*
	float M4x4[4][4] =
	{
		{side[0], up[0], -direction[0], 0},
		{side[1], up[1], -direction[1], 0},
		{side[2], up[2], -direction[2], 0},
		{-_eye_point[0], -_eye_point[1], -_eye_point[2], 1}
	};
	 */
	
	float wcToECMatrix[4][4] =
	{
		{up[0], up[1], up[2], -_eye_point[0]},
		{side[0], side[1], side[2], -_eye_point[1]},
		{direction[0], direction[1], direction[2], -_eye_point[2]},
		{0, 0, 0, 1}
	};
	
	//Adding code here that will handle the panning, zooming, and rotation
	
	//First define variables and matricies
	float Dynamic_Matrix[4][4];
	
	float Pan_Matrix[4][4] =
	{
		{1,			0,			0,			panX},
		{0,			1,			0,			panY},
		{0,			0,			1,			panZ},
		{0,			0,			0,			1}
	};

	float PostTranslation_Matrix[4][4] =
	{
		{1,			0,			0,			0},
		{0,			1,			0,			0},
		{0,			0,			1,			-distanceEyeCenter},
		{0,			0,			0,			1}
	};

	float Scale_Matrix[4][4] =
	{
		{globalScale,	0,				0,				0},
		{0,				globalScale,	0,				0},
		{0,				0,				globalScale,	0},
		{0,				0,				0,				1}
	};

	float PreTranslation_Matrix[4][4] =
	{
		{1,			0,			0,			0},
		{0,			1,			0,			0},
		{0,			0,			1,			distanceEyeCenter},
		{0,			0,			0,			1}
	};

	//Implement the following matrix operations: dynamic =	P	*	Tpost *	dynamicRotation	*	S	*	Tpre
	float tempMatrix[4][4];

	multiply(Pan_Matrix, PostTranslation_Matrix, tempMatrix);
	multiply(tempMatrix, Dynamic_Rotation,  Pan_Matrix);
	multiply(Pan_Matrix, Scale_Matrix, tempMatrix);
	multiply(tempMatrix, PreTranslation_Matrix, Dynamic_Matrix);
	
	//Now multiply dynamic by the world to eye coordinate matrix
	multiply(Dynamic_Matrix, wcToECMatrix, tempMatrix);
	

//		cout << "\nModelview Matrix:\n";
	//showMatrix(std::cout, tempMatrix);

	//Copy tempMatrix into the real modelViewMatrix that will go to shader
	for(int y = 0; y < 4; y++)
		for(int x = 0; x < 4; x++)
			modelViewMatrix[(y*4)+x] = tempMatrix[y][x];

//	cout << "\nModelview Matrix:\n";
//	showMatrix(std::cout, tempMatrix);

	//define the normal matrix
	float M3x3Inv[3][3], M3x3[3][3], M3x3InvTranspose[3][3];
	upper3x3(tempMatrix, M3x3);
	if(inverse(M3x3, M3x3Inv))
		transpose(M3x3Inv, M3x3InvTranspose);
	else
	{
		cout << "Couldnt find an inverse for the modelview matrix\n";
		return false;
	}

	for(int y = 0; y < 3; y++)
		for(int x = 0; x < 3; x++)
			normalMatrix[(y*3)+x] = M3x3InvTranspose[y][x];
	
//	cout << "\nNormal Matrix:\n";
//	showMatrix(std::cout, M3x3InvTranspose);

	//define the projection matrix
	if(projection == true) //this is for perspective projection
	{
		float Perspective_M4x4[4][4] =
		{
			{ (-2*(zpp/(xmax-xmin))) , 0, ((xmax+xmin)/(xmax-xmin)) , 0},
			{0, -2*(zpp/(ymax-ymin)) , ((ymax+ymin)/(ymax-ymin)) , 0},
			{0, 0, ((zmax+zmin)/(zmax-zmin)) , -2*((zmin*zmax)/(zmax-zmin)) },
			{0, 0, -1, 0}
		};
		
		//DEBUGME: **!
		for(int y = 0; y < 4; y++)
			for(int x= 0; x < 4; x++)
				projectionMatrix[(y*4)+x] = Perspective_M4x4[y][x];
		
	//	cout << "\nPerspective Matrix:\n";
	//	showMatrix(std::cout, Perspective_M4x4);
	}
	else
	{
		//This is for ortho projection
		float Ortho_M4x4[4][4] =
		{
			{2/(xmax-xmin), 0, 0, (xmax+xmin)/(-xmax+xmin)},
			{0, 2/(ymax-ymin), 0, (ymax+ymin)/(-ymax+ymin)},
			{0, 0, -2/(zmax-zmin), (zmax+zmin)/(zmax-zmin)},
			{0, 0, 0, 1}
		};

		for(int y = 0; y < 4; y++)
			for(int x= 0; x < 4; x++)
				projectionMatrix[(y*4)+x] = Ortho_M4x4[y][x];
		
	//	cout << "\nOrtho Matrix:\n";
	//	showMatrix(std::cout, Ortho_M4x4);
	}


	
	return true;
}


bool cCamera::getMatrices(GLfloat *_modelViewMatrix, GLfloat *_normalMatrix, GLfloat *_projectionMatrix)
{
	for(int x = 0; x < 16; x++)
	{
		_modelViewMatrix[x] = modelViewMatrix[x];
		_projectionMatrix[x] = projectionMatrix[x];
	}
	
	for(int x = 0; x < 9; x++)
		_normalMatrix[x] = normalMatrix[x];

	return true;
}

//Taken from Mesa3D source code, and implmentation for gluUnProject

GLint cCamera::gluUnProject(GLfloat winx, GLfloat winy, GLfloat winz, GLfloat *objx, GLfloat *objy, GLfloat *objz)
{
    //double finalMatrix[16];
    float in[3];
    float out[3];

	//Convert [16] to [4][4] to use with functions
	float projMatrix[4][4], modelMatrix[4][4], finalMatrix[4][4];
	float tempMatrix[3][3], tempMatrixInverse[3][3];
	
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			modelMatrix[i][j] = modelViewMatrix[(i*4)+j];
			projMatrix[i][j] = projectionMatrix[(i*4)+j];
		}
	}


    multiply(modelMatrix, projMatrix, finalMatrix);


	upper3x3(finalMatrix, tempMatrix);
	if(!inverse(tempMatrix, tempMatrixInverse))
	{
		cout << "gluUnProject: Couldnt find an inverse for the finalmatrix matrix\n";
		return false;
	}


    in[0]=winx;
    in[1]=winy;
    in[2]=winz;
//    in[3]=1.0;

    /* Map x and y from window coordinates */
    in[0] = (in[0] - winXmin) / winXmax;
    in[1] = (in[1] - winYmin) / winYmax;

    /* Map to range -1 to 1 */
    in[0] = in[0] * 2 - 1;
    in[1] = in[1] * 2 - 1;
    in[2] = in[2] * 2 - 1;

   // multiply(tempMatrixInverse, in, out);
	out[0] = tempMatrixInverse[0][0]*in[0] + tempMatrixInverse[0][1]*in[0] + tempMatrixInverse[0][2]*in[0];
	out[1] = tempMatrixInverse[1][0]*in[1] + tempMatrixInverse[1][1]*in[1] + tempMatrixInverse[1][2]*in[1];
	out[2] = tempMatrixInverse[2][0]*in[2] + tempMatrixInverse[2][1]*in[2] + tempMatrixInverse[2][2]*in[2];

    //if (out[3] == 0.0) return(GL_FALSE);
   
	//out[0] /= out[3];
    //out[1] /= out[3];
    //out[2] /= out[3];
    *objx = out[0];
    *objy = out[1];
    *objz = out[2];
    return(GL_TRUE);
}
