//Matt H 11/26/2011
//Camera class

#ifndef __CAMERA__
#define __CAMERA__

#include "Externals.h"
//#include "ModelView.h"

//Include points/vector/matrix stuff
#include "AffPoint.h"
#include "AffVector.h"
#include "MatrixUtil.h"

typedef GLfloat vec2[2]; // or use Angel's definitions
typedef GLfloat vec3[3]; // or use Angel's definitions
typedef GLfloat vec4[4]; // or use Angel's definitions

using namespace cryph;

class cCamera
{
	public:
		cCamera()
		{
			_up_vector = cryph::AffVector(0, 1, 0);
			_center_of_attention = cryph::AffVector(0, 0, 0);
			//_eye_point = cryph::AffVector(0.5, 0.5, 1);
			_eye_point = cryph::AffVector(0.0, 0.0, 1.0);
			
			//Calculate distance from eye to center
			cryph::AffVector tempVector = cryph::AffVector(_eye_point - _center_of_attention);
			distanceEyeCenter = tempVector.length();

			//Define projection type: true = perspective and false = ortho
			projection_type = true;
			
			//zpp = -1.5;
			zpp = -1.5;
			zmin = -2;
			zmax = -0.1;
			xmin = ymin = -4;
			xmax = ymax = 4;
			
			/*	_up_vector = cryph::AffVector(0, 1, 0);
			_center_of_attention = cryph::AffVector(0, 0, 0);
			//_eye_point = cryph::AffVector(0.5, 0.5, 1);
			_eye_point = cryph::AffVector(0, 0, 1.9);

			
				_up_vector = cryph::AffVector(0, 1, 0);
			_center_of_attention = cryph::AffVector(0, 0, 0);
			//_eye_point = cryph::AffVector(0.5, 0.5, 1);
			_eye_point = cryph::AffVector(0, 0, 0.8);
			

			
			//Calculate distance from eye to center
			cryph::AffVector tempVector = cryph::AffVector(_eye_point - _center_of_attention);
			distanceEyeCenter = tempVector.length();

			//Define projection type: true = perspective and false = ortho
			projection_type = true; 
				
			//Define viewing 
		/*	zpp = -26;
			zmin = -100;
			zmax = -25.0;

			xmax = 50;
			xmin = -50;

			ymin = -10;
			ymax = 10;
			*/
		/*	zpp = -20;
			zmin = -50;
			zmax = -25.0;

			xmax = 25;
			xmin = -25;

			ymin = -10;
			ymax = 10;
*/


			/*
			//Define viewing 
			zpp = -1.5;
			zmin = -2;
			zmax = -0.1;
			xmin = ymin = -2;
			xmax = ymax = 2;
			*/
			/* Ortho View: _up_vector = cryph::AffVector(0, 1, 0); _center_of_attention = cryph::AffVector(200, 500, 0); _eye_point = cryph::AffVector(100, -1100/2, 200); */
			/*
			_up_vector = cryph::AffVector(0, 1, 0);
			_center_of_attention = cryph::AffVector(0, 0, 0);
			_eye_point = cryph::AffVector(0, 1, 1);

			//Define projection type: true = perspective and false = ortho
			projection_type = false;
	
			//Define viewing 
			zpp = -1;
			zmin = -5;
			zmax = 5;
			xmin = ymin = -5;
			xmax = ymax = 5;
			*/
					
			//Initalize camera variables
			panX = panY = panZ = 0;
			globalScale = 1.1; scaleIncrement = 0.1;

			//Create dynamic rotation matrix to identity
			Dynamic_Rotation[0][0] = 1; Dynamic_Rotation[0][1] = 0; Dynamic_Rotation[0][2] = 0; Dynamic_Rotation[0][3] = 0;
			Dynamic_Rotation[1][0] = 0; Dynamic_Rotation[1][1] = 1; Dynamic_Rotation[1][2] = 0; Dynamic_Rotation[1][3] = 0;	
			Dynamic_Rotation[2][0] = 0; Dynamic_Rotation[2][1] = 0; Dynamic_Rotation[2][2] = 1; Dynamic_Rotation[2][3] = 0;	
			Dynamic_Rotation[3][0] = 0; Dynamic_Rotation[3][1] = 0; Dynamic_Rotation[3][2] = 0; Dynamic_Rotation[3][3] = 1;
		};

		~cCamera()
		{

		};

		//Singleton
		static cCamera *Get()
		{
			if(!Instance)
				Instance = new cCamera;
			return Instance;
		};

		bool getMatrices(GLfloat *_modelViewMatrix, GLfloat *_normalMatrix, GLfloat *_projectionMatrix);
		bool defineMatrices(bool projection);

		//Interface functions to change internal variable such as pan, scale/Rotation
		void addTosGlobalScale(float _scaleIncrement);
		void addToGlobalPan(float _panX, float _panY, float _panZ);
		void addToGlobalRotateDegrees(float rx, float ry, float rz);

		//Manually set 
		void setToGlobalPan(vec3 &oldValues, float _panX, float _panY, float _panZ);

		//Aspect ratio
		bool AdjustAspectRatio(float fVPAspectRatio, float _winXmin, float _winXmax, float _winYmin, float _winYmax);

		//Taken from mesa3d implementation for gluUnproject
		GLint gluUnProject(GLfloat winx, GLfloat winy, GLfloat winz, GLfloat *objx, GLfloat *objy, GLfloat *objz);

		bool projection_type, current_projection_type; //false = ortho and true = perspective
		GLfloat zpp, xmin, xmax, ymin, ymax, zmin, zmax;

		//define for affine class types
		cryph::AffVector _eye_point, _center_of_attention, _up_vector;

		bool ResetCamera();
	private:
		static cCamera *Instance;

		//Camera definitions
		float Dynamic_Rotation[4][4];

		float panX, panY, panZ;
		float globalScale, scaleIncrement;
		float distanceEyeCenter;

		GLfloat modelViewMatrix[16];
		GLfloat projectionMatrix[16];
		GLfloat normalMatrix[9];



		vec3 eye_point, center_of_attention, up_vector;

		float winXmin, winXmax, winYmin, winYmax;
};









#endif