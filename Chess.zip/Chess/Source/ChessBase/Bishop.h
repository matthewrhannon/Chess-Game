//Board 7/20/11 

#ifndef _BISHOP_
#define _BISHOP_

#include "Main.h"

#include "Log.h"
#include "Vector.h"
#include "Board.h"
#include "ChessBlocks.h"
#include "Pieces.h"

class cPiece;
class cChessBoard;
class cChessBlock;

class cBishop : public cPiece 
{
public:
	friend class cChessBlock;
	friend class cChessBoard;
	
	cBishop() : cPiece(UNKNOWN, "UNKNOWN BISHOP COLOR")
	{
		PieceIdentifier = (int)Bishop_Piece_Count--;
		PieceValue = GENERIC_BISHOP_VALUE;

		CLog::Get()->WriteError("cBishop_Constructor: Called without specifying color of bishop piece...Assuming white!");
		bWhiteBishop = true;
	};
	
	cBishop(bool bWhite) : cPiece(BISHOP, "Bishop")
	{
		PieceIdentifier = (int)Bishop_Piece_Count--;
		PieceValue = GENERIC_BISHOP_VALUE;

		bWhiteBishop = bWhite; 

		//Two separate bitboards for the black and white bishops
		if(!bWhite_BitBoard_Built)
		{
			Initalize();	
			bWhite_BitBoard_Built = true;
		}
		
		/*if(!bBlack_BitBoard_Built)
		{
			Initalize();	
			bBlack_BitBoard_Built = true;
		}
		*/
	}

	virtual ~cBishop() 
	{
		Deinitalize();
	};

	bool Initalize()
	{
		//////////////////////////////////////////////////////////////
		//Bitboard stuff
		//////////////////////////////////////////////////////////////

		//Initalize 64 bitboards for the rook (?is this even a efficient way to do this?)
		cBitboard *tempBitBoard = new cBitboard[64];

		UINT uTempPos = 0;

		xPiecePos = yPiecePos = 1;

		//Loop through each of the 64 bitboards for the rook potential locations
		for(yPiecePos = 1; yPiecePos <= 8; yPiecePos++)
		{
			for(xPiecePos = 1; xPiecePos <= 8; xPiecePos++)
			{
				//Update piece to next location
				uTempPos = (((yPiecePos-1)*8)+(xPiecePos-1));

				//Loop through each square, and generate bitboards that represent potentially valid moves
				for(UINT cur_Y = 1; cur_Y <= 8; cur_Y++)
				{
					for(UINT cur_X = 1; cur_X <= 8; cur_X++)
					{
						//Lets start by running through one rook pattern, say x = y = 1 Position placement of rook, and find potential movements
						if( Movement(cur_X, cur_Y) == 1 )
						{	//Success move
							tempBitBoard[uTempPos].SetBit(cur_X, cur_Y);
						}
					}
				}

				//Test if same square as position being tested
				//if( (xPiecePos != cur_X) && (yPiecePos != cur_Y) )
				tempBitBoard[uTempPos].ResetBit(xPiecePos, yPiecePos);
				//	tempBitBoard[uTempPos].Drawboard();
				//	cout << "\n"; Note: Looks good to me by initial inspection
			}
		}

	//	if(bWhiteBishop)
			White_Bishop_BitBoards = tempBitBoard;
	//	else
			Black_Bishop_BitBoards = tempBitBoard;


		//REMEMBERME: Remember to reset x/y position values after all this!
		xPiecePos = yPiecePos = 1;

		return true;
	};

	bool Deinitalize()
	{
		Type = UNKNOWN;

		bWhite_BitBoard_Built = false;
		bBlack_BitBoard_Built = false;

		SafeDelete(White_Bishop_BitBoards);
		SafeDelete(Black_Bishop_BitBoards);

		return true;
	};


	UINT Movement(UINT xPos, UINT yPos)
	{

		//Bishop: absolute slope of 1 to 1 for vertical movement
		//		  First is it it on white on black?
		//		  tan(45) = 1 therefore if not normal dot product, could be valid?

		//First test color and color of block for validity

		if(cChessBoard::BoundsChecker(xPos, yPos))
		{ 
			/* FIXME!!! Doesn't work right. It strafes the xPos
			//Make sure bishop is moving to valid color
			if(cChessBoard::GetBlockColor(xPos, yPos) != bWhiteBishop)
			{ 
				#if (BUILD_TYPE == DEBUG_MODE)
					CLog::Get()->WriteError("Bishop_Movement: Problem identifying bishop and color");
				#endif
				return 0;
			}
			*/
			//Now test if it is on a proper line of direction
			cVector vNewPos(xPos, yPos, 0);
			cVector vCurPos(xPiecePos, yPiecePos, 0);

			cVector vDelta = vNewPos.Subtract(vCurPos);

			//Normalize stuff
			vDelta.Normalize();

			//FIXME For team FIX ME!
			float fTemp = 0;
			//if(bWhiteBishop)
				fTemp = 1;
		//	else
			//	fTemp = -1;

			cVector vCompare(0, fTemp, 0);
			vCompare.Normalize();

			//Dot them and look for proper angle
			float fDotty = vCompare.Dot(vDelta);

			if( (abs(fDotty) >= abs(cos(DEG2RAD(45.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(45.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
			{ //I think we have a valid move so far....
				return 1;
			}
			else if( (abs(fDotty) >= abs(cos(DEG2RAD(135.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(135.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
			{ //I think we have a valid move so far....
				return 1;
			}
			else if( (abs(fDotty) >= abs(cos(DEG2RAD(225.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(225.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
			{ //I think we have a valid move so far....
				return 1;
			}
			else if( (abs(fDotty) >= abs(cos(DEG2RAD(315.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(315.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
			{ //I think we have a valid move so far....
				return 1;
			}
			else
			{
				#if (BUILD_TYPE == DEBUG_MODE)
					CLog::Get()->WriteError("Bishop_Movement: Dot product doesn't match - fDotty: %f", fDotty);
				#endif
			
				return 0;
			}
		
			return 0;
		}
		else
		{
			CLog::Get()->WriteError("Bishop_Movement: Outside boundaries");
			return 0;
		}

		//Invalid move
		return 0;
	};

	UINT Action()
	{

		return 1;
	};

	UINT Special()
	{

		return 1;
	};		

	bool bWhiteBishop; //Bishop can only move on white or black based on start of game position

	//Need to have two bitboards for bishop due to color restrictions
	static cBitboard *White_Bishop_BitBoards;
	static cBitboard *Black_Bishop_BitBoards;
	static bool bWhite_BitBoard_Built, bBlack_BitBoard_Built;

private:




};

cBitboard *cBishop::White_Bishop_BitBoards = NULL;
cBitboard *cBishop::Black_Bishop_BitBoards = NULL;
bool cBishop::bWhite_BitBoard_Built = false;
bool cBishop::bBlack_BitBoard_Built = false;

#endif