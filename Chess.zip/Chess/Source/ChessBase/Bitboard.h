//Bitboards 7/25/11

#ifndef _BITBOARD_
#define _BITBOARD_

#include "Main.h"

//Plan: Need to have bit boards for:
//		All_Piece_Locations, All_White_Locations, All_Black_Locations
//		White/Black_Pawns/Bishops/Rooks/Knights/King/Queen -- Locations
//		White/Black_Pawns/Bishops/Rooks/Knights/King/Queen -- Potential Move Locations
//      Can use bitwise sort later for tree search of move calculations
//		Plan: As for now, build proper bit functions to manage the bit boards efficiently
//			  and maybe use the already written movement code to pre-generate bit boards for each block and corresponding piece?

//Little Endian	- x86 - (Low address) least significant byte ... (High adders) most significant byte
/*
	00000000
	00000000
	00000000
	00000000
	00000000
	00000000
	00000000
	00000000
*/

//Note: A bit of chess lingo
//	File == columns (ie A1-A8 etc)
//	Rank == rows	(ie A1-F1 etc)


class cBitboard
{
	public:
		cBitboard()
		{
			BitBoard = 0x00ULL;
		};

		cBitboard(QWORD InputBoard)
		{
			BitBoard = InputBoard;
		};

		~cBitboard()
		{
		};

		//Sets/Gets
		void ResetBoard()
		{
			BitBoard = 0x00ULL;
		};

		void SetBoard(QWORD InputBoard)
		{
			BitBoard = InputBoard;
		};

		QWORD AND_BitBoard(cBitboard InputBitboard)
		{
			BitBoard &= InputBitboard.GetBoard();
			return BitBoard;
		};

		QWORD OR_BitBoard(cBitboard InputBitboard)
		{
			BitBoard |= InputBitboard.GetBoard();
			return BitBoard;
		};

		QWORD GetBoard()
		{
			return BitBoard;
		};

		bool SetBit(UINT xPos, UINT yPos)
		{
			static int uTemp = 0, Rank = 0, File = 0;

			//First check bounds
			if((xPos >= 1) && (xPos <= 8))
				if((yPos >= 1) && (yPos <= 8))
					goto Valid_Bounds;
				else
					goto Invalid_Bounds;
			else
				goto Invalid_Bounds;

			Invalid_Bounds:
				CLog::Get()->WriteError("cBitboard_SetBit: Out of bounds error");
				return false;

			Valid_Bounds:

			if( (xPos == 1) && (yPos == 1) )
				BitBoard |= 1ULL;
			else if( (xPos == 8) && (yPos == 8) )
				BitBoard |= (QWORD)((0x0000000000000001ULL) << ((64-1)));//BBSQUARE[64-1];//(QWORD)(0x8000000000000000ULL);//	//BitBoard |= (QWORD)( (0000000000000001) << ((62)-1) );//
			else if( (yPos == 1) )
				BitBoard |= (QWORD)( (0000000000000001ULL) << ((xPos)-1) );
			else if( (xPos == 1) )
				BitBoard |= (QWORD)( (0000000000000001ULL) << ( ((yPos-1)*8)) );
			else
				BitBoard |= (QWORD)( (0000000000000001ULL) << ( (((yPos-1)*8) + (xPos-1) )));
			
			return true;
		};

		bool ResetBit(UINT xPos, UINT yPos)
		{
			static int uTemp = 0, Rank = 0, File = 0;

			//First check bounds
			if((xPos >= 1) && (xPos <= 8))
				if((yPos >= 1) && (yPos <= 8))
					goto Valid_Bounds;
				else
					goto Invalid_Bounds;
			else
				goto Invalid_Bounds;

			Invalid_Bounds:
			CLog::Get()->WriteError("cBitboard_ResetBit: Out of bounds error");
			return false;

			Valid_Bounds:
		
			if( (xPos == 1) && (yPos == 1) )
				BitBoard &= ~1ULL;
			else if( (xPos == 8) && (yPos == 8) )
				BitBoard &= ~(QWORD)((0x0000000000000001ULL) << ((64-1)));//BBSQUARE[64-1];//(QWORD)(0x8000000000000000ULL);//	//BitBoard |= (QWORD)( (0000000000000001) << ((62)-1) );//
			else if( (yPos == 1) )
				BitBoard &= ~(QWORD)( (0000000000000001ULL) << ((xPos)-1) );
			else if( (xPos == 1) )
				BitBoard &= ~(QWORD)( (0000000000000001ULL) << ( ((yPos-1)*8)) );
			else
				BitBoard &= ~(QWORD)( (0000000000000001ULL) << ( (((yPos-1)*8) + (xPos-1) )));

			return true;
		};

		bool TestBit(UINT xPos, UINT yPos)
		{
			static int uTemp = 0, Rank = 0, File = 0;

			//First check bounds
			if((xPos >= 1) && (xPos <= 8))
				if((yPos >= 1) && (yPos <= 8))
					goto Valid_Bounds;
				else
					goto Invalid_Bounds;
			else
				goto Invalid_Bounds;

			Invalid_Bounds:
			CLog::Get()->WriteError("cBitboard_TestBit: Out of bounds error");
			return false;

			Valid_Bounds:

			if( (xPos == 1) && (yPos == 1) ) 
			{
				if(BitBoard & 1ULL)
				{
					return true;
				}
				else
					return false;
			}
			else if( (xPos == 8) && (yPos == 8) )
			{
				if((BitBoard & ((QWORD)((0x0000000000000001ULL) << ((64-1))))))//BBSQUARE[64-1];//(QWORD)(0x8000000000000000ULL);//	//BitBoard |= (QWORD)( (0000000000000001) << ((62)-1) );//
				{
					return true;
				}
				else
					return false;
			}
			else if( (yPos == 1) )
			{
				if((BitBoard & ((QWORD)( (0000000000000001ULL) << ((xPos)-1) ))))
				{
					return true;
				}
				else
					return false;
			}
			else if( (xPos == 1) )
			{
				if((BitBoard & ((QWORD)( (0000000000000001ULL) << ( ((yPos-1)*8)) ))))
				{
					return true;
				}
				else
					return false;
			}
			else if(BitBoard & ((QWORD)( (0000000000000001ULL) << ( (((yPos-1)*8) + (xPos-1) )))))
			{
					return true;
			}
			else
			{
				#if (BUILD_TYPE == DEBUG_MODE)
					CLog::Get()->WriteError("BitBoard_TestBit: How did we get here? Specified bit is not selected.");
				#endif
			
				return false;
			}

			CLog::Get()->WriteError("BitBoard_TestBit: Should never reach this point. Therefore unknown error?... xPos: %d yPos %d", xPos, yPos);
			return false;
		};

		void Drawboard()
		{
			static UINT uTemp = 0, Rank = 0, File = 0;

			//Loop through each square, and generate bitboards that represent potentially valid moves
			for(UINT cur_Y = 8; cur_Y >= 1; cur_Y--)
			{
				cout << "\n";

				for(UINT cur_X = 1; cur_X <= 8; cur_X++)
				{
					uTemp = (((cur_Y)*8)+(cur_X));

					/* Obsolete
					if(uTemp > 8)
					{
						Rank  = UINT(uTemp / 8);
						File  = UINT(uTemp % 8);

					}
					else
					{
						Rank = 1;
						File = uTemp;
					}
					*/
					//This bit is on, so display it
				//	if(BitBoard & (QWORD)(1<<( (Rank*File)-1) ))
					if(BitBoard & (QWORD)( (0000000000000001ULL) << ( (((cur_Y-1)*8) + (cur_X-1) ))) )
						cout << "1";
					else
						cout << "0";
				}
			}
		};

	private:


		QWORD BitBoard;

};




#endif