//Board 7/23/11
#include "Board.h"

#include "Pawn.h"
#include "Bishop.h"
#include "Knight.h"
#include "King.h"
#include "Queen.h"
#include "Rook.h"

cChessBlock *cChessBoard::ChessBlocks = NULL;
cPiece **cChessBoard::DeadChessPieces = NULL;
UINT cChessBoard::DeadPieceCounter = 0;

bool cChessBoard::InitalizeBoard()
{
	//Initalize total piece values for each white/black team
	TotalWhiteValue = TotalBlackValue = Backup_TotalWhiteValue = Backup_TotalBlackValue = 0;

	//Initalize memory for each of the 8x8 blocks
	if(ChessBlocks != NULL)
	{
		CLog::Get()->WriteError("InitalizeBoard: Chessblock memory has already been initialized...Weird error.");
		return false;
	}

	ChessBlocks = new cChessBlock[64];

	if(!ChessBlocks)
	{
		CLog::Get()->WriteError("InitalizeBoard: Couldn't initialize memory for chess blocks!");
		return false;
	}

	if(DeadChessPieces != NULL)
	{
		CLog::Get()->WriteError("InitalizeBoard: DeadChessPieces memory has already been initialized...Weird error.");
		return false;
	}

	//Initalize dead pieces to default unknown piece type
	DeadChessPieces = new cPiece*[32];
	
	if(!DeadChessPieces)
	{
		CLog::Get()->WriteError("InitalizeBoard: Couldn't initialize memory for DeadChessPieces!");
		return false;
	}

	//NULL out the dead piece pointers
	for(int tempX = 0; tempX < 32; tempX++)
		DeadChessPieces[tempX] = NULL;

	//Now need to fill in each chess block with appropriate data
	cChessBlock *tempBlock;
	bool bWhiteTeam = true; //Temp for specifying in Piece class

	//Fill in board with generic
	for(UINT y = 1; y <= 8; y++)
	{
		for(UINT x = 1; x <= 8; x++)
		{
			tempBlock = GetBlockData(x, y);
			tempBlock->xPos = x;
			tempBlock->yPos = y;

			if( (y == 1) || (y == 8) )
				tempBlock->bTopBottomPos = true;
			else
				tempBlock->bTopBottomPos = false;

			tempBlock->bColored = GetBlockColor(x, y); //Sets white or black color to block

			if( (x == 5) && (y == 1) )
				tempBlock->Attributes |= 1 << 2; //King
			else if( (x == 5) && (y == 8) )
				tempBlock->Attributes |= 1 << 2; //King
			else
				tempBlock->Attributes &= ~(1 << 2); //Do not set king bit
			
			if( (y > 2) && (y < 7) )
			{
				tempBlock->Attributes |= 1 << 0; //Neutral
			}
			else if(y <= 2)
			{ 
				bWhiteTeam = true;
				tempBlock->bWhite_Black = true;
			
				tempBlock->Attributes |= 1 << 1;  //White
			}
			else if(y >= 7)
			{ 
				bWhiteTeam = false;
				tempBlock->bWhite_Black = false;
				
				tempBlock->Attributes &= ~(1 << 1); //Black
			}

			//Now lets work on initializing the proper piece based on position

			//Initalize actual piece for block now
			PIECE_TYPE tempType = GetPieceType(tempBlock->xPos, tempBlock->yPos);
			if(tempType == UNKNOWN)
			{
				CLog::Get()->WriteError("InitalizeBoard: Call to GetPieceType failed returning UNKNOWN");
				return false;
			}

			if(tempType == PAWN)
				tempBlock->Piece = new cPawn(tempBlock->bWhite_Black);//dynamic_cast<cPiece*>((new cPawn));
			else if(tempType == KNIGHT)
				tempBlock->Piece = new cKnight();
			else if(tempType == BISHOP)
				tempBlock->Piece = new cBishop(tempBlock->bWhite_Black);//GetBlockColor(x, y));
			else if(tempType == KING)
				tempBlock->Piece = new cKing();
			else if(tempType == QUEEN)
				tempBlock->Piece = new cQueen();
			else if(tempType == ROOK)
				tempBlock->Piece = new cRook();
			else if(tempType == EMPTY)
				tempBlock->Piece = new cPiece(EMPTY, "Empty");
			else
			{
				CLog::Get()->WriteError("InitalizeBoard: Error while picking type of piece to create for block");
			}

			if(!tempBlock->Piece)
			{
				CLog::Get()->WriteError("InitalizeBoard: Couldn't initialize memory for chess piece inside block!");
				return false;
			}

			//Set the piece position
			tempBlock->Piece->xPiecePos = x;
			tempBlock->Piece->yPiecePos = y;

		
			if(tempBlock->bWhite_Black)
			{
				tempBlock->Piece->bTeamColor = true;
				TotalWhiteValue += tempBlock->Piece->PieceValue;
			}
			else
			{
				tempBlock->Piece->bTeamColor = false;
				TotalBlackValue += tempBlock->Piece->PieceValue;
			}

			//If reached here, the chess block has been initialized with proper piece
			
			//DELETE_ME: Now it is time to test if any of this code actually works!

			//TODO: Have another algorithm come through and connect the boxes that are related to the current one

			
			
		}
	}

	//Generate bitboards 

	//Plan: Need to have bit boards for:
	//		All_Piece_Locations, All_White_Locations, All_Black_Locations
	//		White/Black_Pawns/Bishops/Rooks/Knights/King/Queen -- Locations
	//		White/Black_Pawns/Bishops/Rooks/Knights/King/Queen -- Potential Move Locations
	//      Can use bitwise sort later for tree search of move calculations
	//		Plan: As for now, build proper bit functions to manage the bit boards efficiently
	//			  and maybe use the already written movement code to pre-generate bit boards for each block and corresponding piece?

	//0000000000000000000000000000000000000000000000000000000000000000

	//General piece locations for all/white/black
	Bit_All_Pieces = new cBitboard(0xFFFF00000000FFFFULL);
	Bit_White_Pieces = new cBitboard(0x000000000000FFFFULL);
	Bit_Black_Pieces = new cBitboard(0xFFFF000000000000ULL);

	//Pawns
	Bit_wPawn_Pieces = new cBitboard((0x000000000000FFFFULL << 8) & 0x000000000000FFFFULL);
    Bit_bPawn_Pieces = new cBitboard((0xFFFF000000000000ULL >> 8) & 0xFFFF000000000000ULL);

	//Bishops
	QWORD tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (1<<(0+3-1));
	tempQWord ^= (1<<(0+6-1));
	Bit_wBishop_Pieces = new cBitboard(tempQWord);

	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (QWORD)(0x0000000000000001ULL) << ((64-2) - 1); //Black bishop is 1 block right of rook; account for zero based value
	tempQWord ^= (QWORD)(0x0000000000000001ULL) << ((64-5) - 1); //Black bishop is 1 block left of rightmost rook; account for zero based value
	Bit_bBishop_Pieces = new cBitboard(tempQWord);
	
	//Knights
	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (1<<(0+2-1));
	tempQWord ^= (1<<(0+7-1));
	Bit_wKnight_Pieces = new cBitboard(tempQWord);

	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (QWORD)(0x0000000000000001ULL) << ((64-1) - 1);
	tempQWord ^= (QWORD)(0x0000000000000001ULL) << ((64-6) - 1);
	Bit_bKnight_Pieces = new cBitboard(tempQWord);

	//Rooks
	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (1<<(0+1-1));
	tempQWord ^= (1<<(0+8-1));
	Bit_wRook_Pieces = new cBitboard(tempQWord);

	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (QWORD)(0x0000000000000001ULL) << ((64-0) - 1);
	tempQWord ^= (QWORD)(0x0000000000000001ULL) << ((64-8) - 0); 
	Bit_bRook_Pieces = new cBitboard(tempQWord);
	
	//Queens
	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (0x0000000000000001ULL<<(0+4-1));
	Bit_wQueen_Piece = new cBitboard(tempQWord);

	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (QWORD)(0x0000000000000001ULL) << ((64-5) - 0); 
	Bit_bQueen_Piece = new cBitboard(tempQWord);

	//Kings
	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (0x0000000000000001ULL<<(0+5-1));
	Bit_wKing_Piece = new cBitboard(tempQWord);

	tempQWord = 0x0000000000000000ULL;
	tempQWord ^= (QWORD)(0x0000000000000001ULL) << ((64-4) - 0); 
	Bit_bKing_Piece = new cBitboard(tempQWord);

	//I think I can generate the bit boards on the fly with the movement routines from the pieces. 
	//Bit boards representing possible moves for each piece on the board  . Think I am going to start with rook generation, and then move
	//into pawn and rook verification of technique.

	//Bitboards completed for the pieces. 

	//Now lets implement the bitboards for the attack pieces
	
	tempQWord = 0x0000000000000000ULL;

	//Specific pieces
	
	//Plan: First get the bitboards that contain all the possible movements of the piece, the filter it for pieces of the other team that it can attack
	//		These movements that attack should be validated moves.


	//Note: Pawns have an exception, they can only move a specific way when they are attacking, other pieces attack with normal movements.
	//Note: There are number
	
	//Initalize memory for attack piece bitboards
	//Note: The higher number pieces are what I am calling white, and the lower are black.
	Bit_Pawn_Attack_Pieces = new cBitboard[16];
	Bit_Bishop_Attack_Pieces = new cBitboard[4];
	Bit_Knight_Attack_Pieces = new cBitboard[4];
	Bit_Rook_Attack_Pieces = new cBitboard[4];

	Bit_Queen_Attack_Pieces = new cBitboard[2];
	Bit_King_Attack_Pieces = new cBitboard[2];

	//Total attack bitboards for White and Black
	Bit_White_Attack_Pieces = new cBitboard;
	Bit_Black_Attack_Pieces = new cBitboard;

	//Loop through board, and create attack bitboards where pieces are located
	//Note: At the start of the game, there are no pieces that can directly attack other pieces. Therefore I think they should all be zero
	/*
	for(UINT x = 1; x <= 8; x++)
	{
		for(UINT y = 1; y <= 8; y++)
		{
			if(Bit_wBishop_Pieces->TestBit(x, y))
	










		}
	}

	*/
	cout << "\nTotal Piece Value: " << TotalWhiteValue << " " << TotalBlackValue << endl;
	return true;
};

UINT cChessBoard::VaildateCheckType(UINT xOldPos, UINT yOldPos, UINT xNewPos, UINT yNewPos)
{
	//Return Values:
	//		0 -- NoCheck
	//		1 -- Valid - Check Move
	//		2 -- Invalid - Movers King is in danger if move took place
	//		3 -- Valid - Checkmate
	//		4 -- Unknown type
	//		5 -- Error
	//		6 -- Invalid - By moving, the movers king is put into danger...
	//		FIXME: When king is suppose to move on turn, what if cant go anywhere.. draw... make code for this

	//Plan: Need to test both kings to see if in check.
	//		These structures are for the old and new blocks, nothing has been changed yet. The move is still considered in evaluation :)
	//		Test to see if in check for each king by using the attack bitboards against the black/white king, look for pattern.
	UINT uTempOld = (((yOldPos-1)*8)+(xOldPos-1));
	UINT uTempNew = (((yNewPos-1)*8)+(xNewPos-1));

	//Need to loop through each alive piece and check to see if their attack boards hit the king after the move would take place. 
	//need to check if by moving, the movers king is put in danger, and also if by moving the other king is in danger.

	bool bOldTeamColor = ChessBlocks[uTempOld].Piece->bTeamColor;
	bool bNewTeamColor = ChessBlocks[uTempNew].Piece->bTeamColor;

	//Test if attacking move
	bool bAttackPotentialMove = false;
	if(bOldTeamColor != bNewTeamColor)
		bAttackPotentialMove = true;

	//Test to see if the king is already in danger, if so, you can only move the king!
	//Or move a piece to protect the king

	bool IsProtectionMove = false;
	if(ChessBlocks[uTempOld].Piece->Type != KING)
	{
		if(bOldTeamColor) //For white old piece movement
		{
			//Check to see if the movers king is already in danger..
			if( (Bit_Black_Attack_Pieces->GetBoard() & Bit_wKing_Piece->GetBoard())  != 0 )
			{	
				IsProtectionMove = true;
				//CLog::Get()->Write("VaildateCheckType: Cannot move because the white king is in danger currently and white is trying to move!");
				//return 2;
			} 
		}
		else //For black old piece movement
		{
			//Check to see if the movers king is already in danger..
			if( (Bit_White_Attack_Pieces->GetBoard() & Bit_bKing_Piece->GetBoard()) != 0 )
			{	
				IsProtectionMove = true;
				//CLog::Get()->Write("VaildateCheckType: Cannot move because the black king is in danger currently and black is trying to move!");
				//return 2;
			}
		}
	}
	else
	{ 
		//REMOVE_ME: If here, then the piece being moved is the king. Here seems like a perfect place to test if the king is in check mate or not.

	}

	//If here, King is not currently in check, so lets now test to see if where we are going to move results in a check or not

	//Plan: Here test to see if the move will result in the movers king being put in check, and vice versa.
	//		This will be accomplished by using the Move function to move the piece, and then look at the moved attack bitboards
	//		I will use these to determine if the king of the movers will be put in danger. Then use the UndoMove function!
	
	//Implement the fore stated plan....
	{
		if(!Move(xOldPos, yOldPos, xNewPos, yNewPos))
		{
			CLog::Get()->WriteError("VaildateCheckType: Move() function failed!");
			return 5; //5 is for error
		}

		//Technically, if all is right, the attack bit boards should be updated as if this move has taken place.

		//Now test to see if the king is currently in check, and whether or not this movement will block this check
		if(IsProtectionMove)
		{
			if(bOldTeamColor) //For white old piece movement
			{
				//Check to see if the movers king is put into danger
				if( (Bit_Black_Attack_Pieces->GetBoard() & Bit_wKing_Piece->GetBoard())  != 0 )
				{	
					CLog::Get()->Write("VaildateCheckType: Cannot move because the white king is in danger currently and white is trying to move!");
					if(!UndoMove(xOldPos, yOldPos, xNewPos, yNewPos))
					{
						CLog::Get()->WriteError("VaildateCheckType: UndoMove() function failed!");
						return 5; //5 is for error
					}

					return 2;
				}
			}
			else //For black old piece movement
			{
				//Check to see if the movers king is already in danger..
				if( (Bit_White_Attack_Pieces->GetBoard() & Bit_bKing_Piece->GetBoard()) != 0 )
				{	
					CLog::Get()->Write("VaildateCheckType: Cannot move because the black king is in danger currently and black is trying to move!");
					if(!UndoMove(xOldPos, yOldPos, xNewPos, yNewPos))
					{
						CLog::Get()->WriteError("VaildateCheckType: UndoMove() function failed!");
						return 5; //5 is for error
					}

					return 2;
				}
			}
		}

		//Check to make sure king over the mover is not put into danger upon movement
		if(bOldTeamColor) //For white old piece movement
		{
			//Check to see if the movers king is put into danger
			if( (Bit_Black_Attack_Pieces->GetBoard() & Bit_wKing_Piece->GetBoard())  != 0 )
			{	
				CLog::Get()->Write("VaildateCheckType: Cannot move because the movers king would be placed into danger if move occurred");
				
				if(!UndoMove(xOldPos, yOldPos, xNewPos, yNewPos))
				{
					CLog::Get()->WriteError("VaildateCheckType: UndoMove() function failed!");
					return 5; //5 is for error
				}
				
				return 6;
			}
		}
		else //For black old piece movement
		{
			//Check to see if the movers king is already in danger..
			if( (Bit_White_Attack_Pieces->GetBoard() & Bit_bKing_Piece->GetBoard()) != 0 )
			{	
				CLog::Get()->Write("VaildateCheckType: Cannot move because the movers king would be placed into danger if move occurred");

				if(!UndoMove(xOldPos, yOldPos, xNewPos, yNewPos))
				{
					CLog::Get()->WriteError("VaildateCheckType: UndoMove() function failed!");
					return 5; //5 is for error
				}
				
				return 6;
			}
		}

		if(!UndoMove(xOldPos, yOldPos, xNewPos, yNewPos))
		{
			CLog::Get()->WriteError("VaildateCheckType: UndoMove() function failed!");
			return 5; //5 is for error
		}

		//If here hopefully the board is back to normal.
	}

	/* Implement these variables
	 
	 //Check/Checkmate stuff
	 bool bWhiteChecked;
	 bool bBlackChecked;

	 bool bWhiteCheckmated;
	 bool bBlackCheckmated;

	*/


	return 0; //False for not in check







	/*
	//Make sure that the input board, which the the board of potential moves with a 0 at the new position
	MoveBoard.SetBit(xNewPos, yNewPos);

	//Now test if this bit board yield a check upon movement
	if( (Bit_wKing_Piece->GetBoard() & MoveBoard.GetBoard()) && !bBlackChecked && !bBlackCheckmated)
	{	//White king is in check
		CLog::Get()->WriteError("cChessBoard_VaildateCheckOnMove: White King is in check and black king is not checked/mated");
		return true;

	}
	else if( (Bit_bKing_Piece->GetBoard() & MoveBoard.GetBoard()) && !bWhiteChecked && !bWhiteCheckmated)
	{	//Black king is in check
		CLog::Get()->WriteError("cChessBoard_VaildateCheckOnMove: Black King is in check and white king is not checked/mated");
		return true;
	}
	else
		return false;

	//Default: in check
	CLog::Get()->WriteError("cChessBoard_VaildateCheck: Program shouldn't not reach this point...?");
	return false;
	*/
}

bool cChessBoard::VaildateCheckmate(bool _bWhite_Black)
{
	//Just call MovePiece for all 6 possibles for the king of each color
	cBitboard KingBitBoard;

	//First find out where the king is
	if(_bWhite_Black)
		KingBitBoard.SetBoard(Bit_wKing_Piece->GetBoard());
	else
		KingBitBoard.SetBoard(Bit_bKing_Piece->GetBoard());

	UINT King_X = 0, King_Y = 0;

	//Loop through until you find the king
	for(UINT x = 1; x <= 8; x++)
	{
		for(UINT y = 1; y <= 8; y++)
		{
			if(KingBitBoard.TestBit(x, y))
			{
				King_X = x;
				King_Y = y;
				x = y = 100; //Break loop
				break;
			}

		}
	}

	//FIXME:
	//		I think there is a easier way to do this. Just get the valid moves of the king by ANDing it with its own pieces .
	//		Then checking the valid moves from the movement bitboards for the kings current position. then finally test each of these with the move/undomove checkings.!
	//		Note: Move me to procedure...

	//King has been found on the board in x/y position, now test 
	//the kings potential mobility for a place he can go without being in check and valid move

	//Plan: There are a maximum of eight potential moves for the king, check each one to see if it is a valid move.
	
	UINT uIndex = (((King_Y-1)*8)+(King_X-1));

	cChessBlock *tempBlock = &ChessBlocks[uIndex];
	PIECE_TYPE tempType = tempBlock->Piece->Type;

	cBitboard *tempBitBoard = NULL;
	cBitboard King_Movement_Board;

	//Get the kings movement bitboard
	tempBitBoard = &(cKing::King_BitBoards[uIndex]);

	//AND the kings movement bitboards with movements that do not contain a piece of the same color because it is blocking
	if(_bWhite_Black)
	{
		King_Movement_Board.SetBoard(tempBitBoard->GetBoard() & ~Bit_White_Pieces->GetBoard());
		cout << "White King Movement Board\n";
		King_Movement_Board.Drawboard();
	}
	else
	{
		King_Movement_Board.SetBoard(tempBitBoard->GetBoard() & ~Bit_Black_Pieces->GetBoard());
		cout << "Black King Movement Board\n";
		King_Movement_Board.Drawboard();
	}

	UINT MoveCounter = 0, InvalidMoveCounter = 0;

	//King_Movement_Board should now be filled with only empty squares and opposite team pieces for attack movements
	for(UINT cur_Y = 1; cur_Y <= 8; cur_Y++)
	{
		for(UINT cur_X = 1; cur_X <= 8; cur_X++)
		{
			//If bit isn't on, then move on
			if(!King_Movement_Board.TestBit(cur_X, cur_Y))
				continue; //Move along with the loop

			//Increment the number of possible moves tried to compare later
			MoveCounter++;

			//If here, we are going to try to move the king's piece to this potential square and test to see if the move results in danger
			//if no moves are found that aren't dangerous, this should be checkmate...

			if(!Move(King_X, King_Y, cur_X, cur_Y))
			{
				CLog::Get()->WriteError("VaildateCheckmate: Move() function failed!");
				if(!UndoMove(King_X, King_Y, cur_X, cur_Y))
				{
					CLog::Get()->WriteError("VaildateCheckmate: UndoMove() function failed!");
					return false; //5 is for error
				}

				return false; //5 is for error
			}

			//Check to make sure king over the mover is not put into danger upon movement
			if(_bWhite_Black) //For white old piece movement
			{
				//Check to see if the movers king is put into danger
				if( (Bit_Black_Attack_Pieces->GetBoard() & Bit_wKing_Piece->GetBoard())  == 0 )
				{	
					InvalidMoveCounter++;
				}
			}
			else //For black old piece movement
			{
				//Check to see if the movers king is already in danger..
				if( (Bit_White_Attack_Pieces->GetBoard() & Bit_bKing_Piece->GetBoard()) == 0 )
				{	
					InvalidMoveCounter++;
				}
			}

			if(!UndoMove(King_X, King_Y, cur_X, cur_Y))
			{
				CLog::Get()->WriteError("VaildateCheckmate: UndoMove() function failed!");
				return false;
			}
		}
	}

	//Test to see if no valid moves exist for the king
	if(MoveCounter != InvalidMoveCounter)
		return true;

	//Return false for non-checkmate
	return false;
}


bool cChessBoard::VaildateMove(UINT uindex, UINT xNew, UINT yNew)
{
	//Plan: We need to use these bitboards as a tool to assist in move validation on the board.
	//		Now we need to connect these bit boards and use clever bit operations on the 64 bit words
	//		to manage movement, potential movement, collision detection, more specific moves like castling,
	//		en pensent, piece upgrade, etc.
	
	//Obtain, and generate proper indices
	UINT uIndex_Old = uindex, uIndex_New = (((yNew-1)*8)+(xNew-1));

	cChessBlock *tempOld = &ChessBlocks[uIndex_Old], *tempNew = &ChessBlocks[uIndex_New];

	PIECE_TYPE tempType = tempOld->Piece->Type;//GetLivePieceType(tempOld->xPos, tempOld->yPos);
	
	cBitboard *tempBitBoard = NULL;
	cBitboard *tempBitBoardNew = NULL;
	cBitboard *tempBitBoard_PawnAttack = NULL;
	//Test Piece type and execute function (not doing virtual method because this level of verification should be at the board level)
	
	//Purpose of this is to figure out the appropriate pieces potential moves from the pre-generated bitboards
	{
		switch(tempType)
		{
		case PAWN:
			if(ChessBlocks[uIndex_Old].Piece->bTeamColor)
			{
				tempBitBoard = &(cPawn::White_Pawn_BitBoards[uIndex_Old]);
				tempBitBoardNew = &(cPawn::White_Pawn_BitBoards[uIndex_New]);

				tempBitBoard_PawnAttack =  &(cPawn::White_Pawn_Attack_BitBoards[uIndex_Old]);
			}
			else
			{
				tempBitBoard = &(cPawn::Black_Pawn_BitBoards[uIndex_Old]);
				tempBitBoardNew = &(cPawn::Black_Pawn_BitBoards[uIndex_New]);

				tempBitBoard_PawnAttack =  &(cPawn::Black_Pawn_Attack_BitBoards[uIndex_Old]);
			}
			break;

		case ROOK:
			tempBitBoard = &(cRook::Rook_BitBoards[uIndex_Old]);
			tempBitBoardNew = &(cRook::Rook_BitBoards[uIndex_New]);
			break;

		case KNIGHT:
			tempBitBoard = &(cKnight::Knight_BitBoards[uIndex_Old]);
			tempBitBoardNew = &(cKnight::Knight_BitBoards[uIndex_New]);
			break;

		case BISHOP:
			if(ChessBlocks[uIndex_Old].Piece->bTeamColor)
			{
				tempBitBoard = &(cBishop::White_Bishop_BitBoards[uIndex_Old]);
				tempBitBoardNew = &(cBishop::White_Bishop_BitBoards[uIndex_New]);

			}
			else
			{
				tempBitBoard = &(cBishop::Black_Bishop_BitBoards[uIndex_Old]);
				tempBitBoardNew = &(cBishop::Black_Bishop_BitBoards[uIndex_New]);
			}
			break;

		case KING:
			tempBitBoard = &(cKing::King_BitBoards[uIndex_Old]);
			tempBitBoardNew = &(cKing::King_BitBoards[uIndex_New]);
			break;

		case QUEEN:
			tempBitBoard = &(cQueen::Queen_BitBoards[uIndex_Old]);
			tempBitBoardNew = &(cQueen::Queen_BitBoards[uIndex_New]);
			break;

		case UNKNOWN:
			CLog::Get()->WriteError("VaildateMove: UNKNOWN return as piece type");
			return false;
			break;

		default:
			CLog::Get()->WriteError("VaildateMove: Piece was not able to be recognized as anything this program knows about.");
			return false;
			break;
		}
	}

	//Object for valid moves
	cBitboard ValidMoves, MovePath, ValidAttackMoves;

	cVector vNewPos(tempNew->xPos, tempNew->yPos, 0);
	cVector vCurPos(tempOld->xPos, tempOld->yPos, 0);

	cVector vDelta = vNewPos.Subtract(vCurPos);
	float fLengthTemp = vDelta.Length();

	cVector vCompare(0, 1, 0);

	//Normalize stuff
	vDelta.Normalize();
	vCompare.Normalize();

	//Dot them and look for proper angle
	float fDotty = vCompare.Dot(vDelta);

	//This test is to see if there are pieces in the way of the potential move

	//First generate bitboard for the path of the potential move
	MovePath.SetBoard( tempBitBoard->GetBoard() & tempBitBoardNew->GetBoard() );

	//I need to clean up the MovePath bitboard, there are bits set that are not on the correct route
	//but instead are there because of other squares that each position on the board and that piece for each share
	//Plan: There is one characteristic about a path and that is that it flows like a line. 
	//		Maybe check each bit around set bits to make sure there is a connection?	
	//		Or maybe...Got tea... Perhaps AND with each of the opposite   boards to detect external bits

	//Get rid of external bits not on path
	//Plan: We know both the old and new positions, therefore we can filter out the bits that are set outside of this box 'per say?'..
	UINT uTemp = 0;

	//Loop through each square, and generate bitboards that represent potentially valid moves
	for(UINT cur_Y = 1; cur_Y <= 8; cur_Y++)
	{
		for(UINT cur_X = 1; cur_X <= 8; cur_X++)
		{
			uTemp = (((cur_Y)*8)+(cur_X));

			//If bit isn't on, then move on
			if(!MovePath.TestBit(cur_X, cur_Y))
				continue; //Move along with the loop

			//Figure out vector for this specific bit as related to the old position
			cVector vTestPosition(cur_X, cur_Y, 0);
				
			cVector vTestDelta = vTestPosition.Subtract(vCurPos);
			float fTestLengthTemp = vTestDelta.Length();

			//Normalize stuff
			vTestDelta.Normalize();

			//Dot them and look for proper angle
			float fTestDotty = vCompare.Dot(vTestDelta);

			//Need to filter out bits that actually meet the dot product and the length criteria.
			//Plan: Use good old fashion slope!

			//If reached here, bit is on, and we need to test to see if it is within the limitations of the potential move
			//This tests to see if the dot products are the same as the move and also that this bit is not outside the possible radius of the move

			if( ((fDotty >= fTestDotty-EPSILON) && (fDotty <= fTestDotty+EPSILON))  && (fTestLengthTemp <= fLengthTemp) )
			{
				vTestDelta.Subtract(vDelta);
				if(vTestDelta.IsEqual( cVector(0, 0, 0) ))
					continue;
				else
					MovePath.ResetBit(cur_X, cur_Y);
			}
			else
				MovePath.ResetBit(cur_X, cur_Y);
		}
	}

	#if (BUILD_TYPE == DEBUG_MODE)
		cout << "Filtered Potential move path:\n";
		MovePath.Drawboard();
		cout << "\n";
	#endif

	//Now figure out if this path has anything in its way 
	//Note: Don't do this for the knight because he jumps over pieces
		
	//If the board is the same before and after this, then it should be all empty squares between the points of movement
	ValidMoves.SetBoard( MovePath.GetBoard() & ~Bit_All_Pieces->GetBoard() );

	#if (BUILD_TYPE == DEBUG_MODE)
		cout << "ValidMove Path:\n";
		ValidMoves.Drawboard();
		cout << "\n";
	#endif


	//If these aren't equal, something is in the way of the potential move
	if( (ValidMoves.GetBoard() != MovePath.GetBoard()) && (tempType != KNIGHT) )
	{	
		#if (BUILD_TYPE == DEBUG_MODE)
			CLog::Get()->WriteError("cChessBoard_ValidateMove: Something is blocking the move from happening.");
		#endif
		return false;
	}


	//This test is used so you cannot move onto your own pieces position
	//FIXME: unless in special case

	//FIXING: Plan: 12:50 am..
	//Going to use this method to call the other. Verify check or not, and/or checkmate.

	//If reached this point, move is fundamentally valid because it has passed the pieces movement function.
	//Also the move has passed a barrier/collision check.

/*

	//Now test if where we are moving puts the other king in check
	if( VaildateCheckOnMove(*tempBitBoardNew, tempOld->xPos, tempOld->yPos, tempNew->xPos, tempNew->yPos) )
	{
		//If here, we are attacking and putting in check 
		if(ChessBlocks[uIndex_Old].Piece->bTeamColor)
		{ //White checking black
			bBlackChecked = true;
			CLog::Get()->WriteEx("cChessBoard_ValidateMove: White is checking the black king!");
		}
		else
		{
			bWhiteChecked = true;
			CLog::Get()->WriteEx("cChessBoard_ValidateMove: Black is checking the white king!");
		}
	}

*/
	//This is the code that makes sure you do not run into your own piece.
	ValidMoves.ResetBoard();

	if(ChessBlocks[uIndex_Old].Piece->bTeamColor)
	{ //White piece being moved, but it cant move into another white piece. That would be rude.
		ValidMoves.SetBoard( tempBitBoard->GetBoard() & ~Bit_White_Pieces->GetBoard() );
	}
	else
	{
		ValidMoves.SetBoard( tempBitBoard->GetBoard() & ~Bit_Black_Pieces->GetBoard() );
	}

	//This code is so you cannot attack your own piece!
/*	if(AttackMovement)
	{
		ValidMoves.


	}
	*/
	//Test attack bit boards for the pawns now
	if(tempType == PAWN)
	{
		if(ChessBlocks[uIndex_Old].Piece->bTeamColor)
		{ 
			ValidAttackMoves.SetBoard( tempBitBoard_PawnAttack->GetBoard() & Bit_Black_Pieces->GetBoard() );
		}
		else
		{
			ValidAttackMoves.SetBoard( tempBitBoard_PawnAttack->GetBoard() & Bit_White_Pieces->GetBoard() );
		}
	}

	//HACK: Now ValidMoves has the bitboard for the valid blocks that the piece in the old position can move to
	if( (tempType == PAWN) && (fLengthTemp == 2) ) 
	{
		//Need to check to see if a piece is in the way of this jump.
		if( (tempOld->yPos == 7) )
			return ( (ValidMoves.TestBit(xNew, yNew)) && (ValidMoves.TestBit(xNew, yNew+1)) && !Bit_All_Pieces->TestBit(xNew, yNew+1) );
		else if( (tempOld->yPos == 2) )
			return ( (ValidMoves.TestBit(xNew, yNew)) && (ValidMoves.TestBit(xNew, yNew-1)) && !Bit_All_Pieces->TestBit(xNew, yNew-1) );
	}
	
	//Make sure the pawns do not attack an empty square, make sure the pawn is making a attack
	if( (tempType == PAWN) && ( ((fLengthTemp) >= (sqrt(2.0f))-EPSILON) && ((fLengthTemp) <= (sqrt(2.0f))+EPSILON) ) ) 
		if(tempNew->Piece->Type == EMPTY)
			return 0; //Fail because pawn cannot attack an empty square

	//Make sure the pawn doesn't just walk right through another piece! Straight into them that is...
	if( (tempType == PAWN) && (fLengthTemp == 1) )
		if(tempNew->Piece->Type != EMPTY)
			return 0; //Fail because pawn cannot walk directly into anything but an empty square

	/*
	//FIXME: Allows to jump, because it doesn't check the dot product!
	if( (tempType == PAWN) && (fLengthTemp < 2) && !tempBitBoard_PawnAttack->TestBit(xNew, yNew) ) 
	{
		return ( (ValidMoves.TestBit(xNew, yNew)) );
	}


	//Pawn attack event
	if( (tempType == PAWN) && (fLengthTemp < 2) && tempBitBoard_PawnAttack->TestBit(xNew, yNew) ) 
	{
	//	if(ChessBlocks[uIndex_Old].Piece->bTeamColor) //White
		return ( tempBitBoard_PawnAttack->TestBit(xNew, yNew) ) ;

	}
	*/


	//This checks if the bit inside of the ValidMove is on, and therefore validated
	 if( ValidMoves.TestBit(xNew, yNew) )
	 {
		 return 1;
	 }
	 else if(tempType == PAWN)
	 {
		 if( ValidAttackMoves.TestBit(xNew, yNew) )
			 return 1;
		 else	
			 return 0;
	 }
	 else
		 return 0;



	 //END FUCNTION
	 return 0;

	/*
	00000000
	00000000
	00000000
	00000000
	00000000
	00000000
	00000000
	00000000
*/

	//If in this function, move has already been verified somewhat. Lets find out whether or not the move actually is valid.
	//This function serves as high level functionality to check move validity.

	//

	//FIXME: Is the king is hostile waters?
};





//Purpose: Perform a direct move on the board without going through MovePiece. 
//		   Much of the error checking is omitted because checks have been done assumably by caller.
bool cChessBoard::Move(UINT _xPosOld, UINT _yPosOld, UINT _xPosNew, UINT _yPosNew)
{
	//Prepare variables
	UINT xPosOld = _xPosOld, yPosOld = _yPosOld, xPosNew = _xPosNew, yPosNew = _yPosNew;

	//Linear memory allocation needs to be split into chunks of 8 with 8 blocks in each row
	UINT uTempOld = (((yPosOld-1)*8)+(xPosOld-1));
	UINT uTempNew = (((yPosNew-1)*8)+(xPosNew-1));
	
	cPiece *tempPiece = NULL, *tempPieceNew = NULL;
	
	//Start setting information as if the move is valid, which I hope it is...
	tempPiece = ChessBlocks[uTempOld].Piece;
	tempPieceNew = ChessBlocks[uTempNew].Piece;
	
	//FIXME: What is the purpose of this?
	tempPiece->xPiecePos = xPosNew;
	tempPiece->yPiecePos = yPosNew;

	//Testing to make sure that the king is trying to attack a empty square
	//	if(ChessBlocks[uTempOld].Piece->bTeamColor)


	//First thing first, backup the current state of the pieces.Drawboard		
	Backup_Bit_All_Pieces.SetBoard( Bit_All_Pieces->GetBoard() );
	Backup_Bit_White_Pieces.SetBoard( Bit_White_Pieces->GetBoard() );
	Backup_Bit_Black_Pieces.SetBoard( Bit_Black_Pieces->GetBoard() );

	Backup_Bit_wPawn_Pieces.SetBoard( Bit_wPawn_Pieces->GetBoard() );
	Backup_Bit_bPawn_Pieces.SetBoard( Bit_bPawn_Pieces->GetBoard() );

	Backup_Bit_wBishop_Pieces.SetBoard( Bit_wBishop_Pieces->GetBoard() );
	Backup_Bit_bBishop_Pieces.SetBoard( Bit_bBishop_Pieces->GetBoard() );

	Backup_Bit_wKnight_Pieces.SetBoard( Bit_wKnight_Pieces->GetBoard() );
	Backup_Bit_bKnight_Pieces.SetBoard( Bit_bKnight_Pieces->GetBoard() );

	Backup_Bit_wRook_Pieces.SetBoard( Bit_wRook_Pieces->GetBoard() );
	Backup_Bit_bRook_Pieces.SetBoard( Bit_bRook_Pieces->GetBoard() );

	Backup_Bit_wQueen_Piece.SetBoard( Bit_wQueen_Piece->GetBoard() );
	Backup_Bit_bQueen_Piece.SetBoard( Bit_bQueen_Piece->GetBoard() );

	Backup_Bit_wKing_Piece.SetBoard( Bit_wKing_Piece->GetBoard() );
	Backup_Bit_bKing_Piece.SetBoard( Bit_bKing_Piece->GetBoard() );

	Backup_TotalWhiteValue = TotalWhiteValue; 
	Backup_TotalBlackValue = TotalBlackValue;


	//FIXME: memory leak
	cPiece *EmptyPiece;
	EmptyPiece = new cPiece(EMPTY, "Empty");
	EmptyPiece->xPiecePos = xPosOld;
	EmptyPiece->yPiecePos = yPosOld;


	//TODO: Need to add here the bit operations to move around pieces etc 
	if(ChessBlocks[uTempOld].Piece->bTeamColor)
	{ 
		Bit_White_Pieces->ResetBit(xPosOld, yPosOld);
		Bit_White_Pieces->SetBit(xPosNew, yPosNew);
	}
	else
	{
		Bit_Black_Pieces->ResetBit(xPosOld, yPosOld);
		Bit_Black_Pieces->SetBit(xPosNew, yPosNew);
	}

	//Set on global board
	Bit_All_Pieces->ResetBit(xPosOld, yPosOld);
	Bit_All_Pieces->SetBit(xPosNew, yPosNew);

	//Set piece bit information
	{
		PIECE_TYPE tempType = tempPiece->Type;//GetLivePieceType(xPosOld, yPosOld);
		switch(tempType)
		{
		case PAWN:
			if(ChessBlocks[uTempOld].Piece->bTeamColor)
			{
				Bit_wPawn_Pieces->ResetBit(xPosOld, yPosOld);
				Bit_wPawn_Pieces->SetBit(xPosNew, yPosNew);
			}
			else
			{
				Bit_bPawn_Pieces->ResetBit(xPosOld, yPosOld);
				Bit_bPawn_Pieces->SetBit(xPosNew, yPosNew);
			}			

			break;

		case ROOK:
			if(ChessBlocks[uTempOld].Piece->bTeamColor)
			{
				Bit_wRook_Pieces->ResetBit(xPosOld, yPosOld);
				Bit_wRook_Pieces->SetBit(xPosNew, yPosNew);
			}
			else
			{
				Bit_bRook_Pieces->ResetBit(xPosOld, yPosOld);
				Bit_bRook_Pieces->SetBit(xPosNew, yPosNew);
			}					

			break;

		case KNIGHT:
			if(ChessBlocks[uTempOld].Piece->bTeamColor)
			{
				Bit_wKnight_Pieces->ResetBit(xPosOld, yPosOld);
				Bit_wKnight_Pieces->SetBit(xPosNew, yPosNew);
			}
			else
			{
				Bit_bKnight_Pieces->ResetBit(xPosOld, yPosOld);
				Bit_bKnight_Pieces->SetBit(xPosNew, yPosNew);
			}					

			break;

		case BISHOP:

			if(ChessBlocks[uTempOld].Piece->bTeamColor)
			{
				Bit_wBishop_Pieces->ResetBit(xPosOld, yPosOld);
				Bit_wBishop_Pieces->SetBit(xPosNew, yPosNew);
			}
			else
			{
				Bit_bBishop_Pieces->ResetBit(xPosOld, yPosOld);
				Bit_bBishop_Pieces->SetBit(xPosNew, yPosNew);
			}

			break;

		case KING:

			if(ChessBlocks[uTempOld].Piece->bTeamColor)
			{
				Bit_wKing_Piece->ResetBit(xPosOld, yPosOld);
				Bit_wKing_Piece->SetBit(xPosNew, yPosNew);
			}
			else
			{
				Bit_bKing_Piece->ResetBit(xPosOld, yPosOld);
				Bit_bKing_Piece->SetBit(xPosNew, yPosNew);	
			}

			break;

		case QUEEN:

			if(ChessBlocks[uTempOld].Piece->bTeamColor)
			{
				Bit_wQueen_Piece->ResetBit(xPosOld, yPosOld);
				Bit_wQueen_Piece->SetBit(xPosNew, yPosNew);
			}
			else
			{
				Bit_bQueen_Piece->ResetBit(xPosOld, yPosOld);
				Bit_bQueen_Piece->SetBit(xPosNew, yPosNew);	
			}
			break;

		case UNKNOWN:
			CLog::Get()->WriteError("cBoard_Move: UNKNOWN return as piece type");
			return false;
			break;

		default:
			CLog::Get()->WriteError("cBoard_Move: Piece was not able to be recognized as anything this program knows about.");
			return false;
			break;
		}
	}

	//Note: Attack movement will be set already from MovePiece function

	//if attacking another piece, we need to save the taken over piece into the dead pieces, and do proper bitboard code!
	if(AttackMovement)
	{ 
		//Set piece bit information
		{			
			//White attacking black, so fix black bitboard
			if(ChessBlocks[uTempOld].Piece->bTeamColor)
				Bit_Black_Pieces->ResetBit(xPosNew, yPosNew);
			else //Black attacking white
				Bit_White_Pieces->ResetBit(xPosNew, yPosNew);

			//Now figure out which kind of piece is being attacked and fix their bitboards!
			PIECE_TYPE tempType = tempPieceNew->Type;
			switch(tempType)
			{
			case PAWN:
				//So test if it is a white or a black pawn that is being attacked, and edit accordingly.
				if(ChessBlocks[uTempNew].Piece->bTeamColor)
					Bit_wPawn_Pieces->ResetBit(xPosNew, yPosNew);
				else
					Bit_bPawn_Pieces->ResetBit(xPosNew, yPosNew);
		
				//Reset the attack bitboard so that identifier of the piece who is being attacked no longer appears in the attack boards
				/* LEFTOFF: This is where I left off, i was trying to attack the problem by thinking that when a piece is taken,
					            the attack bitboards for the piece were still being used, and not reset... 
							However pre-testing with this showed that this doesn't seem to fix the issue..
				*/
				Bit_Pawn_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
				break;

			case ROOK:		
				if(ChessBlocks[uTempNew].Piece->bTeamColor)
					Bit_wRook_Pieces->ResetBit(xPosNew, yPosNew);
				else
					Bit_bRook_Pieces->ResetBit(xPosNew, yPosNew);

				Bit_Rook_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
				break;

			case KNIGHT:				
				if(ChessBlocks[uTempNew].Piece->bTeamColor)
					Bit_wKnight_Pieces->ResetBit(xPosNew, yPosNew);
				else
					Bit_bKnight_Pieces->ResetBit(xPosNew, yPosNew);

				Bit_Knight_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
				break;

			case BISHOP:
				if(ChessBlocks[uTempNew].Piece->bTeamColor)
					Bit_wBishop_Pieces->ResetBit(xPosNew, yPosNew);
				else
					Bit_bBishop_Pieces->ResetBit(xPosNew, yPosNew);

				Bit_Bishop_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
				break;

			case KING:
				CLog::Get()->WriteError("Inside of somewhere... It appears that the king is being attacked and about to have its bitboard erased from the map.....?");
					
				if(ChessBlocks[uTempNew].Piece->bTeamColor)
					Bit_wKing_Piece->ResetBit(xPosNew, yPosNew);
				else
					Bit_bKing_Piece->ResetBit(xPosNew, yPosNew);

				Bit_King_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
				break;

			case QUEEN:
				if(ChessBlocks[uTempNew].Piece->bTeamColor)
					Bit_wQueen_Piece->ResetBit(xPosNew, yPosNew);
				else
					Bit_bQueen_Piece->ResetBit(xPosNew, yPosNew);

				Bit_Queen_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
				break;
			case EMPTY:
				CLog::Get()->WriteError("cBoard_Move:Attack movement Stuff -- EMPTY return as piece type...Continuing program execution for my sanity...");
			//	return false;
				break;

			case UNKNOWN:
				CLog::Get()->WriteError("cBoard_Move:Attack movement Stuff -- UNKNOWN return as piece type");
				return false;
				break;

			default:
				CLog::Get()->WriteError("cBoard_Move: Attack movement Stuff -- Piece was not able to be recognized as anything this program knows about.");
				return false;
				break;
			}
		}

		//add to dead pieces as a deferenced object
		if(DeadPieceCounter >= 32)
		{
			CLog::Get()->WriteError("cChessBoard_MovePiece: DeadPieceCounter is greater than or equal to 32. This could be bad! Continuing anyways...");
			//return false;
		}

		//Update total piece team values
		if(ChessBlocks[uTempNew].Piece->bTeamColor)
		{ 
			//A white piece is dying
			TotalBlackValue += ChessBlocks[uTempNew].Piece->PieceValue;
			TotalWhiteValue -= ChessBlocks[uTempNew].Piece->PieceValue;
		}
		else
		{
			//A black piece is dying
			TotalBlackValue -= ChessBlocks[uTempNew].Piece->PieceValue;
			TotalWhiteValue += ChessBlocks[uTempNew].Piece->PieceValue;
		}


		//Add it to dead pieces
		DeadChessPieces[DeadPieceCounter++] = ChessBlocks[uTempNew].Piece;

		//Now finally actually switch the piece pointers!
		ChessBlocks[uTempNew].Piece = tempPiece;
		ChessBlocks[uTempOld].Piece = EmptyPiece;
	}
	else
	{
		ChessBlocks[uTempNew].Piece = tempPiece;
		ChessBlocks[uTempOld].Piece = EmptyPiece;
	}

	try {
		if(!UpdateAttackBitBoards())
		{
			CLog::Get()->WriteError("cChessBoard_Move: UpdateAttackBitBoards returned invalid!");
			return false;

		}
	}
	catch(int excep)
	{
		CLog::Get()->WriteError("cChessBoard_Move: !Caught exception from UpdateAttackBitboards! %d", excep);
		return false;

	};

	return true;
}

bool cChessBoard::UndoMove(UINT _xPosOld, UINT _yPosOld, UINT _xPosNew, UINT _yPosNew)
{
	//First thing first, set the backups to the right ones	
	Bit_All_Pieces->SetBoard( Backup_Bit_All_Pieces.GetBoard() );
	
	Bit_White_Pieces->SetBoard( Backup_Bit_White_Pieces.GetBoard() );
	Bit_Black_Pieces->SetBoard( Backup_Bit_Black_Pieces.GetBoard() );

	Bit_wPawn_Pieces->SetBoard( Backup_Bit_wPawn_Pieces.GetBoard() );
	Bit_bPawn_Pieces->SetBoard( Backup_Bit_bPawn_Pieces.GetBoard() );

	Bit_wBishop_Pieces->SetBoard( Backup_Bit_wBishop_Pieces.GetBoard() );
	Bit_bBishop_Pieces->SetBoard( Backup_Bit_bBishop_Pieces.GetBoard() );

	Bit_wKnight_Pieces->SetBoard( Backup_Bit_wKnight_Pieces.GetBoard() );
	Bit_bKnight_Pieces->SetBoard( Backup_Bit_bKnight_Pieces.GetBoard() );

	Bit_wRook_Pieces->SetBoard( Backup_Bit_wRook_Pieces.GetBoard() );
	Bit_bRook_Pieces->SetBoard( Backup_Bit_bRook_Pieces.GetBoard() );

	Bit_wQueen_Piece->SetBoard( Backup_Bit_wQueen_Piece.GetBoard() );
	Bit_bQueen_Piece->SetBoard( Backup_Bit_bQueen_Piece.GetBoard() );

	Bit_wKing_Piece->SetBoard( Backup_Bit_wKing_Piece.GetBoard() );
	Bit_bKing_Piece->SetBoard( Backup_Bit_bKing_Piece.GetBoard() );

	TotalWhiteValue = Backup_TotalWhiteValue;
	TotalBlackValue = Backup_TotalBlackValue;

	//Now we need to set the pieces represented by pointers to the previous blocks, and resurrect the poor piece offered in the name of science.

	//Prepare variables
	UINT xPosOld = _xPosOld, yPosOld = _yPosOld, xPosNew = _xPosNew, yPosNew = _yPosNew;

	//Linear memory allocation needs to be split into chunks of 8 with 8 blocks in each row
	UINT uTempOld = (((yPosOld-1)*8)+(xPosOld-1));
	UINT uTempNew = (((yPosNew-1)*8)+(xPosNew-1));
	
	//Delete the empty piece. 

	/* LEFTOFF -- TAKING A BREAK:
		I fixed the dead pawn getting put back to the right place, but now it is referencing the knight that has to do with the move ... 
		and this knight is being set to memory made of noise....I do not care if noise does not fit, becuase i think it does.

		FIX THIS SHIT
	*/



	//Note: First step to responsible memory management...There better be more!
	/*
	if(ChessBlocks[uTempOld].Piece->Type == EMPTY)
	{
		SafeDelete(ChessBlocks[uTempOld].Piece);
	}
	else
	{
		CLog::Get()->WriteError("cChessBoard_UndoMove: The piece on the old block is not an empty block. UndoMove should be called only with Move!");
		return false;
	}
	*/
	//The empty piece is deleted, now set the appropriate pointers.
	ChessBlocks[uTempOld].Piece = ChessBlocks[uTempNew].Piece;
	ChessBlocks[uTempOld].Piece->xPiecePos = xPosOld;
	ChessBlocks[uTempOld].Piece->yPiecePos = yPosOld;

	//LEFTOFF: I think the problem is that the piece is being initialized to nothing from DeadChessPieces because no pieces have yet to be taken.
	cPiece *tempDeadPiece = NULL;

	if(AttackMovement)
	{
		//Deference once, bam! we are now looking into the opening of 32 pointers to cPieces...
		//tempDeadPiece = *((cPiece **)DeadChessPieces);

		//Now we need to increment to the pointer that we are looking for
		//tempDeadPiece =  (&tempDeadPiece + sizeof(cPiece)*DeadPieceCounter--);
		ChessBlocks[uTempNew].Piece = DeadChessPieces[--DeadPieceCounter];


		//ChessBlocks[uTempNew].Piece = ((*DeadChessPieces) + (4 * --DeadPieceCounter));


	//	ChessBlocks[uTempNew].Piece = (cPiece *)&(DeadChessPieces[--DeadPieceCounter]);//[DeadPieceCounter--];

		/*
		lpp = &(*lpp)->next

			(*lpp)->next
			*/

		//FIXME -- HACK: Make sure it isn't null if so, create empty
		if(!ChessBlocks[uTempNew].Piece)
		{
			CLog::Get()->WriteError("cChessBoard_UndoMove: invalid memory for piece object. HACK OCCURING");
			//FIXME: memory leak
			cPiece *EmptyPiece;
			EmptyPiece = new cPiece(EMPTY, "Empty");


			EmptyPiece->xPiecePos = ChessBlocks[uTempNew].Piece->xPiecePos;
			EmptyPiece->yPiecePos = ChessBlocks[uTempNew].Piece->yPiecePos;

			ChessBlocks[uTempNew].Piece = EmptyPiece;
		}

	}
	else
	{
		//Create a new empty piece with the proper x,y coordinates on the board. 

		//FIXME: memory leak
		cPiece *EmptyPiece;
		EmptyPiece = new cPiece(EMPTY, "Empty");
		EmptyPiece->xPiecePos = ChessBlocks[uTempNew].Piece->xPiecePos;
		EmptyPiece->yPiecePos = ChessBlocks[uTempNew].Piece->yPiecePos;

		ChessBlocks[uTempNew].Piece = EmptyPiece;
	}

	//Fix the attack bitboards
	try {
		if(!UpdateAttackBitBoards())
		{
			CLog::Get()->WriteError("cChessBoard_UndoMove: UpdateAttackBitBoards returned invalid!");
			return false;

		}
	}
	catch(int excep)
	{
		CLog::Get()->WriteError("cChessBoard_UndoMove: !Caught exception from UpdateAttackBitboards! %d", excep);
		return false;

	};

	return true;
}













bool cChessBoard::MovePiece(UINT _xPosOld, UINT _yPosOld, UINT _xPosNew, UINT _yPosNew)
{
	//Reset attack movement
	AttackMovement = false;

	UINT xPosOld = _xPosOld, yPosOld = _yPosOld, xPosNew = _xPosNew, yPosNew = _yPosNew;

	//Linear memory allocation needs to be split into chunks of 8 with 8 blocks in each row
	UINT uTempOld = (((yPosOld-1)*8)+(xPosOld-1));
	UINT uTempNew = (((yPosNew-1)*8)+(xPosNew-1));

	cPiece *tempPiece = NULL, *tempPieceNew = NULL;

	if( (uTempOld > 63) || (uTempNew > 63) )
	{
		CLog::Get()->WriteError("cChessBoard_MovePiece: Transform of number exceeds maximum.");
		return false;
	}

	//Make sure we are not moving into the same spot
	if( (_xPosOld == xPosNew) && (_yPosOld == yPosNew) )
	{
		CLog::Get()->WriteError("cChessBoard_MovePiece: Invalid move because you cannot move into the same square that you are already on!");
		return false;
	}

	//Make sure that we are not trying to move an empty square
	//FIXME: Maybe will not work with en pensent moves
	if(ChessBlocks[uTempOld].Piece->Type == EMPTY)
	{
		CLog::Get()->WriteError("cChessBoard_MovePiece: The piece you are trying to move is EMPTY!");
		return false;
	}

	//Test to see if this is a potential attack movement
	if(ChessBlocks[uTempNew].Piece->Type != EMPTY)
		AttackMovement = true;
	
	//First check piece's basic movement function to see if it is valid move
	if(!ChessBlocks[uTempOld].Piece->Movement(xPosNew, yPosNew))
	{
		CLog::Get()->WriteError("cChessBoard_MovePiece: Failed Piece_Movement function.");
		return false;
	}
	
	if( VaildateMove(uTempOld, xPosNew, yPosNew) )
	{
		//Now test check stuff
		if( VaildateCheckType(xPosOld, yPosOld, xPosNew, yPosNew) != 0)
		{
			//If here, then if we move this piece, the king could potentially be in the check

			//FIXME: Add code to see if other player has attack on piece if current piece is moved
			#if (BUILD_TYPE == PRIVATE_MODE)
				CLog::Get()->WriteError("FIXME: cChessBoard_MovePiece: VaildateCheckType returned some kind of check");
			#endif

			return false;
		}

		//FIXME: Is this even required
		tempPiece = ChessBlocks[uTempOld].Piece;
		tempPieceNew = ChessBlocks[uTempNew].Piece;

		//FIXME: memory leak
		cPiece *EmptyPiece;
		EmptyPiece = new cPiece(EMPTY, "Empty");
		EmptyPiece->xPiecePos = xPosOld;
		EmptyPiece->yPiecePos = yPosOld;

		//FIXME: What is the purpose of this?
		tempPiece->xPiecePos = xPosNew;
		tempPiece->yPiecePos = yPosNew;

		//TODO: Need to add here the bit operations to move around pieces etc 
		if(ChessBlocks[uTempOld].Piece->bTeamColor)
		{ 
			Bit_White_Pieces->ResetBit(xPosOld, yPosOld);
			Bit_White_Pieces->SetBit(xPosNew, yPosNew);
		}
		else
		{
			Bit_Black_Pieces->ResetBit(xPosOld, yPosOld);
			Bit_Black_Pieces->SetBit(xPosNew, yPosNew);
		}

		//Set on global board
		Bit_All_Pieces->ResetBit(xPosOld, yPosOld);
		Bit_All_Pieces->SetBit(xPosNew, yPosNew);
	
		//Set piece bit information
		{
			PIECE_TYPE tempType = tempPiece->Type;//GetLivePieceType(xPosOld, yPosOld);
			switch(tempType)
			{
				case PAWN:
					if(ChessBlocks[uTempOld].Piece->bTeamColor)
					{
						Bit_wPawn_Pieces->ResetBit(xPosOld, yPosOld);
						Bit_wPawn_Pieces->SetBit(xPosNew, yPosNew);
					}
					else
					{
						Bit_bPawn_Pieces->ResetBit(xPosOld, yPosOld);
						Bit_bPawn_Pieces->SetBit(xPosNew, yPosNew);
					}			

				break;

				case ROOK:
					if(ChessBlocks[uTempOld].Piece->bTeamColor)
					{
						Bit_wRook_Pieces->ResetBit(xPosOld, yPosOld);
						Bit_wRook_Pieces->SetBit(xPosNew, yPosNew);
					}
					else
					{
						Bit_bRook_Pieces->ResetBit(xPosOld, yPosOld);
						Bit_bRook_Pieces->SetBit(xPosNew, yPosNew);
					}					

				break;

				case KNIGHT:
					if(ChessBlocks[uTempOld].Piece->bTeamColor)
					{
						Bit_wKnight_Pieces->ResetBit(xPosOld, yPosOld);
						Bit_wKnight_Pieces->SetBit(xPosNew, yPosNew);
					}
					else
					{
						Bit_bKnight_Pieces->ResetBit(xPosOld, yPosOld);
						Bit_bKnight_Pieces->SetBit(xPosNew, yPosNew);
					}					

				break;

				case BISHOP:

					if(ChessBlocks[uTempOld].Piece->bTeamColor)
					{
						Bit_wBishop_Pieces->ResetBit(xPosOld, yPosOld);
						Bit_wBishop_Pieces->SetBit(xPosNew, yPosNew);
					}
					else
					{
						Bit_bBishop_Pieces->ResetBit(xPosOld, yPosOld);
						Bit_bBishop_Pieces->SetBit(xPosNew, yPosNew);
					}
	
				break;

				case KING:

					if(ChessBlocks[uTempOld].Piece->bTeamColor)
					{
						Bit_wKing_Piece->ResetBit(xPosOld, yPosOld);
						Bit_wKing_Piece->SetBit(xPosNew, yPosNew);
					}
					else
					{
						Bit_bKing_Piece->ResetBit(xPosOld, yPosOld);
						Bit_bKing_Piece->SetBit(xPosNew, yPosNew);	
					}
	
				break;

				case QUEEN:

					if(ChessBlocks[uTempOld].Piece->bTeamColor)
					{
						Bit_wQueen_Piece->ResetBit(xPosOld, yPosOld);
						Bit_wQueen_Piece->SetBit(xPosNew, yPosNew);
					}
					else
					{
						Bit_bQueen_Piece->ResetBit(xPosOld, yPosOld);
						Bit_bQueen_Piece->SetBit(xPosNew, yPosNew);	
					}
				break;

				case UNKNOWN:
					CLog::Get()->WriteError("cBoard_MovePiece: UNKNOWN return as piece type");
					return false;
				break;

				default:
					CLog::Get()->WriteError("cBoard_cBoard_MovePiece: Piece was not able to be recognized as anything this program knows about.");
					return false;
				break;
			}
		}

		//Finally switch the pieces

		//if attacking another piece, we need to save the taken over piece into the dead pieces, and do proper bitboard code!
		if(AttackMovement)
		{ 
			//Set piece bit information
			{			
				//White attacking black, so fix black bitboard
				if(ChessBlocks[uTempOld].Piece->bTeamColor)
					Bit_Black_Pieces->ResetBit(xPosNew, yPosNew);
				else //Black attacking white
					Bit_White_Pieces->ResetBit(xPosNew, yPosNew);

				//Now figure out which kind of piece is being attacked and fix their bitboards!
				PIECE_TYPE tempType = tempPieceNew->Type;
				switch(tempType)
				{
				case PAWN:
					//So test if it is a white or a black pawn that is being attacked, and edit accordingly.
					if(ChessBlocks[uTempNew].Piece->bTeamColor)
						Bit_wPawn_Pieces->ResetBit(xPosNew, xPosNew);
					else
						Bit_bPawn_Pieces->ResetBit(xPosNew, xPosNew);
		
					//Reset the attack bitboard so that identifier of the piece who is being attacked no longer appears in the attack boards
					/* LEFTOFF: This is where I left off, i was trying to attack the problem by thinking that when a piece is taken,
					             the attack bitboards for the piece were still being used, and not reset... 
								However pre-testing with this showed that this doesn't seem to fix the issue..
					*/
					Bit_Pawn_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
					break;

				case ROOK:		
					if(ChessBlocks[uTempNew].Piece->bTeamColor)
						Bit_wRook_Pieces->ResetBit(xPosNew, xPosNew);
					else
						Bit_bRook_Pieces->ResetBit(xPosNew, xPosNew);

					Bit_Rook_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
					break;

				case KNIGHT:				
					if(ChessBlocks[uTempNew].Piece->bTeamColor)
						Bit_wKnight_Pieces->ResetBit(xPosNew, xPosNew);
					else
						Bit_bKnight_Pieces->ResetBit(xPosNew, xPosNew);

					Bit_Knight_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
					break;

				case BISHOP:
					if(ChessBlocks[uTempNew].Piece->bTeamColor)
						Bit_wBishop_Pieces->ResetBit(xPosNew, xPosNew);
					else
						Bit_bBishop_Pieces->ResetBit(xPosNew, xPosNew);

					Bit_Bishop_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
					break;

				case KING:
					CLog::Get()->WriteError("Inside of somewhere... It appears that the king is being attacked and about to have its bitboard erased from the map.....?");
					
					if(ChessBlocks[uTempNew].Piece->bTeamColor)
						Bit_wKing_Piece->ResetBit(xPosNew, xPosNew);
					else
						Bit_bKing_Piece->ResetBit(xPosNew, xPosNew);

					Bit_King_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
					break;

				case QUEEN:
					if(ChessBlocks[uTempNew].Piece->bTeamColor)
						Bit_wQueen_Piece->ResetBit(xPosNew, xPosNew);
					else
						Bit_bQueen_Piece->ResetBit(xPosNew, xPosNew);

					Bit_Queen_Attack_Pieces[ChessBlocks[uTempNew].Piece->PieceIdentifier-1].ResetBoard();
					break;

				case UNKNOWN:
					CLog::Get()->WriteError("cBoard_MovePiece:Attack movement Stuff -- UNKNOWN return as piece type");
					return false;
					break;

				default:
					CLog::Get()->WriteError("cBoard_cBoard_MovePiece: Attack movement Stuff -- Piece was not able to be recognized as anything this program knows about.");
					return false;
					break;
				}
			}

			//add to dead pieces as a deferenced object
			if(DeadPieceCounter >= 32)
			{
				CLog::Get()->WriteError("cChessBoard_MovePiece: DeadPieceCounter is greater than or equal to 32. This could be bad! Continuing anyways...");
				//return false;
			}

			
			//Update total piece team values
			if(ChessBlocks[uTempNew].Piece->bTeamColor)
			{ 
				//A white piece is dying
				TotalBlackValue += ChessBlocks[uTempNew].Piece->PieceValue;
				TotalWhiteValue -= ChessBlocks[uTempNew].Piece->PieceValue;
			}
			else
			{
				//A black piece is dying
				TotalBlackValue -= ChessBlocks[uTempNew].Piece->PieceValue;
				TotalWhiteValue += ChessBlocks[uTempNew].Piece->PieceValue;
			}


			//Add it to dead pieces
			DeadChessPieces[DeadPieceCounter++] = ChessBlocks[uTempNew].Piece;

			//Now finally actually switch the piece pointers!
			ChessBlocks[uTempNew].Piece = tempPiece;
			ChessBlocks[uTempOld].Piece = EmptyPiece;

			
			cout << "\nTotal Piece Value: " << TotalWhiteValue << " " << TotalBlackValue << endl;
			CLog::Get()->Write("NOTICE: A attack movement just occurred!");

		}
		else
		{
			ChessBlocks[uTempNew].Piece = tempPiece;
			ChessBlocks[uTempOld].Piece = EmptyPiece;
		}


		//FIXME: Update the bWhiteBlack option if a white/black piece is taking over a black/white piece square. (Use AttackBitboards at top of function?)
		//Update to fix: I added some more check at the top, however when we overwrite the new piece, the bWhiteBlack gets copied too. (Note: no currently implemented copy constructor but I think it will be ok with the current data types)

		try {
		if(!UpdateAttackBitBoards())
		{
			CLog::Get()->WriteError("cChessBoard_MovePiece: UpdateAttackBitBoards returned invalid!");
			return false;

		}
		}
		catch(int excep)
		{
			CLog::Get()->WriteError("cChessBoard_MovePiece: !Caught exception from UpdateAttackBitboards! %d", excep);

		};

		//Return true for valid move, and finished move.
		return true;
	}
	else
	{
		//Invalid move
		CLog::Get()->WriteError("cChessBoard_MovePiece: Failed Validate function check.");
		return false;
	}

	//Return false is invalid move
	return false;
}

bool cChessBoard::UpdateAttackBitBoards()
{
	//FUTURE: Make this function quicker by only updating the pieces that are directly affected by a piece changing positions rather than all pieces.

	//First find out where the pieces are on the board
	cBitboard Alive_White_Pieces( Bit_All_Pieces->GetBoard() & Bit_White_Pieces->GetBoard() );
	cBitboard Alive_Black_Pieces( Bit_All_Pieces->GetBoard() & Bit_Black_Pieces->GetBoard() );

	//Plan Procedure:
	//Now loop through alive pieces, and for each piece, 
	//get the type of piece, 
	//then get the bitboard for that pieces potential movement from that spot (filter out the empty squares!)
	//then filter that movement bitboard with the opposite teams alive pieces
	//then test these final set bits too see if they are actually validated movements
	//if they are, then this is a valid attack on the other teams piece.
	//The final bitboard output should only have bits set where there is a valid attack

	cChessBlock *tempBlock = NULL;
	UINT uIndex = 0;
	PIECE_TYPE tempType = UNKNOWN;
	cBitboard *tempBitBoard = NULL;
	int PieceId = -1;

	cBitboard tempAttackBitBoard;

	for(UINT x = 1; x <= 8; x++)
	{
		for(UINT y = 1; y <= 8; y++)
		{
			//Do for white pieces
			if(!Alive_White_Pieces.TestBit(x, y))
				if(!Alive_Black_Pieces.TestBit(x, y))
					continue;

			tempAttackBitBoard.ResetBoard();

			//if reached here, either there square contains a black or white piece, and isn't empty
			uIndex = (((y-1)*8)+(x-1));

			//Get type of piece
			tempBlock = &ChessBlocks[uIndex];
			tempType = tempBlock->Piece->Type;
			PieceId = tempBlock->Piece->PieceIdentifier;

			//Purpose of this is to figure out the appropriate pieces potential moves from the pre-generated bitboards
			{ //Begin Block
				switch(tempType)
				{
				case PAWN:
					if(ChessBlocks[uIndex].Piece->bTeamColor)
					{
						//tempBitBoard = &(cPawn::White_Pawn_BitBoards[uIndex]);
						tempBitBoard = &(cPawn::White_Pawn_Attack_BitBoards[uIndex]);
					}
					else
					{
						//tempBitBoard = &(cPawn::Black_Pawn_BitBoards[uIndex]);
						tempBitBoard = &(cPawn::Black_Pawn_Attack_BitBoards[uIndex]);
					}
					break;

				case ROOK:
					tempBitBoard = &(cRook::Rook_BitBoards[uIndex]);
					break;

				case KNIGHT:
					tempBitBoard = &(cKnight::Knight_BitBoards[uIndex]);
					break;

				case BISHOP:
					if(ChessBlocks[uIndex].Piece->bTeamColor)
					{
						tempBitBoard = &(cBishop::White_Bishop_BitBoards[uIndex]);
					}
					else
					{
						tempBitBoard = &(cBishop::Black_Bishop_BitBoards[uIndex]);
					}
					break;

				case KING:
					tempBitBoard = &(cKing::King_BitBoards[uIndex]);
					break;

				case QUEEN:
					tempBitBoard = &(cQueen::Queen_BitBoards[uIndex]);
					break;

				case UNKNOWN:
					CLog::Get()->WriteError("cChessBoard_UpdateAttackBitBoards: UNKNOWN return as piece type");
					return false;
					break;

				case EMPTY:
					CLog::Get()->WriteError("cChessBoard_UpdateAttackBitBoards: EMPTY return as piece type. Strange error...");
					return false;
					break;

				default:
					CLog::Get()->WriteError("cChessBoard_UpdateAttackBitBoards: Piece was not able to be recognized as anything this program knows about.");
					return false;
					break;
				}
			} //End Block

			//Now tempBitboard is filled in with the potential moves from the spot we are currently checking, for the proper color and piece of the square
			//Next thing in the list is to filter out empty squares
			//tempBitBoard->AND_BitBoard( (Bit_All_Pieces->GetBoard()) );

			
			//Filter bitboard with opposite teams alive pieces

			if(ChessBlocks[uIndex].Piece->bTeamColor)
				tempAttackBitBoard.SetBoard( tempBitBoard->GetBoard() & Alive_Black_Pieces.GetBoard() );
			else
				tempAttackBitBoard.SetBoard( tempBitBoard->GetBoard() & Alive_White_Pieces.GetBoard() );

			//Now loop through the set bits, and validate that the attack movement is actually valid
			for(UINT tempX = 1; tempX <= 8; tempX++)
			{
				for(UINT tempY = 1; tempY <= 8; tempY++)
				{
					if(!tempAttackBitBoard.TestBit(tempX, tempY))
						continue;

					//If reached here, then this current bit should be set, test if it is a valid move...
					if( !VaildateMove(uIndex, tempX, tempY)) 
						tempAttackBitBoard.ResetBit(tempX, tempY);
				}
			}

			//Finally set the tempBitBoard to the actual attack bitboard for the piece
			PieceId--;
			switch(tempType)
			{
				case PAWN:
					Bit_Pawn_Attack_Pieces[PieceId].SetBoard( tempAttackBitBoard.GetBoard() );
				break;

				case ROOK:
					Bit_Rook_Attack_Pieces[PieceId].SetBoard( tempAttackBitBoard.GetBoard() );
				break;

				case KNIGHT:
					Bit_Knight_Attack_Pieces[PieceId].SetBoard( tempAttackBitBoard.GetBoard() );
				break;

				case BISHOP:
					Bit_Bishop_Attack_Pieces[PieceId].SetBoard( tempAttackBitBoard.GetBoard() );
				break;

				case KING:
					Bit_King_Attack_Pieces[PieceId].SetBoard( tempAttackBitBoard.GetBoard() );
				break;

				case QUEEN:
					Bit_Queen_Attack_Pieces[PieceId].SetBoard( tempAttackBitBoard.GetBoard() );
				break;

				case UNKNOWN:
					CLog::Get()->WriteError("cChessBoard_UpdateAttackBitBoards: UNKNOWN return as piece type");
					return false;
				break;

				default:
					CLog::Get()->WriteError("cChessBoard_UpdateAttackBitBoards: Piece was not able to be recognized as anything this program knows about.");
					return false;
					break;
			}

		} //End Y Loop
	} //End X Loop
	
	//Set the bitboards for all the white and black attack pieces
	Bit_White_Attack_Pieces->ResetBoard();
	Bit_Black_Attack_Pieces->ResetBoard();

	Bit_White_Attack_Pieces->SetBoard( Bit_Rook_Attack_Pieces[2].GetBoard() | Bit_Rook_Attack_Pieces[3].GetBoard() | Bit_Knight_Attack_Pieces[2].GetBoard() | Bit_Knight_Attack_Pieces[3].GetBoard() | Bit_Bishop_Attack_Pieces[2].GetBoard() | Bit_Bishop_Attack_Pieces[3].GetBoard() | Bit_King_Attack_Pieces[1].GetBoard() | Bit_Queen_Attack_Pieces[1].GetBoard() );
	Bit_Black_Attack_Pieces->SetBoard( Bit_Rook_Attack_Pieces[0].GetBoard() | Bit_Rook_Attack_Pieces[1].GetBoard() | Bit_Knight_Attack_Pieces[1].GetBoard() | Bit_Knight_Attack_Pieces[0].GetBoard() | Bit_Bishop_Attack_Pieces[1].GetBoard() | Bit_Bishop_Attack_Pieces[0].GetBoard() | Bit_King_Attack_Pieces[0].GetBoard() | Bit_Queen_Attack_Pieces[0].GetBoard() );
	
	//Do the pawns for both
	for(int tempX = 0; tempX < 8; tempX++)
		Bit_Black_Attack_Pieces->OR_BitBoard(Bit_Pawn_Attack_Pieces[tempX].GetBoard());

	for(int tempX = 8; tempX < 16; tempX++)
		Bit_White_Attack_Pieces->OR_BitBoard(Bit_Pawn_Attack_Pieces[tempX].GetBoard());
	
	
	//Bit_Pawn_Attack_Pieces[3].GetBoard() | Bit_Pawn_Attack_Pieces[4].GetBoard()
	//Bit_Black_Attack_Pieces

#if (BUILD_TYPE == PRIVATE_MODE)
	//cout << "Piece Id and Color and Type: " << PieceId << " " << ChessBlocks[uIndex].bWhite_Black << " " << tempBlock->Piece->Title << "\n";
//	cout << "White_Attack_Board\n";
//	Bit_White_Attack_Pieces->Drawboard();
//	cout << "Black_Attack_Board\n";
//	Bit_Black_Attack_Pieces->Drawboard();

//	cout << "\n\nWhite_Alive\n";
//	Alive_White_Pieces.Drawboard();
//	cout << "Black_Alive \n";
//	Alive_Black_Pieces.Drawboard();

	
#endif



	return true;
}

bool cChessBoard::PrintBoard()
{
	UINT xPos = 0, yPos = 0;
	UINT uTemp = 0;

	//static char AlphaBet[8] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
	static char AlphaBet[8] = {'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A'};
	for(UINT y = 8; y >= 1; y--)
	{
		//cout << AlphaBet[y-1] << ": ";
		cout << y << ": ";
		for(UINT x = 1; x <= 8; x++)
		{
			xPos = x-1;
			yPos = y-1;

			//Linear memory allocation needs to be split into chunks of 8 with 8 blocks in each row
			uTemp = ((yPos*8)+xPos);

			if( (uTemp > 63) )
			{
				CLog::Get()->WriteError("PrintBoard: Transform of number exceeds maximum.");
				return false;
			}

			cout << ChessBlocks[uTemp].Piece->Title[0] << " ";

		}

		cout << "\n";
	}

	//Draw bottom border and numbers
	cout << "   ";
	for(int x = 0; x < 8; x++)
		cout << "-" << " ";
	cout << "\n";

	cout << "   ";
	for(int x = 0; x < 8; x++)
		cout << x+1 << " ";
	cout << "\n";



	return true;
};



