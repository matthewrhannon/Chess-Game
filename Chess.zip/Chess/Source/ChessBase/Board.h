//Board 7/20/11 

#ifndef _BOARD_
#define _BOARD_

#include "Main.h"

#include "Log.h"
#include "Vector.h"


#include "ChessBlocks.h"
#include "Pieces.h"
#include "Bitboard.h"

//#include "Pawn.h"
//#include "Bishop.h"
//#include "Knight.h"
//#include "Rook.h"

class cPiece;
class cChessBlock;

class cChessBoard
{
	public:
		//friend class cChessBlock;

		cChessBoard() 
		{
			ChessBlocks = NULL; 
			AttackMovement = false;

			TotalWhiteValue = TotalBlackValue = Backup_TotalWhiteValue = Backup_TotalBlackValue = 0;
		};
	
		~cChessBoard() 
		{
			SafeDelete(ChessBlocks);
		};

		bool InitalizeBoard();

		bool MovePiece(UINT _xPosOld, UINT _yPosOld, UINT _xPosNew, UINT _yPosNew);

		bool Move(UINT _xPosOld, UINT _yPosOld, UINT _xPosNew, UINT _yPosNew);
		bool UndoMove(UINT _xPosOld, UINT _yPosOld, UINT _xPosNew, UINT _yPosNew);

		bool VaildateMove(UINT uindex, UINT xNew, UINT yNew);

		UINT VaildateCheckType(UINT xOldPos, UINT yOldPos, UINT xNewPos, UINT yNewPos);
		bool VaildateCheckmate(bool _bWhite_Black);

		bool PrintBoard();

		//Return true for good values and false otherwise
		static bool BoundsChecker(UINT xPos, UINT yPos)
		{
			if((xPos >= 1) && (xPos <= 8))
				if((yPos >= 1) && (yPos <= 8))
					return true;
				else
					return false;
			else
				return false;
		};

		static PIECE_TYPE GetPieceType(UINT xPos, UINT yPos)
		{
			/*
			  8 R B H Q K H B R	 Black
			  7 P P P P P P P P
			  6
			  5
			  4
			  3
			  2 P P P P P P P P 
			  1 R B H K Q H B R	 White

			    A B C D E F G H 
				(Note: Using A=1 -> H=8 most of time)
			*/

			cChessBlock *BlockTemp = GetBlockData(xPos, yPos);

			//First check for pawn
			if( (yPos == 2) || (yPos == 7) )
				return PAWN;
			else if( (yPos > 2) && (yPos < 7) )
				return EMPTY;
			else if( (yPos == 1) || (yPos == 8) ) 
			{ //Figure out which special piece it is

				switch(xPos)
				{
					case 1:
						return ROOK;
					break;

					case 2:
						return KNIGHT;
					break;
				
					case 3:
						return BISHOP;
					break;

					case 4:
					//	if(BlockTemp->bWhite_Black)
					//	if(BlockTemp->Piece->bTeamColor)
							return QUEEN;

						break;

					case 5:
					//	if(BlockTemp->Piece->bTeamColor)
							return KING;

					break;

					case 6:
						return BISHOP;
					break;

					case 7:
						return KNIGHT;
					break;

					case 8:
						return ROOK;
					break;
				}

			}
			else
			{
				CLog::Get()->WriteError("GetPieceType: Unknown returned on piece from position. xPos: %d yPos: %d", xPos, yPos);
				return UNKNOWN;
			}

			return UNKNOWN;
		};

		static bool GetBlockColor(UINT xPos, UINT yPos) //Return: true is white, false is black
		{
			// Odd Odd    B
			// Even Even  B
			// Odd Even	  W
			// Even Odd   W

			if( is_odd(xPos) && is_odd(yPos) ) 
			{ 
				return false;
			}
			else if( !is_odd(xPos) && !is_odd(yPos) ) 
			{
				return false;
			}		
			else if( is_odd(xPos) && !is_odd(yPos) ) 
			{
				return true;;
			}		
			else if( !is_odd(xPos) && is_odd(yPos) ) 
			{
				return true;
			}
			else
			{
				CLog::Get()->WriteError("GetBlockColor - %d %d: Invalid block color. Returning false...");
				return false;
			}

			return false;
		};

	public:
		static bool is_odd(UINT n)
		{
			return ((n % 2) != 0);
		};

		static cChessBlock *GetBlockData(UINT xPos, UINT yPos)
		{
			static UINT uTemp = 0;

			if(ChessBlocks && BoundsChecker(xPos, yPos))
			{
				//For zero compensation
				xPos--;
				yPos--;

				//Linear memory allocation needs to be split into chunks of 8 with 8 blocks in each row
				uTemp = ((yPos*8)+xPos);

				if( (uTemp > 63) )
				{
					CLog::Get()->WriteError("GetBlockData: Transform of number exceeds maximum. ");
					return NULL;
				}

				return &ChessBlocks[uTemp];
			}
			else
			{
				CLog::Get()->WriteError("GetBlockData: Either ChessBlocks memory invalid or invalid input numbers.");
				return NULL;
			}
		};

		bool UpdateAttackBitBoards();

		
	public:
		//Is something happening where an attack on a non-empty square is occurring
		bool AttackMovement;

		//Check/Checkmate stuff
		bool bWhiteChecked;
		bool bBlackChecked;

		bool bWhiteCheckmated;
		bool bBlackCheckmated;

		//BitBoard stuff
		static cChessBlock *ChessBlocks; //Going to be 64 - 8x8 blocks in memory to simulate board
		static cPiece **DeadChessPieces;
		static UINT DeadPieceCounter;

		/*	Bitboards for piece positions */
		//General pieces
		cBitboard *Bit_All_Pieces, Backup_Bit_All_Pieces;
		cBitboard *Bit_White_Pieces, Backup_Bit_White_Pieces;
		cBitboard *Bit_Black_Pieces, Backup_Bit_Black_Pieces;

		//Specific pieces
		cBitboard *Bit_wPawn_Pieces, Backup_Bit_wPawn_Pieces;
		cBitboard *Bit_bPawn_Pieces, Backup_Bit_bPawn_Pieces;
		cBitboard *Bit_wBishop_Pieces, Backup_Bit_wBishop_Pieces;
		cBitboard *Bit_bBishop_Pieces, Backup_Bit_bBishop_Pieces;
		cBitboard *Bit_wKnight_Pieces, Backup_Bit_wKnight_Pieces;
		cBitboard *Bit_bKnight_Pieces, Backup_Bit_bKnight_Pieces;
		cBitboard *Bit_wRook_Pieces, Backup_Bit_wRook_Pieces;
		cBitboard *Bit_bRook_Pieces, Backup_Bit_bRook_Pieces;

		//One pieces
		cBitboard *Bit_wQueen_Piece, Backup_Bit_wQueen_Piece;
		cBitboard *Bit_bQueen_Piece, Backup_Bit_bQueen_Piece;
		cBitboard *Bit_wKing_Piece, Backup_Bit_wKing_Piece;
		cBitboard *Bit_bKing_Piece, Backup_Bit_bKing_Piece;


		/*	Bitboards for piece attack positions */
		//General pieces
		//cBitboard *Bit_All_Pieces;

		//FIXME: Are the following backup vars really needed?
		cBitboard *Bit_White_Attack_Pieces, Backup_Bit_White_Attack_Piece;
		cBitboard *Bit_Black_Attack_Pieces, Backup_Bit_Black_Attack_Piece;

		//Specific pieces
		cBitboard *Bit_Pawn_Attack_Pieces, Backup_Bit_Pawn_Attack_Piece;
		cBitboard *Bit_Bishop_Attack_Pieces, Backup_Bit_Bishop_Attack_Piece;
		cBitboard *Bit_Knight_Attack_Pieces, Backup_Bit_Knight_Attack_Piece;
		cBitboard *Bit_Rook_Attack_Pieces, Backup_Bit_Rook_Attack_Piece;

		//One pieces
		cBitboard *Bit_Queen_Attack_Pieces, Backup_Bit_Queen_Attack_Piece;
		cBitboard *Bit_King_Attack_Pieces, Backup_Bit_King_Attack_Piece;

		//Total piece values
		int TotalWhiteValue, TotalBlackValue, Backup_TotalWhiteValue, Backup_TotalBlackValue;



};





#endif
