//Written by Matthew Hannon 1/14/12

#include "ChessAI.h"

int cChessAI::Static_Evaluation(UINT PosX, UINT PosY, bool bTeam)
{




	return 0;
};

int cChessAI::Search(UINT PosX, UINT PosY, bool bTeam, UINT Depth, int Alpha, int Beta)
{





	return 0;
};