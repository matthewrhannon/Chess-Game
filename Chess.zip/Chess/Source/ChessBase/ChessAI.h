//Written by Matthew Hannon 1/14/12

#ifndef __CHESSAI__
#define __CHESSAI__

#include "Main.h"
#include "Game.h"
#include "Bitboard.h"


/* WHAT I WANT:
	-chess ai semi-good
		-use alpha beta prunning
		-need static and dynamic evaluation function
			-use search extensions

	-Need structure for backup of game state on recursion...

*/
//if(cChessGame::Get()->ChessBoard->MovePiece(Controller::curController->MoveXold, Controller::curController->MoveYold, Controller::curController->MoveXnew, Controller::curController->MoveYnew))	


struct TEMP_GAMESTATE
{
	cBitboard All_Pieces;
	cBitboard White_Pieces, BlackPieces;
	cBitboard wPawn_Pieces, bPawn_Pieces;
	cBitboard wBishop_Pieces, bBishop_Pieces;
	cBitboard wKnight_Pieces, bKnight_Pieces;
	cBitboard wRook_Pieces, bRook_Pieces;
	cBitboard wQueen_Piece, bQueen_Piece;
	cBitboard wKing_Piece, bKing_Piece;

	int WhiteValue, BlackValue;
};


/* WHERE I AM AT:
	
	Appearently I am leaving soon for Leavenworth according to the conversation between Justin and Mother that I just overheard.
	Therefore I am going to summarize where my mind currently is as relating to this program:
		Mind: 
			The chess AI's ultimate goal is to mate the king, so fundamentally the checkmate and check algorithms in ChessBase
			must work correctly or we are building atop of unstable ground. FIX THIS..Please.

			The static evaluation function is going to have to call into Board.cpp quite a bit, this could lead to latency issues...
			Also the static eval. function should call into a more indepth evaluation function that judges things like pawn advancements and control of center board.

			I am also going to need to adapt a way to use the bitboard temp struct so the game state is saved multiple recursions in.. maybe just overload the function with extra parameter?

			Much of the current game functionality is based inside of Controller.cpp. This is bad design! FIX THIS and put it into ChessBase game file...




*/

class cChessAI
{	
	public:
		cChessAI()
		{




		};

		~cChessAI()
		{




		};

		//search(position,side,depth,alpha,beta)

		int Search(UINT PosX, UINT PosY, bool bTeam, UINT Depth, int Alpha, int Beta);


		int Static_Evaluation(UINT PosX, UINT PosY, bool bTeam); //Note: bTeam == true for white and vice versa
	private:








};


/*
(Set depth initially to required value)

SEARCHING_FUNCTION {

  Decrease depth by 1

  Loop through all moves

    Play move
  
    if ( depth = 0 ) move_score = static_position_score
    else move_score = - Opponent's_best_move_score
    
    if ( move_score > best_move_score ) then ( best_move = move )
    
    Undo Move
 
  End of Loop

  Return best_move_score

} END
*/



/*
initially alpha = -INFINITY, beta=INFINITY

search(position,side,depth,alpha,beta) {

  best_score = -INFINITY
  
  for each move {

    do_move(position, move)
      
      if ( depth is 0 )   move_score = static_score(position, side)
      else   move_score = - search(position, opponent side, depth-1, -beta, -alpha)
      
    undo_move(position,move)
    
    if ( move_score > best_score )   best_score = move_score
    if ( best_score > alpha )   alpha = best_score
    if ( alpha >= beta )   return alpha
  }
  
  return best_score
  
}
(
*/






#endif