//7/23/11 Matt H
#ifndef _CHESS_BLOCKS_
#define _CHESS_BLOCKS_

#include "Main.h"

#include "Log.h"
#include "Vector.h"

#include "Pieces.h"

class cPiece;

//Blocks on board declarations
class cChessBlock
{
	public:
		cChessBlock()
		{
			Piece = NULL;
			ConnectedBlocks = NULL; //ADDME: Link list

			xPos = yPos = 0;
			bTopBottomPos = false;
			Attributes = NULL;
			bColored = true; //1x1 square is black w/ white nearest

			bWhite_Black = true; //true = white black = false
		};

		~cChessBlock()
		{
			//FIXME: It doesnt know what Piece to delete. It needs to know later on what type of piece
			/*if(Piece)
			{
				delete Piece;
				Piece = 0;
			}*/
		};

		//friend class cChessBoard;


	public:
		cPiece *Piece;  // null for empty block(64)
		UINT xPos, yPos; //xPos later translated to A-H, and starts on lower left with side of white
		cChessBlock *ConnectedBlocks;
		bool bTopBottomPos; //Is block on rows 1 or 8

		//BitPattern for Attributes
		/*
			0x00 = NeutralSquare
			0x01 = WhiteSquare
			0x10 = BlackSquare
			0x11 = KingSquare
			0xFF = ...


		*/
		UCHAR Attributes; 

		bool bColored; //For black/white blocks
		bool bWhite_Black; //For white/black team

		/*
		PIECE_TYPE GetType()
		{
			if(Piece != NULL)
				return Piece->Type;
			else
				CLog::Get()->WriteError("cChessBlock_GetType: Invalid piece pointer.");

			return UNKNOWN;
		};
		*/
};

#endif