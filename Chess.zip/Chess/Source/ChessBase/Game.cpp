//Game.cpp 7/20/11

#include "Game.h"

//Init variables and singleton
cChessGame *cChessGame::Instance = 0;
//char g_Buffer[512];

/*
  8 R B H Q K H B R
  7 P P P P P P P P
  6
  5
  4
  3
  2 P P P P P P P P 
  1 R B H K Q H B R

    A B C D E F G H
*/

UINT cChessGame::InitalizeGame()
{
	//Initalize chessboard
	if(!ChessBoard)
		ChessBoard = new cChessBoard;
	else
	{
		CLog::Get()->WriteError("cChessGame_InitalizeGame: ChessBoard object already exists!");
		return 0;
	}

	if(!ChessBoard->InitalizeBoard())
	{
		CLog::Get()->WriteError("cChessGame_InitalizeGame: InitalizeBoard failed!");
		return 0;
	}


	return 1;
}

UINT cChessGame::UninitalizeGame()
{

	return 1;
}

UINT cChessGame::BeginMatch(UINT Settings)
{
	//Initalize board/game conditions
	ChessBoard->bWhiteChecked = false;
	ChessBoard->bBlackChecked = false;
	ChessBoard->bWhiteCheckmated = false;
	ChessBoard->bBlackCheckmated = false;

	return 1;
}

UINT cChessGame::EndMatch(UINT Settings)
{


	return 1;
}

