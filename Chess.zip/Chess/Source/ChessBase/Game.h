//Game 7/20/11 

#ifndef _GAME_
#define _GAME_

#include "Main.h"
#include "Board.h"

//Chess game main class
class cChessGame
{
public:
	static cChessGame *Get()
	{
		if(!Instance)
			Instance = new cChessGame;
		return Instance;
	}

	cChessGame()
	{
		ChessBoard = NULL;

	}
	~cChessGame()
	{
		if(Instance)
			delete Instance;
		Instance = 0;

		SafeDelete(ChessBoard);
	}

	UINT InitalizeGame();
	UINT UninitalizeGame();

	UINT BeginMatch(UINT Settings);
	UINT EndMatch(UINT Settings);

	cChessBoard *ChessBoard;

private:
	static cChessGame *Instance;

	


};




/*
enum PIECE {ROOK = 0, KNIGHT, BISHOP, QUEEN, KING, PAWN}; // 6 := 2^3 = 8
struct ITEM_ATTRIBUTES
{
	PIECE Type;
};

struct ITEM_PIECE
{
	unsigned char blType; //bl bitlist
	unsigned int xPos, yPos;
	bool bDead;
	bool bEmpty;
	
	ITEM_ATTRIBUTES *Attributes;
};

struct BOARD
{
	ITEM_PIECE White[15], Black[15]; 
	ITEM_PIECE Board[7][7]; //8x8 = 64 slots

	bool bCheck;
	bool bCheckMate;
};

/*
  8 R B H Q K H B R
  7 P P P P P P P P
  6
  5
  4
  3
  2 P P P P P P P P 
  1 R B H K Q H B R

    A B C D E F G H
*/


#endif
