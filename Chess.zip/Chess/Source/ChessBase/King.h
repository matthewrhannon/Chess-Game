//King 7/24/11 

#ifndef _KING_
#define _KING_

#include "Main.h"

#include "Log.h"
#include "Vector.h"

#include "Board.h"
#include "ChessBlocks.h"
#include "Pieces.h"

class cPiece;

class cKing : public cPiece
{
public:
	cKing() : cPiece(KING, "King")
	{
		PieceIdentifier = (int)King_Piece_Count--;
		PieceValue = GENERIC_KING_VALUE;

		if(!bBitBoard_Built)
		{
			Initalize();	
			bBitBoard_Built = true;
		}
	};

	~cKing() 
	{
		Deinitalize();
	};

	bool Initalize()
	{
		//////////////////////////////////////////////////////////////
		//Bitboard stuff
		//////////////////////////////////////////////////////////////

		//Initalize 64 bitboards for the rook (?is this even a efficient way to do this?)
		King_BitBoards = new cBitboard[64];

		cBitboard tempBitBoard;

		UINT uTempPos = 0;

		xPiecePos = yPiecePos = 1;

		//Loop through each of the 64 bitboards for the rook potential locations
		for(yPiecePos = 1; yPiecePos <= 8; yPiecePos++)
		{
			for(xPiecePos = 1; xPiecePos <= 8; xPiecePos++)
			{
				//Update piece to next location
				uTempPos = (((yPiecePos-1)*8)+(xPiecePos-1));

				//Loop through each square, and generate bitboards that represent potentially valid moves
				for(UINT cur_Y = 1; cur_Y <= 8; cur_Y++)
				{
					for(UINT cur_X = 1; cur_X <= 8; cur_X++)
					{
						//Lets start by running through one rook pattern, say x = y = 1 Position placement of rook, and find potential movements
						if( Movement(cur_X, cur_Y) == 1 )
						{	//Success move
							King_BitBoards[uTempPos].SetBit(cur_X, cur_Y);
						}
					}
				}

				//Test if same square as position being tested
				//if( (xPiecePos != cur_X) && (yPiecePos != cur_Y) )
				King_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos);
			//	King_BitBoards[uTempPos].Drawboard();
			//	cout << "\n";
			}

		}

		//REMEMBERME: Remember to reset x/y position values after all this!
		xPiecePos = yPiecePos = 1;


		return true;
	};

	bool Deinitalize()
	{
		Type = UNKNOWN;
		bBitBoard_Built = false;

		SafeDelete(King_BitBoards);
		return true;
	};

	UINT Movement(UINT xPos, UINT yPos)
	{
		//King - Well it moves maximum a length of 1 square in any possible direction (unless castling)
		//		 Cannot move into harms way, also check for check/checkmate
			 

		//First test if move is in boundaries
		if(cChessBoard::BoundsChecker(xPos, yPos))
		{ 
			//Now check if length is proper for movement
			if( ((abs(int(xPos) - int(xPiecePos)) == 1) && (abs(int(yPos) - int(yPiecePos)) == 0)) )
				return 1;
			else if( ((abs(int(xPos) - int(xPiecePos) == 0) && (abs(int(yPos) - int(yPiecePos)) == 1))) )
				return 1;
			else if( ((abs(int(xPos) - int(xPiecePos)) == 1) && (abs(int(yPos) - int(yPiecePos)) == 1)) )
				return 1;					
			else
			{
				#if (BUILD_TYPE == DEBUG_MODE)
					//I don't think it is a valid move..Have not added castling / other yet note..
					CLog::Get()->WriteEx("King_Movement: Movement not showing magnitude of 1");
				#endif

				return 0;
			}
			

			//ADDME: Is something potentially in the way? !!!

			return 0;


		}
		else
		{
			CLog::Get()->WriteError("King_Movement: Outside boundaries");
			return 0;
		}


		return 0;
	};

	UINT Action()
	{

		return 1;
	};

	UINT Special()
	{

		return 1;
	};

	static cBitboard *King_BitBoards;
	static bool bBitBoard_Built;

private:



};

cBitboard *cKing::King_BitBoards = NULL;
bool cKing::bBitBoard_Built = false;
#endif



