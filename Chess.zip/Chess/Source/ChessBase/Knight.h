//Board 7/20/11 

#ifndef _KNIGHT_
#define _KNIGHT_

#include "Main.h"

#include "Log.h"
#include "Vector.h"
#include "Board.h"
#include "ChessBlocks.h"
#include "Pieces.h"

class cPiece;

class cKnight : public cPiece
{
	//friend class cPiece;

	public:
		cKnight() : cPiece(KNIGHT, "Knight")
		{
			//Knight_BitBoards = NULL;
			PieceIdentifier = (int)Knight_Piece_Count--;
			PieceValue = GENERIC_KNIGHT_VALUE;

			if(!bBitBoard_Built)
			{
				Initalize();	
				bBitBoard_Built = true;
			}
		
		};

		~cKnight() 
		{
			Deinitalize();
		};

		bool Initalize()
		{
			strcpy(Title, "Knight");
			Type = KNIGHT;


			//////////////////////////////////////////////////////////////
			//Bitboard stuff
			//////////////////////////////////////////////////////////////
			
			//Initalize 64 bitboards for the rook (?is this even a efficient way to do this?)
			Knight_BitBoards = new cBitboard[64];

			cBitboard tempBitBoard;

			UINT uTempPos = 0;

			xPiecePos = yPiecePos = 1;

			//Loop through each of the 64 bitboards for the rook potential locations
			for(yPiecePos = 1; yPiecePos <= 8; yPiecePos++)
			{
				for(xPiecePos = 1; xPiecePos <= 8; xPiecePos++)
				{
					//Update piece to next location
					uTempPos = (((yPiecePos-1)*8)+(xPiecePos-1));

					//Loop through each square, and generate bitboards that represent potentially valid moves
					for(UINT cur_Y = 1; cur_Y <= 8; cur_Y++)
					{
						for(UINT cur_X = 1; cur_X <= 8; cur_X++)
						{
							//Lets start by running through one rook pattern, say x = y = 1 Position placement of rook, and find potential movements
							if( Movement(cur_X, cur_Y) == 1 )
							{	//Success move
									Knight_BitBoards[uTempPos].SetBit(cur_X, cur_Y);
							}
						}
					}

					//Test if same square as position being tested
					//if( (xPiecePos != cur_X) && (yPiecePos != cur_Y) )
					Knight_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos);
//					Knight_BitBoards[uTempPos].Drawboard();
	//				cout << "\n";
				}



			}


			//REMEMBERME: Remember to reset x/y position values after all this!
			xPiecePos = yPiecePos = 1;

			return true;

		};

		bool Deinitalize()
		{
			Type = UNKNOWN;

			bBitBoard_Built = false;
			SafeDelete(Knight_BitBoards);

			return true;
		};

		UINT Movement(UINT xPos, UINT yPos)
		{

			//Note: Knight moves in semi L pattern. Patter length 3 squares then hook. Four square total for basic validity,
			//		and in correct pattern type.
			// Start first with basic length verification, then proceed backwards from NewPos with 1 block test of right handle, then test for 3 and/or valid move.

			//Testing if valid length of movement


			cVector vNewPos(xPos, yPos, 0);
			cVector vCurPos(xPiecePos, yPiecePos, 0);

			cVector vDelta = vNewPos.Subtract(vCurPos);
			float fLengthTemp = vDelta.Length();
	
			//FIXME: quick hack for length of valid knight move
			static float fProperLength = sqrt(float(1*1 + 2*2));

			if( (fLengthTemp >= fProperLength-EPSILON) && (fLengthTemp <= fProperLength+EPSILON) ) 
				goto Valid_Length;
			else
			{
				#if (BUILD_TYPE == DEBUG_MODE)
					CLog::Get()->WriteError("Knight_Movement: Knight invalid move length is not %f != %f", fLengthTemp, fProperLength);
				#endif
				
				return 0;
			}


			Valid_Length:
			//12 21
			if( ((abs(int(xPos) - int(xPiecePos)) == 1) || (abs(int(xPos) - int(xPiecePos)) == 2)) )
			{
				if( ((abs(int(yPos) - int(yPiecePos)) == 1) || (abs(int(yPos) - int(yPiecePos)) == 2)) )
				{
					//Valid knight move	
					return 1;
				}
			}

			//If reached here, invalid I think...?
			CLog::Get()->WriteEx("Knight_Movement: Knight invalid move");
			return 0;
		};

		UINT Action()
		{

			return 1;
		};

		UINT Special()
		{

			return 1;
		};
		
		static cBitboard *Knight_BitBoards;
		static bool bBitBoard_Built;

	private:


};

cBitboard *cKnight::Knight_BitBoards = NULL;
bool cKnight::bBitBoard_Built = false;


#endif