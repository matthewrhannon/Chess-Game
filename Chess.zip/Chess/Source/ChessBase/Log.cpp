//Logger 7/20/11

#include "Log.h"

CLog *CLog::Instance = 0;

CLog::CLog()
{
	LogFile = NULL;
	Extensions = true;
	sprintf(g_Buffer, "%s.txt", TARGET_NAME);
	strcpy(LogPath, "Log.txt");
}

CLog::~CLog()
{
	UnLoad();
	if(Instance)
		delete Instance;
	Instance = 0;
}

void CLog::Load()
{
	LogFile = fopen(LogPath, "w");

	if(!LogFile)
		return;

	fputs("******************************", LogFile);
	
	WriteHeader(); 

	//WriteCompInfo();
}

void CLog::UnLoad()
{
	LineDown();

	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	fputs("\n******************************", LogFile);
	
	fclose(LogFile);
	LogFile = NULL;
}

void CLog::Write(char *Text)
{
	if(!strlen(Text))
		return;

	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	 sprintf(Text1, "\n%s", Text);

	fputs(Text1, LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::WriteEx(char *Text, ...)
{	
	if(!strlen(Text))
		return;

	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	va_list List;
	char Temp[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	sprintf(Text1, "\n%s", Temp);

	fputs(Text1, LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

bool CLog::WriteRisky(char *Text, ...)
{
	if(!strlen(Text))
		return false;

	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	if(LogFile)
	{
		va_list List;
		char Temp[256];

		va_start(List, Text);
			vsprintf(Temp, Text, List);
		va_end(List);

		sprintf(Text1, "\n%s", Temp);

		fputs(Text1, LogFile);

		return true;
	}

	return false;
}

/*
void CLog::WriteCompInfo()
{
	SYSTEMTIME Time;
	GetLocalTime(&Time);

	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	fputs("\n****************", LogFile);
	sprintf(TempString, "\n   Comp Info");
	fputs(TempString, LogFile);
	sprintf(TempString, "\nTime: %d:%d", Time.wHour, Time.wMinute);
	fputs(TempString, LogFile);
	sprintf(TempString, "\nDate: %d/%d/%d", Time.wMonth, Time.wDay, Time.wYear);
	fputs(TempString, LogFile);
	fputs("\n****************", LogFile);
	LineDown();
	
	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}
*/

void CLog::WriteHeader()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	fputs("\n****************", LogFile);
	sprintf(TempString, "\n   Engine Info");
	fputs(TempString, LogFile);
	fputs("\nEngine Name: ", LogFile);
	fputs(PROGRAM_NAME, LogFile);
	fputs("  \nBy Matthew Hannon\n", LogFile);
	sprintf(TempString, "\nVersion: %s", PROGRAM_VERSION);
	fputs(TempString, LogFile);
	fputs("\n****************", LogFile);
	
	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::WriteError(char *Text1, ...)
{
	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	va_list TempList1;

	if(!strlen(Text1))
		return;

	va_start(TempList1, Text1);
		vsprintf(TempString1, Text1, TempList1);
	va_end(TempList1);
	
	sprintf(TempString, "\n**ERROR** %s", TempString1);

	fputs(TempString, LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::LineDown()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "a+");

	fputc('\n', LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}
