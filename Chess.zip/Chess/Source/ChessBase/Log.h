//Logger.h 7/20/11

#ifndef LOG_SYSTEM_FILE
#define LOG_SYSTEM_FILE

#include "Main.h"

class CLog
{
	public:
		static CLog *Get()
		{
			if(!Instance)
				Instance = new CLog;
			return Instance;
		}

		CLog();
		~CLog();

		void Load();
		void UnLoad();
		
		void Write(char *Text);
		void WriteEx(char *Text, ...);

		//It just writes without making sure the write more than likely took place.
		bool WriteRisky(char *Text, ...);

		void WriteHeader();
		void WriteCompInfo();

		void WriteError(char *Text1, ...);
		void LineDown();

	private:
		static CLog *Instance;
		FILE *LogFile;
		char Text1[255];

		bool Extensions;
		char TempString[64];
		char TempString1[64];
		char ExtensionString[512];
		char LogPath[32];

		char g_Buffer[256];
};



#endif
