#include <iostream>
#include <stdio.h>
//NOTE... 
#include <windows.h>

#include "Main.h"
#include "Log.h"
#include "Game.h"

void __cdecl ExitFunction()
{
	//Deinitalize 
	cChessGame::Get()->UninitalizeGame();
	CLog::Get()->UnLoad();
}

int main()
{
	
	cout << "Chess Base - Matt Hannon\n\n";
	//will i finish this?fjfiojfjii I hope so.. progress has been made, but many stages and current issues to still face...
	atexit(ExitFunction);
	
	CLog::Get()->Load();

	//Start chess game
	if(cChessGame::Get()->InitalizeGame() != 1)
	{
		CLog::Get()->WriteError("Main: Failed to initialize chess game");
		return 0;
	}

	//Start a match 
	//Note: 0x00 now as place holder for potential later features
	if(cChessGame::Get()->BeginMatch(0x00) != 1)
	{
		CLog::Get()->WriteError("Main: Failed to begin match");
		return 0;
	}

	//Lets test the code so far...
	bool bExit = false;
	char strInputOld[4], strInputNew[4];
	strcpy(strInputOld, "");
	strcpy(strInputNew, "");
	
	while(!bExit)
	{
		cout << "\n\n";
		cChessGame::Get()->ChessBoard->PrintBoard();

		cout << "Enter Move (Format: Old New - A1 B1) -- (X to exit)\n";
		cin >> strInputOld >> strInputNew;

		//Test if exiting
		if(strcmp(strInputOld, "X") == 0)
			bExit = true;

		//Now need to print board, and move pieces along with valid moves. If not valid, say so!
		//Question to self: Will any of this code work!?

		char strTemp[4];

		sprintf(strTemp, "%c", (char *)strInputOld[0]);
		UINT xPosOld = atoi(strTemp);

		sprintf(strTemp, "%c", (char *)strInputOld[1]);
		UINT yPosOld = atoi(strTemp);

		sprintf(strTemp, "%c", (char *)strInputNew[0]);
		UINT xPosNew = atoi(strTemp);

		sprintf(strTemp, "%c", (char *)strInputNew[1]);
		UINT yPosNew = atoi(strTemp);

		if(cChessGame::Get()->ChessBoard->MovePiece(xPosOld, yPosOld, xPosNew, yPosNew))
		{
			cout << "SUCCESS - Valid Move - xPosOld: " << xPosOld << " yPosOld: " << yPosOld << " xPosNew: " << xPosNew << " yPosNew: " << yPosNew << "\n";
		}
		else
		{
			cout << "ERROR - Invalid Move - xPosOld: " << xPosOld << " yPosOld: " << yPosOld << " xPosNew: " << xPosNew << " yPosNew: " << yPosNew << "\n";
		}

		//Test for checkmate scenario
		//Check for white king checkmate
		if(cChessGame::Get()->ChessBoard->VaildateCheckmate(true))
		{
			cout << "WHITE KING IS IN CHECKMATE\n";
			ExitFunction();
			goto Exit;
		}
		
		if(cChessGame::Get()->ChessBoard->VaildateCheckmate(false))
		{
			cout << "BLACK KING IS IN CHECKMATE\n";
			ExitFunction();
			goto Exit;
		}

	}

	Exit:
	return 0;




};