//Main 7/24/11 

#ifndef _MAIN_
#define _MAIN_

#define WIN32_LEAN_AND_MEAN

#include <iostream>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <assert.h>

using namespace std;

//Visual studio helper stuff
#define _CRT_SECURE_NO_DEPRECATE //Annoying!!!!
#pragma warning(disable:4996) //Depreciation annoyance
#pragma warning(disable:4244) //I am hard headed and overally annoyed by these warnings. Headaches perhaps in the future?!

#define inline __forceinline

#define UINT unsigned int
#define UCHAR unsigned char

enum PIECE_TYPE {ROOK = 0, KNIGHT, BISHOP, QUEEN, KING, PAWN, EMPTY, UNKNOWN};

//Setup program specific stuff
#define PROGRAM_NAME "Chess_Base"
#define PROGRAM_VERSION "0.40"

#define TARGET_NAME "Chess_Base"
#define TARGET_WINDOW_NAME "Chess_Base"


//Modes of build
#define DEBUG_MODE	 0
#define PRIVATE_MODE 1
#define PUBLIC_MODE  2

#define BUILD_TYPE PRIVATE_MODE //PRIVATE_MODE

//////////////////////////////////////////
#define DWORD ULONG
#define WORD USHORT 
#define BYTE UCHAR

#define inline __forceinline

#define SafeDelete(Object) {if(Object) delete Object; Object = 0; };
#define QuickMsg(Text) {	printf(Text);	};

//extern char g_Buffer[512];

//64 bit data type
#ifndef _WIN64
typedef unsigned long long QWORD;
#else
typedef unsigned long QWORD;
#endif


//Some quick math stuff
#define PI 3.14159265358f //is this right?
#define EPSILON 0.0001f

#define DEG2RAD(fvalue) ((PI/180)*fvalue)



//#define CMP_ERROR_CORRECT()



#endif