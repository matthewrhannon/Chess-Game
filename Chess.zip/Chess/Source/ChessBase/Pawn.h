//Board 7/20/11 

#ifndef _PAWN_
#define _PAWN_

class cVector;
class cPiece;


#include "Main.h"
#include "Log.h"
#include "Vector.h"

#include "Pieces.h"
//#include "ChessBlocks.h"
class cPiece;

class cPawn : public cPiece
{
	public:
		cPawn() : cPiece(UNKNOWN, "UNKNOWN PAWN COLOR")
		{
			PieceIdentifier = (int)Pawn_Piece_Count--;
			PieceValue = GENERIC_PAWN_VALUE;
		
			CLog::Get()->WriteError("cPawn_Constructor: Called without specifying color of pawn piece...Assuming white!");
			bWhitePawns = true;
		//	White_Pawn_BitBoards = NULL;
			//Black_Pawn_BitBoards = NULL;
		};

		cPawn(bool bWhite) : cPiece(PAWN, "Pawn")
		{
			PieceIdentifier = (int)Pawn_Piece_Count--;
			PieceValue = GENERIC_PAWN_VALUE;
		
			bWhitePawns = bWhite; 
			//White_Pawn_BitBoards = NULL;
		//	Black_Pawn_BitBoards = NULL;

			//Two separate bitboards for the black and white bishops
		
			if(!bWhite_BitBoard_Built || !bBlack_BitBoard_Built)
			{
				Initalize();
				bWhite_BitBoard_Built = true;
				bBlack_BitBoard_Built = true;
			}
			
			/*
			if(!bWhite_BitBoard_Built)
			{
				Initalize();	
				bWhite_BitBoard_Built = true;
			}
			
			if(!bBlack_BitBoard_Built)
			{
				Initalize();	
				bBlack_BitBoard_Built = true;
			}
			*/
		};


		virtual ~cPawn() 
		{
			Deinitalize();
		};
		
		bool Initalize()
		{
			//////////////////////////////////////////////////////////////
			//Bitboard stuff
			//////////////////////////////////////////////////////////////

			//Initalize 64 bitboards for the rook (?is this even a efficient way to do this?)
			cBitboard *tempBitBoardW = new cBitboard[64];
			cBitboard *tempBitBoardB = new cBitboard[64];
			cBitboard *tempBitBoard_AttackW = new cBitboard[64];
			cBitboard *tempBitBoard_AttackB = new cBitboard[64];

			UINT uTempPos = 0;

			xPiecePos = yPiecePos = 1;


			White_Pawn_Attack_BitBoards = tempBitBoard_AttackW;
			Black_Pawn_Attack_BitBoards = tempBitBoard_AttackB;

			//Set the non-attack bitboard for white to the white_pawn bitboard pointer object
			White_Pawn_BitBoards = tempBitBoardW;
			Black_Pawn_BitBoards = tempBitBoardB;

			//set for white
			bWhitePawns = true;

			//Loop through each of the 64 bitboards for the rook potential locations
			//FIXME: Optimize these loops. they are looping through squares the pawn never is able to move to
			for(yPiecePos = 1; yPiecePos <= 8; yPiecePos++)
			{
				for(xPiecePos = 1; xPiecePos <= 8; xPiecePos++)
				{
					//Update piece to next location
					uTempPos = (((yPiecePos-1)*8)+(xPiecePos-1));

					//Reset board
				//	White_Pawn_Attack_BitBoards[uTempPos].SetBoard(0x0);

					//Loop through each square, and generate bitboards that represent potentially valid moves
					for(UINT cur_Y = 1; cur_Y <= 8; cur_Y++)
					{
						for(UINT cur_X = 1; cur_X <= 8; cur_X++)
						{
							//Lets start by running through one rook pattern, say x = y = 1 Position placement of rook, and find potential movements
							if( Movement(cur_X, cur_Y) == 1 )
							{	//Success move
								White_Pawn_BitBoards[uTempPos].SetBit(cur_X, cur_Y);
							}
						
							if( Movement_Attack(cur_X, cur_Y) == 1 )
							{	//Success attack move
								White_Pawn_Attack_BitBoards[uTempPos].SetBit(cur_X, cur_Y);
							}
						}
					}

					//Test if same square as position being tested
					//if( (xPiecePos != cur_X) && (yPiecePos != cur_Y) )
					//Zero out current position of piece in bitboard
					//if(yPiecePos < 2)
					//	White_Pawn_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos); cout << "\n";

					//tempBitBoard_Attack[uTempPos].ResetBit(xPiecePos, yPiecePos);
					White_Pawn_Attack_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos);

					//White_Pawn_Attack_BitBoards[uTempPos].Drawboard();
					//cout << "\n";
				}

			}

			

			bWhitePawns = false; //set for black
			for(yPiecePos = 8; yPiecePos >= 1; yPiecePos--)
			{
				for(xPiecePos = 8; xPiecePos >= 1; xPiecePos--)
				{
					//Update piece to next location
					uTempPos = (((yPiecePos-1)*8)+(xPiecePos-1));
					
					//Reset board
				//	Black_Pawn_Attack_BitBoards[uTempPos].SetBoard(0x0);
					//Loop through each square, and generate bitboards that represent potentially valid moves
					for(UINT cur_Y = 8; cur_Y >= 1; cur_Y--)
					{
						for(UINT cur_X = 8; cur_X >= 1; cur_X--)
						{
							//Lets start by running through one rook pattern, say x = y = 1 Position placement of rook, and find potential movements
							if( Movement(cur_X, cur_Y) == 1 )
							{	//Success move
								Black_Pawn_BitBoards[uTempPos].SetBit(cur_X, cur_Y);
							}

							
							if( Movement_Attack(cur_X, cur_Y) == 1 )
							{	//Success attack move
								Black_Pawn_Attack_BitBoards[uTempPos].SetBit(cur_X, cur_Y);
							}
						}
					}

					//Test if same square as position being tested
					//if( (xPiecePos != cur_X) && (yPiecePos != cur_Y) )
					//Zero out current position of piece in bitboard
					
					
					Black_Pawn_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos);
					/*
					Black_Pawn_Attack_BitBoards[uTempPos].SetBoard(Black_Pawn_BitBoards[uTempPos].GetBoard());
					
					
					if(yPiecePos != 7)
						Black_Pawn_Attack_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos-1);
					//tempBitBoard_Attack[uTempPos].ResetBit(xPiecePos, yPiecePos);
					*/
					
					Black_Pawn_Attack_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos);
				}

			}


			//REMEMBERME: Remember to reset x/y position values after all this!
			xPiecePos = yPiecePos = 1;
			bWhitePawns = false;

			return true;
		};

		bool Deinitalize()
		{
			Type = UNKNOWN;

			bWhite_BitBoard_Built = false;
			bBlack_BitBoard_Built = false;

			SafeDelete(White_Pawn_BitBoards);
			SafeDelete(Black_Pawn_BitBoards);

			return true;

		};
		
		//Function is only used thus far to compute the attack bitboards for the pawn
		UINT Movement_Attack(UINT xPos, UINT yPos)
		{
			cVector vNewPos(xPos, yPos, 0);
			cVector vCurPos(xPiecePos, yPiecePos, 0);

			cVector vDelta = vNewPos.Subtract(vCurPos);
			float fLengthTemp = vDelta.Length();

		//	if(fLengthTemp <= sqrt(2))
			if( ((fLengthTemp) >= (sqrt(2.0f))-EPSILON) && ((fLengthTemp) <= (sqrt(2.0f))+EPSILON) )
				goto Valid_Length;
			else
			{
				#if (BUILD_TYPE == DEBUG_MODE)
					CLog::Get()->WriteError("Movement_Attack: Pawn invalid move  %f", fLengthTemp);
				#endif

				return 0;
			}

			Valid_Length:

			//Normalize stuff
			vDelta.Normalize();

			float fTemp = 0;
			if(bWhitePawns)
				fTemp = 1;
			else
				fTemp = -1;

			cVector vCompare(0, 1, 0);
			vCompare.Normalize();

			//Dot them and look for proper angle
			float fDotty = vCompare.Dot(vDelta);

			//Pawns...Plan: They can only move one square in the relative forward direction (ie 0, 45, 135)
			//				unless they are on the row of 2 or 7 in which case they can move only forward 
			//				two spots, in any other case, only one square in the before mentioned directions
			
			if(bWhitePawns)
			{
				//Doing for white
				if(fDotty > 0)
				{
					if( ((fDotty) >= (cos(DEG2RAD(45.0f)))-EPSILON) && ((fDotty) <= (cos(DEG2RAD(45.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
					{ 
						return 1;
					}
					else if( ((fDotty) >= (cos(DEG2RAD(135.0f)))-EPSILON) && ((fDotty) <= (cos(DEG2RAD(135.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
					{ 
						return 1;
					}
					else
					{
						//Potentially invalid move
						#if (BUILD_TYPE == DEBUG_MODE)
							CLog::Get()->WriteError("Pawn_Movement_Attack: Invalid movement occurred --xPiecePos: %d yPiecePos %d  xPos: %d yPos %d", xPiecePos, yPiecePos, xPos, yPos);
						#endif

						return 0;
					}
				}
			}
			else
			{
				//Doing for black
				if(fDotty < 0)
				{
					if( ((abs(fDotty)) >= (cos(DEG2RAD(45.0f)))-EPSILON) && ((abs(fDotty)) <= (cos(DEG2RAD(45.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
					{ 
						return 1;
					}
					else if( ((abs(fDotty)) >= (cos(DEG2RAD(135.0f)))-EPSILON) && ((abs(fDotty)) <= (cos(DEG2RAD(135.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
					{ 
						return 1;
					}
					else
					{
						//Potentially invalid move
						#if (BUILD_TYPE == DEBUG_MODE)
							CLog::Get()->WriteError("Pawn_Movement_Attack: Invalid movement occurred --xPiecePos: %d yPiecePos %d  xPos: %d yPos %d", xPiecePos, yPiecePos, xPos, yPos);
						#endif

						return 0;
					}
				}
			}



			
				/*
				if(bWhitePawns)
				{
					if( ((fDotty) >= (cos(DEG2RAD(45.0f)))-EPSILON) && ((fDotty) <= (cos(DEG2RAD(45.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
					{ //I think we have a valid move so far....
						if(fLengthTemp < 2)
							return 1;
					}
					else if( ((fDotty) >= (cos(DEG2RAD(135.0f)))-EPSILON) && ((fDotty) <= (cos(DEG2RAD(135.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
					{ //I think we have a valid move so far....
						if(fLengthTemp < 2)
							return 1;
					}
					else
					{
						//Potentially invalid move
						#if (BUILD_TYPE == DEBUG_MODE)
							CLog::Get()->WriteError("Pawn_Movement_Attack: Invalid movement occurred --xPiecePos: %d yPiecePos %d  xPos: %d yPos %d", xPiecePos, yPiecePos, xPos, yPos);
						#endif

						return 0;
					}
				}
				else
				{
					if( ((fDotty) >= (cos(DEG2RAD(225.0f)))-EPSILON) && ((fDotty) <= (cos(DEG2RAD(225.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
					{ //I think we have a valid move so far....
 						return 1;
					}
					else if( ((fDotty) >= (cos(DEG2RAD(315.0f)))-EPSILON) && ((fDotty) <= (cos(DEG2RAD(315.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
					{ //I think we have a valid move so far....
						return 1;
					}
					else
					{
						//Potentially invalid move
						#if (BUILD_TYPE == DEBUG_MODE)
							CLog::Get()->WriteError("Pawn_Movement_Attack: Invalid movement occurred --xPiecePos: %d yPiecePos %d  xPos: %d yPos %d", xPiecePos, yPiecePos, xPos, yPos);
						#endif

						return 0;
					}
				}

				*/


		//	}

		//	return 0;
			return 0;
		};



		UINT Movement(UINT xPos, UINT yPos)
		{
			cVector vNewPos(xPos, yPos, 0);
			cVector vCurPos(xPiecePos, yPiecePos, 0);

			cVector vDelta = vNewPos.Subtract(vCurPos);
			float fLengthTemp = vDelta.Length();
		
			if(fLengthTemp <= 2)
				goto Valid_Length;
			else
			{
				#if (BUILD_TYPE == DEBUG_MODE)
					CLog::Get()->WriteError("Pawn_Movement: Knight invalid move", fLengthTemp);
				#endif

				return 0;
			}

		Valid_Length:

			//Normalize stuff
			vDelta.Normalize();

			//FIXME For team FIX ME!
			float fTemp = 0;
			if(bWhitePawns)
				fTemp = 1;
			else
				fTemp = -1;

			cVector vCompare(0, 1, 0);
			vCompare.Normalize();

			//Dot them and look for proper angle
			float fDotty = vCompare.Dot(vDelta);

			//Pawns...Plan: They can only move one square in the relative forward direction (ie 0, 45, 135)
			//				unless they are on the row of 2 or 7 in which case they can move only forward 
			//				two spots, in any other case, only one square in the before mentioned directions
			if(bWhitePawns)
			{
				//Doing for white
				if(fDotty > 0)
				{
					if( (abs(fDotty) >= abs(cos(DEG2RAD(45.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(45.0f)))+EPSILON) && (fLengthTemp < 2)) //FIXME: Add epsilon floating point error correction
					{ //I think we have a valid move so far....
						if(fLengthTemp < 2)
							return 1;
					}
					else if( (fLengthTemp == 2) && (yPiecePos == 7 || yPiecePos == 2) && (abs(fDotty) == 1))
						return 1;
					else if((fLengthTemp == 1))
						return 1;
					else
					{

						//Potentially invalid move
						#if (BUILD_TYPE == DEBUG_MODE)
							CLog::Get()->WriteError("Pawn: Invalid movement occurred --xPiecePos: %d yPiecePos %d  xPos: %d yPos %d", xPiecePos, yPiecePos, xPos, yPos);
						#endif
					
						return 0;

					}
				}
			}
			else
			{
				if(fDotty < 0)
				{
					if( (abs(fDotty) >= abs(cos(DEG2RAD(45.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(45.0f)))+EPSILON) && (fLengthTemp < 2)) //FIXME: Add epsilon floating point error correction
					{ //I think we have a valid move so far....
						if(fLengthTemp < 2)
							return 1;
					}
					else if( (fLengthTemp == 2) && (yPiecePos == 7 || yPiecePos == 2) && (abs(fDotty) == 1))
						return 1;
					else if((fLengthTemp == 1))
						return 1;
					else
					{

						//Potentially invalid move
						#if (BUILD_TYPE == DEBUG_MODE)
							CLog::Get()->WriteError("Pawn: Invalid movement occurred --xPiecePos: %d yPiecePos %d  xPos: %d yPos %d", xPiecePos, yPiecePos, xPos, yPos);
						#endif

						return 0;

					}
				}
			}
				

			return 0;

		};

		UINT Action()
		{

			return 1;
		};

		UINT Special()
		{
			if((yPiecePos == 1) || (yPiecePos == 8))
			{
				bReincarnate = true;

				//TODO: Prompt for user input of new piece
				CLog::Get()->WriteEx("Special: Pawn movement on yPos 1 or 8");

			}

			return 1;

		};

		//For Movement
		static cBitboard *White_Pawn_BitBoards;
		static cBitboard *Black_Pawn_BitBoards;

		//for Attack
		static cBitboard *White_Pawn_Attack_BitBoards;
		static cBitboard *Black_Pawn_Attack_BitBoards;

		static bool bWhite_BitBoard_Built;
		static bool bBlack_BitBoard_Built;
		bool bWhitePawns;

	private:


};

cBitboard *cPawn::White_Pawn_BitBoards = NULL;
cBitboard *cPawn::Black_Pawn_BitBoards = NULL;
bool cPawn::bWhite_BitBoard_Built = false;
bool cPawn::bBlack_BitBoard_Built = false;

cBitboard *cPawn::White_Pawn_Attack_BitBoards = NULL;
cBitboard *cPawn::Black_Pawn_Attack_BitBoards = NULL;



#endif