#ifndef _PIECEVALUES_
#define _PIECEVALUES_

#include "Main.h"

//enum PIECE_TYPE {ROOK = 0, KNIGHT, BISHOP, QUEEN, KING, PAWN, EMPTY, UNKNOWN};

/* one pawn is equal to 100 points, and then a knight or bishop is worth around 300 points, a rook 500 and a queen 900. */


#define GENERIC_ROOK_VALUE 500
#define GENERIC_KNIGHT_VALUE 300
#define GENERIC_BISHOP_VALUE 300

#define GENERIC_QUEEN_VALUE 900
#define GENERIC_KING_VALUE 5000 //Perhaps edit me?

#define GENERIC_PAWN_VALUE 100

#define GENERIC_EMPTY_VALUE 0
#define GENERIC_EMPTY_UNKNOWN -1




#endif