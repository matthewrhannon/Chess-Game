#include "Pieces.h"

//Count for both colors
int cPiece::Pawn_Piece_Count = 16;
int cPiece::Bishop_Piece_Count = 4;
int cPiece::Rook_Piece_Count = 4;
int cPiece::Knight_Piece_Count = 4;
int cPiece::King_Piece_Count = 2;
int cPiece::Queen_Piece_Count = 2;