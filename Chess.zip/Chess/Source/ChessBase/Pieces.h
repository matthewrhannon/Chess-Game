//Piece 7/20/11 

#ifndef _PIECE_
#define _PIECE_

#include "Main.h"
#include "Board.h"
#include "ChessBlocks.h"
#include "PiecceValues.h"

class cPawn;
class cKnight;
class cBishop;

class cPiece
{
	public:
		cPiece()
		{
			Type = UNKNOWN;
			bAlive = false;
			strcpy(Title, "Unknown Piece");

			bReincarnate = false;
			bKing = false;

			xPiecePos = yPiecePos = 0;
			PieceIdentifier = -1;
			PieceValue = 0;
		};

		cPiece(PIECE_TYPE _Type, char *_Title)
		{
			Type = _Type;
			strcpy(Title, _Title);

			bAlive = false;
			bReincarnate = false;
			bKing = false;
			xPiecePos = yPiecePos = 0;
			PieceIdentifier = -1;
			bTeamColor = true;
			PieceValue = 0;
		};


		cPiece(const cPiece& Piece)
		{
			Type = Piece.Type;
			strcpy(Title, Piece.Title);

			bAlive = Piece.bAlive;
			bReincarnate = Piece.bReincarnate;
			bKing = Piece.bKing;
			xPiecePos = Piece.xPiecePos;
			yPiecePos = Piece.yPiecePos;

			PieceIdentifier = Piece.PieceIdentifier;
			bTeamColor = Piece.bTeamColor;
			PieceValue = Piece.PieceValue;
		};


		~cPiece() 
		{

		};

		//friend class cChessBlock;

		virtual bool Initalize()
		{

			return false;
		};

		virtual bool Deinitalize()
		{

			return false;
		};
			
		virtual UINT Movement(UINT xPos, UINT yPos)
		{
		
			return 0;
		};

		virtual UINT Action()
		{

			return 0;
		};

		virtual UINT Special()
		{

			return 0;
		};
		
		PIECE_TYPE Type;
		bool bAlive;

		UINT xPiecePos, yPiecePos;
		bool bReincarnate;
		bool bKing;
		char Title[16];

		bool bTeamColor; //false = black; white = true
		bool bPieceColor; //false = black; white = true Note: Only for specifc color of the team
		int PieceIdentifier;

		//AI Stuff
		int PieceValue;

		//Individual piece counters
		static int Pawn_Piece_Count;
		static int Bishop_Piece_Count;
		static int Rook_Piece_Count;
		static int Knight_Piece_Count;
		
		static int King_Piece_Count;
		static int Queen_Piece_Count;



	protected:

	private:
		


};

#endif
