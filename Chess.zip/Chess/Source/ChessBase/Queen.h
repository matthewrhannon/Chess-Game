//Queen 7/24/11 

#ifndef _QUEEN_
#define _QUEEN_

#include "Main.h"

#include "Log.h"
#include "Vector.h"

#include "Board.h"
#include "ChessBlocks.h"
#include "Pieces.h"

class cPiece;

class cQueen : public cPiece
{

public:
	cQueen() : cPiece(QUEEN, "Queen")
	{
		PieceIdentifier = (int)Queen_Piece_Count--;
		PieceValue = GENERIC_QUEEN_VALUE;

		if(!bBitBoard_Built)
		{
			Initalize();	
			bBitBoard_Built = true;
		}

	};

	~cQueen() 
	{
		Deinitalize();
	};

	bool Initalize()
	{
		//////////////////////////////////////////////////////////////
		//Bitboard stuff
		//////////////////////////////////////////////////////////////

		//Initalize 64 bitboards for the rook (?is this even a efficient way to do this?)
		Queen_BitBoards = new cBitboard[64];

		cBitboard tempBitBoard;

		UINT uTempPos = 0;

		xPiecePos = yPiecePos = 1;

		//Loop through each of the 64 bitboards for the rook potential locations
		for(yPiecePos = 1; yPiecePos <= 8; yPiecePos++)
		{
			for(xPiecePos = 1; xPiecePos <= 8; xPiecePos++)
			{
				//Update piece to next location
				uTempPos = (((yPiecePos-1)*8)+(xPiecePos-1));

				//Loop through each square, and generate bitboards that represent potentially valid moves
				for(UINT cur_Y = 1; cur_Y <= 8; cur_Y++)
				{
					for(UINT cur_X = 1; cur_X <= 8; cur_X++)
					{
						//Lets start by running through one rook pattern, say x = y = 1 Position placement of rook, and find potential movements
						if( Movement(cur_X, cur_Y) == 1 )
						{	//Success move
							Queen_BitBoards[uTempPos].SetBit(cur_X, cur_Y);
						}
					}
				}

				//Test if same square as position being tested
				//if( (xPiecePos != cur_X) && (yPiecePos != cur_Y) )
				Queen_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos);
			}
		}

		//REMEMBERME: Remember to reset x/y position values after all this!
		xPiecePos = yPiecePos = 1;

		return true;
	};

	bool Deinitalize()
	{
		Type = UNKNOWN;

		bBitBoard_Built = false;
		SafeDelete(Queen_BitBoards);

		return true;
	};

	UINT Movement(UINT xPos, UINT yPos)
	{
		//Queen - Its moves encompass the kings, the bishops, and the rook. So lets combine them!

		bool bValidMove = false;
		//First test if move is in boundaries
		if(cChessBoard::BoundsChecker(xPos, yPos))
		{ 
			//Test king movement because the queen is similar
			{
				//Now check if length is proper for movement
				if( ((abs(int(xPos) - int(xPiecePos)) == 1) && (abs(int(yPos) - int(yPiecePos)) == 0)) )
				{
					bValidMove = true;
					return bValidMove;
				}
				else if( ((abs(int(xPos) - int(xPiecePos) == 0) && (abs(int(yPos) - int(yPiecePos)) == 1))) )
				{
					bValidMove = true;
					return bValidMove;
				}
				else if( ((abs(int(xPos) - int(xPiecePos)) == 1) && (abs(int(yPos) - int(yPiecePos)) == 1)) )
				{
					bValidMove = true;
					return bValidMove;
				}				
			}
			
			//If here, not moving like king, so lets check bishop and rook movements now
			{
				//Now test if it is on a proper line of direction for rook
				cVector vNewPos(xPos, yPos, 0);
				cVector vCurPos(xPiecePos, yPiecePos, 0);

				cVector vDelta = vNewPos.Subtract(vCurPos);

				//Normalize stuff
				vDelta.Normalize();

				cVector vCompare(0, 1, 0);
				vCompare.Normalize();

				//Dot them and look for proper angle
				float fDotty = vCompare.Dot(vDelta);

				//cos (theta) needs to be +1,-1,+0,-0
				if( (abs(fDotty) >= 1-EPSILON) && (abs(fDotty) <= 1+EPSILON) ) 
				{
					bValidMove = true;
					return bValidMove;
				}
				else if( (abs(fDotty) >= 0-EPSILON) && (abs(fDotty) <= 0+EPSILON) ) 
				{ 
					bValidMove = true;
					return bValidMove;
				}
			}

			//If code reaches here, move isn't like king or rook, so test bishop type of move
			{
				//Now test if it is on a proper line of direction
				cVector vNewPos(xPos, yPos, 0);
				cVector vCurPos(xPiecePos, yPiecePos, 0);

				cVector vDelta = vNewPos.Subtract(vCurPos);

				//Normalize stuff
				vDelta.Normalize();

				//FIXME For team FIX ME!
				float fTemp = 1; //Shouldn't matter with queen?
	
				cVector vCompare(0, fTemp, 0);
				vCompare.Normalize();

				//Dot them and look for proper angle
				float fDotty = vCompare.Dot(vDelta);

				if( (abs(fDotty) >= abs(cos(DEG2RAD(45.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(45.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
				{ //I think we have a valid move so far....
					bValidMove = true;
					return bValidMove;
				}
				else if( (abs(fDotty) >= abs(cos(DEG2RAD(135.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(135.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
				{ //I think we have a valid move so far....
					bValidMove = true;
					return bValidMove;
				}
				else if( (abs(fDotty) >= abs(cos(DEG2RAD(225.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(225.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
				{ //I think we have a valid move so far....
					bValidMove = true;
					return bValidMove;
				}
				else if( (abs(fDotty) >= abs(cos(DEG2RAD(315.0f)))-EPSILON) && (abs(fDotty) <= abs(cos(DEG2RAD(315.0f)))+EPSILON) ) //FIXME: Add epsilon floating point error correction
				{ //I think we have a valid move so far....
					bValidMove = true;
					return bValidMove;
				}
				else
				{
					//If reaches here, the king/rook/bishop movements are not valid, therefore may not be a valid move?
					#if (BUILD_TYPE == DEBUG_MODE)
						CLog::Get()->WriteError("Queen_Movement: Tested King/Rook/Bishop movements yet invalid move");
					#endif

					bValidMove = false;
					return bValidMove;
				}
			}
		}
		else
		{
			CLog::Get()->WriteError("Queen_Movement: Outside boundaries");
			bValidMove = false;
			return bValidMove;
		}


		return false;
	};

	UINT Action()
	{

		return 1;
	};

	UINT Special()
	{

		return 1;
	};

	static cBitboard *Queen_BitBoards;
	static bool bBitBoard_Built;


private:

};

cBitboard *cQueen::Queen_BitBoards = NULL;
bool cQueen::bBitBoard_Built = false;



#endif