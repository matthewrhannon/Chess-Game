//Rook 7/24/11 

#ifndef _ROOK_
#define _ROOK_

#include "Main.h"

#include "Log.h"
#include "Vector.h"

#include "Board.h"
#include "ChessBlocks.h"
#include "Pieces.h"
#include "Bitboard.h"

class cPiece;
class cBitboard;

class cRook : public cPiece
{
public:
	cRook() : cPiece(ROOK, "Rook")
	{
		//Rook_BitBoards = NULL;
		PieceIdentifier = (int)Rook_Piece_Count--;
		PieceValue = GENERIC_ROOK_VALUE;

		if(!bBitBoard_Built)
		{
			Initalize();	
			bBitBoard_Built = true;
		}
	};

	~cRook() 
	{
		Deinitalize();
	};

	bool Initalize()
	{
		//Initalize 64 bitboards for the rook (?is this even a efficient way to do this?)
		Rook_BitBoards = new cBitboard[64];

		cBitboard tempBitBoard;

		UINT uTempPos = 0;

		xPiecePos = yPiecePos = 1;

		//Loop through each of the 64 bitboards for the rook potential locations
		for(yPiecePos = 1; yPiecePos <= 8; yPiecePos++)
		{
			for(xPiecePos = 1; xPiecePos <= 8; xPiecePos++)
			{
				//Update piece to next location
				uTempPos = (((yPiecePos-1)*8)+(xPiecePos-1));

				//Loop through each square, and generate bitboards that represent potentially valid moves
				for(UINT cur_Y = 1; cur_Y <= 8; cur_Y++)
				{
					for(UINT cur_X = 1; cur_X <= 8; cur_X++)
					{
						//Lets start by running through one rook pattern, say x = y = 1 Position placement of rook, and find potential movements
						if( Movement(cur_X, cur_Y) == 1 )
						{	//Success move
								Rook_BitBoards[uTempPos].SetBit(cur_X, cur_Y);
						}
					}
				}

				//Test if same square as position being tested
				//if( (xPiecePos != cur_X) && (yPiecePos != cur_Y) )
				Rook_BitBoards[uTempPos].ResetBit(xPiecePos, yPiecePos);
			}
		}

		//REMEMBERME: Remember to reset x/y position values after all this!
		xPiecePos = yPiecePos = 1;

		return true;
	};

	bool Deinitalize()
	{
		Type = UNKNOWN;
		bBitBoard_Built = false;

		SafeDelete(Rook_BitBoards);

		return true;
	};

	UINT Movement(UINT xPos, UINT yPos)
	{
		//Rook -- Well they travel in straight lines front/back and lside/rside
		//Make sure you check bounds! Test by angle of 0,90,180,270
		
		//First test if move is in boundaries
		if(cChessBoard::BoundsChecker(xPos, yPos))
		{ 
			//Now test if it is on a proper line of direction
			cVector vNewPos(xPos, yPos, 0);
			cVector vCurPos(xPiecePos, yPiecePos, 0);

			cVector vDelta = vNewPos.Subtract(vCurPos);

			//Normalize stuff
			vDelta.Normalize();

			cVector vCompare(0, 1, 0);
			vCompare.Normalize();

			//Dot them and look for proper angle
			float fDotty = vCompare.Dot(vDelta);

			//cos (theta) needs to be +1,-1,+0,-0
			if( !((abs(fDotty) == 1) || (abs(fDotty) == 0)) )
			{ 
				#if (BUILD_TYPE == DEBUG_MODE)
					CLog::Get()->WriteError("Rook_Movement: Dot product doesn't match - fDotty: %f", fDotty);
				#endif

				return 0;
			}

			//I think we have a valid move so far.....
			//ADDME: Is something potentially in the way? !!!

			return 1;


		}
		else
		{
			CLog::Get()->WriteError("Rook_Movement: Outside boundaries");
			return 0;
		}
	

		return 0;
	};

	UINT Action()
	{

		return 1;
	};

	UINT Special()
	{

		return 1;
	};


	static cBitboard *Rook_BitBoards;
	static bool bBitBoard_Built;

private:

};

cBitboard *cRook::Rook_BitBoards = NULL;
bool cRook::bBitBoard_Built = false;


#endif