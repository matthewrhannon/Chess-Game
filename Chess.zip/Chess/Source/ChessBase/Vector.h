//July 22 '11 Matt H

#ifndef _MY_VECTOR_
#define _MY_VECTOR_

#include "Main.h"

//Keep it simple stupid!

class cVector
{
	public:
		cVector()
		{
			bNormalized = false;
			fx = fy = fz = 0;
		};

		cVector(float x, float y, float z)
		{
			fx = x;
			fy = y;
			fz = z;
		};

		~cVector()
		{

		};

		bool IsEqual(cVector &EqualVec)
		{
			if( (fx >= EqualVec.fx-EPSILON) && (fx <= EqualVec.fx+EPSILON) ) 
				if( (fy >= EqualVec.fy-EPSILON) && (fy <= EqualVec.fy+EPSILON) ) 
					if( (fz >= EqualVec.fz-EPSILON) && (fz <= EqualVec.fz+EPSILON) ) 
							return true;

			/*
			if( (fx == EqualVec.fx) && (fy == EqualVec.fy) && (fz == EqualVec.fz) )
				return true;
			else
				return false;
			*/

			return false;
		};

		void Reset(float x, float y, float z)
		{
			fx = x;
			fy = y;
			fz = z;
		};

		cVector Add(cVector &AddMe)
		{
			fx += AddMe.fx;
			fy += AddMe.fy;
			fz += AddMe.fz;

			return *this;
		};

		cVector Subtract(cVector &SubMe)
		{
			fx -= SubMe.fx;
			fy -= SubMe.fy;
			fz -= SubMe.fz;

			return *this;
		};

		cVector Multiply(cVector &MulMe)
		{
			fx *= MulMe.fx;
			fy *= MulMe.fy;
			fz *= MulMe.fz;

			return *this;
		};
		
		cVector Divide(cVector &DivMe)
		{
			fx /= DivMe.fx;
			fy /= DivMe.fy;
			fz /= DivMe.fz;

			return *this;
		};


		bool Normalize()
		{
			float fTemp = Length();

			if(fTemp == 0)
				return false;

			fx /= fTemp;
			fy /= fTemp;
			fz /= fTemp;

			bNormalized = true;

			return true;
		}

		float Length()
		{	
			return sqrt(abs(fx*fx + fy*fy + fz*fz));
		};

		float Dot(cVector &DotMe)
		{
			return fx*DotMe.fx + fy*DotMe.fy + fz*DotMe.fz;
		}

		float fx, fy, fz;
	private:
		bool bNormalized;

};





#endif
