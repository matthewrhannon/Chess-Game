// Controller.c++: a basic Controller (in Model-View-Controller sense)

/* Matthew Hannon 2217853 skinnym2@ku.edu */
#include "Controller.h"
#include "ModelView.h"

Controller* Controller::curController = NULL;
float Controller::VP_AspectRatio = 1;

Controller::Controller(const std::string& name) : overallWCBoundingBoxInitialized(false)
{
	curController = this;
	TestMouse = false;
	bMakingMove = false;
	// First create the window and its Rendering Context (RC)
	int windowID = createWindow(name);

	// Then initialize the newly created OpenGL RC
	establishInitialCallbacksForRC(); // the callbacks for this RC
	initializeOpenGLRC(); // other general OpenGL initialization for the RC
	
	// generic default
	overallWCBoundingBox[0] = overallWCBoundingBox[2] = overallWCBoundingBox[4] = -1.0;
	overallWCBoundingBox[1] = overallWCBoundingBox[3] = overallWCBoundingBox[5] =  1.0;

	//Set to not translating first
	mouseMotionIsTranslate = false;

	#if ( defined(_WIN32) || defined(__WIN32__) || defined(__WINDOWS__) )
		glewExperimental = GL_TRUE;
		GLenum err = glewInit();
		if (GLEW_OK != err)
		{ 
			fprintf(stderr, "Error: %s\n", glewGetErrorString(err));  
		};
	#endif
}

Controller::~Controller()
{
	if (this == curController)
		curController = NULL;
}

void Controller::addModel(ModelView* m)
{
	models.push_back(m);
	updateWCBoundingBox(m);
}

bool Controller::checkForErrors(std::ostream& os, const std::string& context)
	// CLASS METHOD
{
	bool hadError = false;
	GLenum e = glGetError();
	while (e != GL_NO_ERROR)
	{
		os << "CheckForErrors (context: " <<  context
		   << "): " << (char*)gluErrorString(e) << std::endl;

		e = glGetError();
		hadError = true;
	}
	return hadError;
}

int Controller::createWindow(const std::string& windowTitle) // CLASS METHOD
{
	// The following "glutInitContext*" calls guarantee that we use only
	// modern OpenGL functionality.
	glutInitContextVersion(3,3);
	glutInitContextFlags(GLUT_FORWARD_COMPATIBLE);
	glutInitContextProfile(GLUT_CORE_PROFILE);

	// Now create the window and its Rendering Context.
	glutInitDisplayMode(GLUT_DEPTH | GLUT_RGBA | GLUT_DOUBLE);
	glutInitWindowSize(1400, 1400);
	
	int windowID = glutCreateWindow("672_Project 3 - Chess3D");
	return windowID;
}

void Controller::displayCB() // CLASS METHOD
{
	if (curController != NULL)
		curController->doDisplay();
}

void Controller::doDisplay()
{
	// clear the frame buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   // cCamera::Get()->addToGlobalPan(1, 5, 1);

	//cCamera::Get()->addToGlobalRotateDegrees(0, 90, 0);

	
	vec3 temp, temp1;
		//cCamera::Get()->defineMatrices(cCamera::Get()->projection_type);
	for (std::vector<ModelView*>::iterator it=models.begin() ; it<models.end() ; it++)
	{
	
		/*	if(strcmp((*it)->strPieceName, "King") == 0)
		{
		 cCamera::Get()->setToGlobalPan(temp, 0.1, 0.0, 0.5);
			cCamera::Get()->addToGlobalPan(0.1, 0.0, 0.5);
		}*/

		(*it)->UpdateLocalMatrices();
		
		cCamera::Get()->defineMatrices(cCamera::Get()->projection_type);
	
		(*it)->render();
			
		/*if(strcmp((*it)->strPieceName, "King") == 0)
		{
			cCamera::Get()->addToGlobalPan(-0.1, 0.0, -0.5);
			cCamera::Get()->setToGlobalPan(temp1, temp[0], temp[1], temp[2]);
		}*/

		(*it)->UpdateLocalMatrices();
		cCamera::Get()->defineMatrices(cCamera::Get()->projection_type);
		//cCamera::Get()->addToGlobalPan(-(*it)->PieceOrigin[0], -(*it)->PieceOrigin[1], -(*it)->PieceOrigin[2]);

	}
	//cCamera::Get()->addToGlobalRotateDegrees(0, -90, 0);
	//cCamera::Get()->addToGlobalPan(-1, -5, -1);
	glutSwapBuffers();
}

void Controller::doReshape()
{
	VP_AspectRatio = float(vpHeight)/float(vpWidth);

	//Fix window aspect ratio based on changes on window changing size
	cCamera::Get()->AdjustAspectRatio(VP_AspectRatio, 0, vpWidth, 0, vpHeight);
	glViewport(0, 0, vpWidth, vpHeight);
}

void Controller::establishInitialCallbacksForRC()
{
	glutDisplayFunc(displayCB); 
	glutReshapeFunc(reshapeCB);
	glutKeyboardFunc(keyboardCB);

	glutMouseFunc(doMouseFunc);
	glutMotionFunc(doMouseMotion);
}

void Controller::getOverallWCBoundingBox(float* xyzLimits)
{
	for (int i=0 ; i<6 ; i++)
		xyzLimits[i] = curController->overallWCBoundingBox[i];
}

void Controller::initializeOpenGLRC() 
{
	glClearColor(0.0, 0.0, 0.0, 1.0);
	
	glEnable(GL_DEPTH_TEST);
}

void Controller::keyboardCB(unsigned char key, int x, int y)
{
	static const unsigned char ESC = 27; // ASCII code for the ESC key
	if (key == ESC)
		exit(0);

	//For reset
	if(key == 'r')
	{
		cCamera::Get()->ResetCamera();
		glutPostRedisplay();
	}

	//Change perspective mode
	if(key == 'p')
	{
		cout << "Changing perspective type!\n";
		//cCamera::Get()->_eye_point. += 0.1;
		cCamera::Get()->defineMatrices(!cCamera::Get()->projection_type);
		//cCamera::Get()->addTosGlobalScale(-1);
		glutPostRedisplay();
	}

	if(key == 'm') //Movement begin
	{
		cout << "Specify first move coordinate with right mouse click: ";

		Controller::curController->bFirstMouseClick = true;
		//Initalize move coordinates
		Controller::curController->MoveXold = -1;
		Controller::curController->MoveYold = -1;
		Controller::curController->MoveXnew = -1;
		Controller::curController->MoveYnew = -1;

		Controller::curController->bMakingMove = true;
	}

}


bool Controller::ConvertWCtoGrid(float _offsetX, float _offsetY, vec3 &retOrigin)
{
	retOrigin[0] = (0.25f*_offsetY)/20.97f;
	retOrigin[1] = (0.25f*_offsetX)/-2.61f;
	retOrigin[2] = 0.0f;

	cout << "ConvertWCtoGrid: retOrigin[] = " << retOrigin[0] << ":" << retOrigin[1] << ":" << retOrigin[2] << endl;
	return true;
}


bool Controller::MoveChessPiece()
{
	//Fisrt convert the new grid position to world coordinates
	float tempWCxold = 10.46 - ((Controller::curController->MoveXold*2.61) - 1.3 -1.3);
	float tempWCyold = -84.69 + ((Controller::curController->MoveYold*20.97) - 11.6816 - 9);
	
	float tempWCxnew = 10.46 - ((Controller::curController->MoveXnew*2.61) - 1.3 -1.3);
	float tempWCynew = -84.69 + ((Controller::curController->MoveYnew*20.97) - 11.6816 - 9);

	//Calculate offsets
	float offsetX = tempWCxnew - tempWCxold;
	float offsetY = tempWCynew - tempWCyold;
	vec3 ret, ret1;
	for (std::vector<ModelView*>::iterator it=models.begin(); it<models.end(); it++)
	{
		if( ((*it)->GridX == Controller::curController->MoveXold) && ((*it)->GridY == Controller::curController->MoveYold) )
		{ 
			//Just found what piece we are moving, so lets move it...
			//ConvertWCtoGrid(Controller::curController->MoveXold, Controller::curController->MoveYold, ret);
			//ConvertWCtoGrid(Controller::curController->MoveXnew, Controller::curController->MoveYnew, ret1);
			ConvertWCtoGrid(offsetX, offsetY, ret);
			
			//(*it)->PieceOffset[0] = offsetX;
		//	(*it)->PieceOffset[1] = offsetY;
			cout <<  "\nMoving Piece offsetX/Y: " << offsetX << "/" << offsetY << endl;
			(*it)->PieceOffset[0] += ret[1];
			(*it)->PieceOffset[1] += ret[0];
			(*it)->PieceOffset[2] += ret[2];
			(*it)->PieceOffset[3] = 0;

			//(*it)->PieceOffset[0] = ret1[0] - ret[0];
			//(*it)->PieceOffset[1] = ret1[1] - ret[1];
			//(*it)->PieceOffset[2] = ret1[2] - ret[2];
			//(*it)->PieceOffset[3] = 0;


			(*it)->GridX = Controller::curController->MoveXnew;
			(*it)->GridY = Controller::curController->MoveYnew;
			
			(*it)->iColor = 0;
			Controller::curController->bMakingMove = false;
			//Exit look
			return true;
		}
	}

	return false;
}

bool Controller::TestMove()
{
	//FIXME: Assuming MoveXYold, MoveXYnew are valid
	bool btempValid = false;

	if(Controller::curController->bMakingMove)
	{
		//Now call into ChessBase
		
		if(cChessGame::Get()->ChessBoard->MovePiece(Controller::curController->MoveXold, Controller::curController->MoveYold, Controller::curController->MoveXnew, Controller::curController->MoveYnew))
		{
			cout << "SUCCESS - Valid Move - xPosOld: " << Controller::curController->MoveXold << " yPosOld: " << Controller::curController->MoveYold << " xPosNew: " << Controller::curController->MoveXnew << " yPosNew: " << Controller::curController->MoveYnew << "\n";
			btempValid = true;
			//We need to actually move the piece now to that the new square cause the move is valid
			if(!MoveChessPiece())
				cout << "ERROR while moving chess piece!\n";
		}
		else
		{
			cout << "ERROR  - Valid Move - xPosOld: " << Controller::curController->MoveXold << " yPosOld: " << Controller::curController->MoveYold << " xPosNew: " << Controller::curController->MoveXnew << " yPosNew: " << Controller::curController->MoveYnew << "\n";
		}

		//Test for checkmate scenario
		//Check for white king checkmate
		if(cChessGame::Get()->ChessBoard->VaildateCheckmate(true))
		{
			cout << "\nWHITE KING IS IN CHECKMATE\n";
			cChessGame::Get()->UninitalizeGame();

			btempValid = false;
		}
		
		if(cChessGame::Get()->ChessBoard->VaildateCheckmate(false))
		{
			cout << "\nBLACK KING IS IN CHECKMATE\n";
			cChessGame::Get()->UninitalizeGame();

			btempValid = false;
		}

		//Perhaps here call into chessAI? because a move just occured (FIXME: Make sure it was a valid move!!!)
		if(btempValid)
		{
			cout << "\nCalling into chess AI for an attempt at a move!\n";



		}
	}


	return true;
}


bool Controller::FindPiecefromCursor(float wx, float wy, float wz, int &MovePosX, int &MovePosY)
{		
	//Convert wx, wy, wz to xpos and ypos on grid
	int tempX = int(((-1*wx)+10.46+1.3+1.3)/2.61);
	int tempY = int((wy + 84.69 + 11.6816+9)/20.97);

	cout << "tempX : " << tempX << " tempY: " << tempY << endl;

	for (std::vector<ModelView*>::iterator it=models.begin(); it<models.end(); it++)
	{
		if( ((*it)->GridX == tempX) && ((*it)->GridY == tempY) )
		{ //Found a match
			if(Controller::curController->bMakingMove  )
			{
				//Make first move piece selection
				//Controller::curController->MoveXold = tempX;
				//Controller::curController->MoveYold = tempY;
				MovePosX = tempX;
				MovePosY = tempY;
			}
			(*it)->iColor = 2; //Set selected

			return true;
		}
	}

	/*
	if(Controller::curController->bMakingMove && (Controller::curController->MoveXnew == -1) && (Controller::curController->MoveXold != -1) )
	{
		//Make second move piece selection
		Controller::curController->MoveXnew = tempX;
		Controller::curController->MoveYnew = tempY;

		//Now call into ChessBase
		
		if(cChessGame::Get()->ChessBoard->MovePiece(Controller::curController->MoveXold, Controller::curController->MoveYold, Controller::curController->MoveXnew, Controller::curController->MoveYnew))
		{
			cout << "SUCCESS - Valid Move - xPosOld: " << Controller::curController->MoveXold << " yPosOld: " << Controller::curController->MoveYold << " xPosNew: " << Controller::curController->MoveXnew << " yPosNew: " << Controller::curController->MoveYnew << "\n";
			
			//We need to actually move the piece now to that the new square cause the move is valid
			if(!MoveChessPiece())
				cout << "ERROR while moving chess piece!\n";
		}
		else
		{
			cout << "ERROR  - Valid Move - xPosOld: " << Controller::curController->MoveXold << " yPosOld: " << Controller::curController->MoveYold << " xPosNew: " << Controller::curController->MoveXnew << " yPosNew: " << Controller::curController->MoveYnew << "\n";
		}

		//Test for checkmate scenario
		//Check for white king checkmate
		if(cChessGame::Get()->ChessBoard->VaildateCheckmate(true))
		{
			cout << "\nWHITE KING IS IN CHECKMATE\n";
			cChessGame::Get()->UninitalizeGame();
		}
		
		if(cChessGame::Get()->ChessBoard->VaildateCheckmate(false))
		{
			cout << "\nBLACK KING IS IN CHECKMATE\n";
			cChessGame::Get()->UninitalizeGame();
		}
	}
	*/
	return true;
}

void Controller::renderBitmapString(float x, float y, float z, void *font, char *string) 
{
  char *c;
  glRasterPos3f(x, y,z);
  for (c=string; *c != '\0'; c++) 
  {
    glutBitmapCharacter(font, *c);
  }
}


void Controller::doMouseFunc(int button, int state, int x, int y)
{
	static const int SCROLL_WHEEL_UP = 3;
	static const int SCROLL_WHEEL_DOWN = 4;

	if (button == SCROLL_WHEEL_UP)
	{
		// each wheel click generates a state==DOWN and state==UP event; use only one
		if (state == GLUT_DOWN)
		{
			cCamera::Get()->addTosGlobalScale(0.1);
			glutPostRedisplay();
		}
	}
	else if (button == SCROLL_WHEEL_DOWN)
	{
		// each wheel click generates a state==DOWN and state==UP event; use only one
		if (state == GLUT_DOWN)
		{
			cCamera::Get()->addTosGlobalScale(-0.1);
			//Controller::curController->renderBitmapString(0, 0, 0, GLUT_BITMAP_TIMES_ROMAN_24, "YOsdsadfasdfasdfsssdfa");
			glutPostRedisplay();
		}
	}
	else if(button == GLUT_RIGHT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			Controller::curController->TestMouse = true;
			float wx, wy, wz;
			//Convert mouse to world coordinate
			cCamera::Get()->gluUnProject(x, y, 0, &wx, &wy, &wz);

			cout << "X: " << x << " Y: " << y << " ----" << " wx: " << wx << " wy: " << wy << " wz: " << wz << endl;

			//Search for piece under cursor
			//if(!Controller::curController->FindPiecefromCursor(wx, wy, wz) && (Controller::curController->MoveXold == -1))
			//	cout << "Couldn't find the right piece from mouse!\n";
			//else if(!Controller::curController->TestMove(wx, wy, wz) && (Controller::curController->MoveYnew == -1))
			//	cout << "Couldn't find the right piece from mouse!\n";
			if(Controller::curController->bMakingMove)
			{
				if(Controller::curController->bFirstMouseClick)
				{
					int tempX, tempY;
					Controller::curController->FindPiecefromCursor(wx, wy, wz, tempX, tempY);
					Controller::curController->MoveXold = tempX;
					Controller::curController->MoveYold = tempY;

					Controller::curController->bFirstMouseClick = false;
				}
				else
				{
					int tempX = 0, tempY = 0;
					Controller::curController->FindPiecefromCursor(wx, wy, wz, tempX, tempY);

					if(tempX == 0 && tempY == 0)
					{
						//Convert wx, wy, wz to xpos and ypos on grid
						tempX = int(((-1*wx)+10.46+1.3+1.3)/2.61);
						tempY = int((wy + 84.69 + 11.6816+9)/20.97);
					}

					Controller::curController->MoveXnew = tempX;
					Controller::curController->MoveYnew = tempY;

					if(!Controller::curController->TestMove())
						cout << "Error testing move!\n";

					Controller::curController->bFirstMouseClick = true;

				}
			
			
			
			
			}

			Controller::curController->TestMouse = false;
		}
	}
	else
	{
		Controller::curController->mouseMotionIsTranslate = ((glutGetModifiers() & GLUT_ACTIVE_SHIFT) != 0);
		if (state == GLUT_DOWN && !Controller::curController->TestMouse)
		{
			Controller::curController->screenBaseX = x; Controller::curController->screenBaseY = y;
		}
	}
}

void Controller::doMouseMotion(int x, int y)
{
	//Dont update mouse during selection
	if(Controller::curController->TestMouse)
		return;

	float wcPerPixelX = (cCamera::Get()->xmax - cCamera::Get()->xmin) / Controller::curController->vpWidth;
	float wcPerPixelY = (cCamera::Get()->ymax - cCamera::Get()->ymin) / Controller::curController->vpHeight;

	int dx = (x - Controller::curController->screenBaseX), dy = (y - Controller::curController->screenBaseY);
	Controller::curController->screenBaseX = x; Controller::curController->screenBaseY = y;
	if (Controller::curController->mouseMotionIsTranslate)
		cCamera::Get()->addToGlobalPan(dx*wcPerPixelX, -dy*wcPerPixelY, 0.0);
	else
	{
		static const float pixelsToDegrees = 360.0 / 500.0;
		float screenRotY = pixelsToDegrees * dx;
		float screenRotX = pixelsToDegrees * dy;
		cCamera::Get()->addToGlobalRotateDegrees(screenRotX, screenRotY, 0.0);
	}

	glutPostRedisplay();
}


void Controller::reportVersions(std::ostream& os)
{
	const char* glVer = reinterpret_cast<const char*>(glGetString(GL_VERSION));
	const char* glslVer = reinterpret_cast<const char*>
			(glGetString(GL_SHADING_LANGUAGE_VERSION));
	// glGetString can return NULL if no rendering context has been created
	os << "GL version: ";
	if (glVer == NULL)
		os << "NULL (has RC been created?)";
	else
		os << glVer;
	os << "; GLSL version: ";
	if (glslVer == NULL)
		os << "NULL (has RC been created?)";
	else
		os << glslVer;
	os << '\n';
}

void Controller::reshapeCB(int width, int height)
{
	Controller::curController->vpWidth = width;
	Controller::curController->vpHeight = height;
	Controller::curController->doReshape();

	glutPostRedisplay();
}

void Controller::updateWCBoundingBox(ModelView* m)
{
	if (m == NULL)
		return;
	if (overallWCBoundingBoxInitialized)
	{
		float xyz[6];
		m->getWCBoundingBox(xyz);
		for (int i=0 ; i<5 ; i+=2)
		{
			if (xyz[i] < overallWCBoundingBox[i])
				overallWCBoundingBox[i] = xyz[i]+1;
			if (xyz[i+1] > overallWCBoundingBox[i+1])
				overallWCBoundingBox[i+1] = xyz[i+1]+1;
		}
	}
	else
	{
		m->getWCBoundingBox(overallWCBoundingBox);
		overallWCBoundingBoxInitialized = true;
	}
}
