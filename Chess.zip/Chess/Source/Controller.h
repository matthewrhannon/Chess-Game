// Controller.h - a basic Controller (in Model-View-Controller sense)
/* Matthew Hannon 2217853 skinnym2@ku.edu */

#ifndef CONTROLLER_H
#define CONTROLLER_H



#include "Externals.h"
#include "ModelView.h"
#include "Camera.h"
#include "ChessBase\Game.h"

class Controller
{
public:
	Controller(const std::string& name);
	virtual ~Controller();

	void addModel(ModelView* m);
	void renderBitmapString(float x, float y, float z, void *font, char *string);

	bool MoveChessPiece();
	static bool checkForErrors(std::ostream& os, const std::string& context);
	// following returns a bounding box that contains all models managed by this Controller
	static void getOverallWCBoundingBox(float* xyzLimits);
	static void reportVersions(std::ostream& os);

	
	static float VP_AspectRatio;
private:
	Controller(const Controller& c) {} // do not allow copies, including pass-by-value
	std::vector<ModelView*> models;

	int vpWidth, vpHeight;
	float overallWCBoundingBox[6];
	bool overallWCBoundingBoxInitialized;

	//Mouse variables
	bool mouseMotionIsTranslate;
	int screenBaseX, screenBaseY;

	void doDisplay();
	void doReshape();
	void establishInitialCallbacksForRC();
	void initializeOpenGLRC();
	void updateWCBoundingBox(ModelView* m);
	bool FindPiecefromCursor(float wx, float wy, float wz, int &MovePosX, int &MovePosY);
	bool TestMove();
	static Controller* curController;

	static int createWindow(const std::string& windowTitle);
	static void displayCB();
	static void keyboardCB(unsigned char key, int x, int y);
	static void reshapeCB(int width, int height);
	static void doMouseFunc(int button, int state, int x, int y);
	static void doMouseMotion(int x, int y);

	
	bool ConvertWCtoGrid(float _offsetX, float _offsetY, vec3 &retOrigin);


	bool TestMouse;
	int MoveXold, MoveYold, MoveXnew, MoveYnew;
	bool bMakingMove, bFirstMouseClick;
};

#endif