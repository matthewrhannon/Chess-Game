//Externals
/* Matthew Hannon 2217853 skinnym2@ku.edu */

#ifndef _EXTERNALS_
#define _EXTERNALS_

#if ( defined(_WIN32) || defined(__WIN32__) || defined(__WINDOWS__) )
	#define WINDOWS_ENV
	#define  GLEW_STATIC
	#include "glew.h"
	#include <gl/GL.h>
#else
	#include <GL/gl.h>
	#include <GL/glu.h>
#endif

#include <GL/freeglut.h>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>

#include <stdio.h>
#include <string.h>

using namespace std;

#if ( defined(_WIN32) || defined(__WIN32__) || defined(__WINDOWS__) )
	#pragma comment(lib, "opengl32.lib")
	#pragma comment(lib, "glu32.lib")
	#pragma comment(lib, "freeglut.lib")
#endif

#define M_PI			3.14159265358f
#define M_PI_2			1.57079632679489661923
#define RADTODEG		360 / (2 * M_PI)
#define DEGTORAD		M_PI / 180

#define UINT unsigned int

extern char g_Buffer[256];


#endif
