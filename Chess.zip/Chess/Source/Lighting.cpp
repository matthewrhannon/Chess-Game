//Matt H 12/3/2011

#include "Lighting.h"

//Static declarations
cLighting *cLighting::Instance = NULL;

cLighting::cLighting()
{
	ecLightPosition = NULL;
	lightStrength = NULL;
	spotDir = NULL;
	spotParams = NULL;

	actualNumLights = -1;
};

cLighting::~cLighting()
{
	if(ecLightPosition)
	{
		delete []ecLightPosition;
		ecLightPosition = NULL;
	}
			
	if(lightStrength)
	{
		delete []lightStrength;
		lightStrength = NULL;
	}
			
	if(spotDir)
	{
		delete []spotDir;
		spotDir = NULL;
	}

	if(spotParams)
	{
		delete []spotParams;
		spotParams = NULL;
	}
};

bool cLighting::QueryLightingVariables(int &_actualNumLights, vec4 *_ecLightPosition, vec4 *_lightStrength, vec3 *_spotDir, vec2 *_spotParams, vec4 &_globalAmbient)
{
	//Set number of lights and globalAmbient to return
	_actualNumLights = actualNumLights;
	
	_globalAmbient[0] = globalAmbient[0];
	_globalAmbient[1] = globalAmbient[1];
	_globalAmbient[2] = globalAmbient[2];
	_globalAmbient[3] = globalAmbient[3];

	for(int x = 0; x < actualNumLights; x++)
	{
		//Set light position
		_ecLightPosition[x][0] = ecLightPosition[x][0];
		_ecLightPosition[x][1] = ecLightPosition[x][1];
		_ecLightPosition[x][2] = ecLightPosition[x][2];
		_ecLightPosition[x][3] = ecLightPosition[x][3];

		//Set light strength
		_lightStrength[x][0] = lightStrength[x][0];
		_lightStrength[x][1] = lightStrength[x][1];
		_lightStrength[x][2] = lightStrength[x][2];
		_lightStrength[x][3] = lightStrength[x][3];

		//Set spot light dir and parms
		_spotDir[x][0] = spotDir[x][0];
		_spotDir[x][1] = spotDir[x][1];
		_spotDir[x][2] = spotDir[x][2];

		_spotParams[x][0] = spotParams[x][0];
		_spotParams[x][1] = spotParams[x][1];
	}



	return true;
}


bool cLighting::InitalizeLightingVariables()
{
	actualNumLights = 2;

	if(actualNumLights > MAX_NUM_LIGHTS)
	{
		cout << "ERROR: Too many lights!\n";
		return false;
	}

	//Allocate memory for lighting variables
	ecLightPosition = new vec4[actualNumLights];
	lightStrength = new vec4[actualNumLights];
	spotDir = new vec3[actualNumLights];
	spotParams = new vec2[actualNumLights];

	//Initalize variables to 0.0f
	for(int x = 0; x < actualNumLights; x++)
	{
		ecLightPosition[x][0] = ecLightPosition[x][1] = ecLightPosition[x][2] = ecLightPosition[x][3] = 0.0f;
		lightStrength[x][0] = lightStrength[x][1] = lightStrength[x][2] = lightStrength[x][3] = 0.0f;
			
		spotDir[x][0] = spotDir[x][1] = spotDir[x][2] = 0.0f;
		spotParams[x][0] = spotParams[x][1] = 0.0f;
	}
	
	//Set lighting variables
	globalAmbient[0] = 0.8f; globalAmbient[1] = 0.8f; globalAmbient[2] = 0.8f; globalAmbient[3] = 1.0f;

	//Set first light
	ecLightPosition[0][0] = 0.0f; ecLightPosition[0][1] = 1.0f; ecLightPosition[0][2] = 0.0f; ecLightPosition[0][3] = 0.0f; //Directional light
	lightStrength[0][0] = 0.9f; lightStrength[0][1] = 0.9f; lightStrength[0][2] = 0.9f; lightStrength[0][3] = 1.0f;
	
	//Set second light
	ecLightPosition[1][0] = 0.0f; ecLightPosition[1][1] = 0.0f; ecLightPosition[1][2] = 0.0f; ecLightPosition[1][3] = 1.0f; //Spot light
	lightStrength[1][0] = 0.8f; lightStrength[1][1] = 0.8f; lightStrength[1][2] = 0.8f; lightStrength[1][3] = 1.0f;
	
	spotDir[0][0] = 0.0f; spotDir[0][1] = 0.0f; spotDir[0][2] = 0.0f; 
	spotDir[1][0] = 0.0f; spotDir[1][1] = 0.0f; spotDir[1][2] = -1.0f; 

	spotParams[0][0] = 0.0f; spotParams[0][0] = 0.0f; 
	spotParams[1][0] = 10.0f; spotParams[1][0] = 25.0f; 
	
	/*
			10.0, 25.0 // ten degree field of view; exponent is 25
			180.0, 0.0 // point source, but not a spot light

			ecLightPosition[0][0] = 0.25f; ecLightPosition[0][1] = 0.5f; ecLightPosition[0][2] = 1.0f; ecLightPosition[0][3] = 0.0f; //Directional light
	lightStrength[0][0] = 0.7f; lightStrength[0][1] = 0.7f; lightStrength[0][2] = 0.7f; lightStrength[0][3] = 1.0f;
	*/
	
	
	return true;
}


