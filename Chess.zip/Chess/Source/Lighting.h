//Matt H 12/3/2011
//Lighting class

#ifndef __LIGHTING__
#define __LIGHTING__

#include "Externals.h"
#include "ModelView.h"


/*
	//Set sun directly overhead, want each terrain triangle stip to have 3 normals
	lightPosition[0] = 0; lightPosition[1] = 1; lightPosition[2] = 0; lightPosition[3] = 1;
	lightStrength[0] = 0.7f; lightStrength[1] = 0.7f; lightStrength[2] = 0.7f; lightStrength[3] = 1;
	ambient[0] = 0.9f; ambient[1] = 0.9f; ambient[2] = 0.9f; ambient[3] = 1; 
	
	//Set material properties
	kd[0] = 0.5f; kd[1] = 0.5f; kd[2] = 0.5f; kd[3] = 0.5f;
	
	//Note: I only implemented the basic lighting model therefore specular and factor m do not work. Only diffuse material properties effect the scene.
	ks[0] = 0.5f; ks[1] = 0.5f; ks[2] = 0.5f; ks[3] = 0.5f;
	m = 1;
	

	*/

#define MAX_NUM_LIGHTS 3

class cLighting
{
	public:
		cLighting();
		~cLighting();

		//Singleton
		static cLighting *Get()
		{
			if(!Instance)
				Instance = new cLighting;
			return Instance;
		};

		bool InitalizeLightingVariables();

		//Returns globalAmbient as return value
		bool QueryLightingVariables(int &_actualNumLights, vec4 *_ecLightPosition, vec4 *_lightStrength, vec3 *_spotDir, vec2 *_spotParams, vec4 &_globalAmbient);

	private:
		static cLighting *Instance;

		//Global scen lighting variables
		int actualNumLights;

		vec4 *ecLightPosition;
		vec4 *lightStrength;
		vec4 globalAmbient;
	
		vec3 *spotDir;
		vec2 *spotParams;
};









#endif