// ModelView.c++ - an Abstract Base Class for a combined Model and View for OpenGL
/* Matthew Hannon 2217853 skinnym2@ku.edu */
#include "ModelView.h"
#include "Controller.h"

ModelView::ModelView()
{
	PieceOffset[0] = PieceOffset[1] = PieceOffset[2] = 0;
	PieceOffset[3] = 1; //Alive

	bAddtoMatrix = true;
}

ModelView::~ModelView()
{
}

void ModelView::computeScaleTrans(float* scaleTrans) // assumed to be 4 positions long
{
	cout << "Compute scaletrans!\n";
	float xyzLimits[6];
	Controller::getOverallWCBoundingBox(xyzLimits);

	// **************This is where your aspect ratio preservation logic needs to be implemented **********
	
	float AspectRatio = float(xyzLimits[3] - xyzLimits[2])/float(xyzLimits[1] - xyzLimits[0]);
	if(AspectRatio > Controller::VP_AspectRatio)
	{
		float NewWidth = float(xyzLimits[3] - xyzLimits[2])/Controller::VP_AspectRatio;
		
		float MidPoint = float(xyzLimits[1] - xyzLimits[0])/2;
		float a = MidPoint - NewWidth/2;
		float b = MidPoint + NewWidth/2;


		// Map the overall limits to the -1..+1 range expected by the OpenGL engine:
		linearMap(a, b, -1.0, 1.0, scaleTrans);      // COMPUTE: sx, tx
		linearMap(xyzLimits[2], xyzLimits[3], -1.0, 1.0, &scaleTrans[2]);  // COMPUTE: sy, ty
	}
	else
	{
		float NewHeight = float(xyzLimits[1] - xyzLimits[0])*Controller::VP_AspectRatio;
		
		float MidPoint = float(xyzLimits[3] - xyzLimits[2])/2;
		float a = MidPoint - NewHeight/2;
		float b = MidPoint + NewHeight/2;

		// Map the overall limits to the -1..+1 range expected by the OpenGL engine:
		linearMap(xyzLimits[0], xyzLimits[1], -1.0, 1.0, scaleTrans);      // COMPUTE: sx, tx
		linearMap(a, b, -1.0, 1.0, &scaleTrans[2]);  // COMPUTE: sy, ty
	}
	
	linearMap(xyzLimits[0], xyzLimits[1], -1.0, 1.0, scaleTrans);      // COMPUTE: sx, tx
	linearMap(xyzLimits[2], xyzLimits[3], -1.0, 1.0, &scaleTrans[2]);  // COMPUTE: sy, ty
	linearMap(xyzLimits[4], xyzLimits[5], -1.0, 1.0, &scaleTrans[4]);  // COMPUTE: sz, tz
}

void ModelView::linearMap(float fromMin, float fromMax, float toMin, float toMax, float* scaleTrans)
		// CLASS METHOD
{
	scaleTrans[0] = (toMax - toMin) / (fromMax - fromMin);
	scaleTrans[1] = toMin - scaleTrans[0]*fromMin;
}

bool ModelView::UpdateLocalMatrices()
{
	//Invert to undo what it does this time
	if(bAddtoMatrix)
		cCamera::Get()->addToGlobalPan(PieceOffset[0], PieceOffset[1], PieceOffset[2]);
	else
		cCamera::Get()->addToGlobalPan((-1)*PieceOffset[0], (-1)*PieceOffset[1], (-1)*PieceOffset[2]);
		
/*	static vec3 old, new1;
	if(bAddtoMatrix)
		cCamera::Get()->setToGlobalPan(old, PieceOffset[0], PieceOffset[1], PieceOffset[2]);
	else
		cCamera::Get()->setToGlobalPan(new1, old[0], old[1], old[2]);
*/
	bAddtoMatrix = !bAddtoMatrix;
	return bAddtoMatrix;
}