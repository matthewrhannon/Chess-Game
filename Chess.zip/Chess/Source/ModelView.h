// ModelView.h - an Abstract Base Class for a combined Model and View for OpenGL
///* Matthew Hannon 2217853 skinnym2@ku.edu */

// This version illustrates a very minimal set of base class functions for a set
// of concrete subclasses that can support a simple window-viewport map:
// 1. The pure virtual method "getWCBoundingBox" is designed for a Controller to ask the
//    subclass what its extent is so that the Controller can keep track of an overall
//    bounding box that encloses the entire scene.
// 2. The protected class method "computeScaleTrans" is designed to be used by
//    ModelView subclasses to fetch the scale and translation terms in x and y that
//    implement a basic window-viewport transformation. The implementation first queries
//    the Controller for its overall bounding box. That box is used as the world coordinate
//    window, and the scale/translation terms map points inside that window into the
//    -1 <= [x,y] <= +1 logical viewport range expected by OpenGL. Subclasses will generally
//    simply pass these scale and translation terms to their vertex shaders.

#ifndef MODELVIEW_H
#define MODELVIEW_H

#include "Externals.h"
#include "Camera.h"

typedef GLfloat vec2[2]; // or use Angel's definitions
typedef GLfloat vec3[3]; // or use Angel's definitions
typedef GLfloat vec4[4]; // or use Angel's definitions

class ModelView
{
public:
	ModelView();
	virtual ~ModelView();

	virtual void getWCBoundingBox(float* xyzLimits) const = 0; // { xmin, xmax, ymin, ymax, zmin, zmax }
	virtual void render() = 0;
	
	bool bAddtoMatrix; //false for subtract
	virtual bool UpdateLocalMatrices();


	vec4 PieceOffset; //if vec(4) is 0 then dead
	vec3 PieceOrigin;
	char strPieceName[32];
		
	int iColor;
	int GridX, GridY;
protected:
	static void computeScaleTrans(float* scaleTrans);
private:
	static void linearMap(float fromMin, float fromMax, float toMin, float toMax, float* scaleTrans);
};

#endif
