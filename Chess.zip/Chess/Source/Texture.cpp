//Matt H 12/3/11

#include "Texture.h"

int cTexture::LoadTexture(char *strTexturePath)
{
	//Make sure string is valid
	if(!strTexturePath)
	{
		cout << "ERROR in Texture::LoadTexture: Invalid strTexturePath\n";
		return -1;
	}

	strcpy(strFile, strTexturePath);

	//Now load in texture bmp along with its details that are required by OpenGL
	if(!LoadFile_BMP(strTexturePath))
	{
		cout << "ERROR in Texture::LoadTexture: Couldnt load the bmp file\n";
		return -1;
	}

	//Now pass image data to OpenGL

	if (Data == NULL)
		return -1;

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glGenTextures(1, &ID);
	glBindTexture(GL_TEXTURE_2D, ID);

	float white[] = { 1.0, 1.0, 1.0, 1.0 };
	glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, white);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);

	GLint level = 0;
	int pw = SizeX, ph = SizeY;
	GLenum iFormat = GL_RGB;
	GLenum format = GL_RGB;
	GLenum type =  GL_UNSIGNED_BYTE;
	const GLint border = 0; // must be zero (only present for backwards compatibility)
	const GLvoid* pixelData = (GLvoid *)Data;
	glTexImage2D(GL_TEXTURE_2D, level, iFormat, pw, ph, border, format, type, pixelData);

	bValid = true;
	return ID;
}


// quick and dirty bitmap loader...for 24 bit bitmaps with 1 plane only.  
// See http://www.dcs.ed.ac.uk/~mxr/gfx/2d/BMP.txt for more info.
bool cTexture::LoadFile_BMP(char *strTexturePath)
{
	FILE *file;
	unsigned long size;                 // size of the image in bytes.
	unsigned long i;                    // standard counter.
	unsigned short int planes;          // number of planes in image (must be 1) 
	unsigned short int bpp;             // number of bits per pixel (must be 24)
	char temp;                          // temporary color storage for bgr-rgb conversion.

	//printf("Attempting to load BMP file: %s\n", strTexturePath);

	// make sure the file is there.
	if ((file = fopen(strTexturePath, "rb"))==NULL)
	{
		cout<< "File Not Found : " << strTexturePath << endl;
		return 0;
	}

	// seek through the bmp header, up to the width/height:
	fseek(file, 18, SEEK_CUR);

	// read the width
	if ((i = fread(&SizeX, 4, 1, file)) != 1) {
		cout << "Error reading width from " << strTexturePath << endl;
		return false;
	}
	
	//printf("Width of %s: %lu\n", strTexturePath, SizeX);

	// read the height 
	if ((i = fread(&SizeY, 4, 1, file)) != 1) {
		cout << "Error reading width from " << strTexturePath << endl;
		return false;
	}

	//printf("Height of %s: %lu\n", strTexturePath, SizeY);

	// calculate the size (assuming 24 bits or 3 bytes per pixel).
	size = SizeX * SizeY * 3;
	DataSize = size;

	// read the planes
	if ((fread(&planes, 2, 1, file)) != 1) 
	{
		printf("Error reading planes from %s.\n", strTexturePath);
		return 0;
	}
	
	if (planes != 1) 
	{
		printf("Planes from %s is not 1: %u\n", strTexturePath, planes);
		return 0;
	}

	// read the bpp
	if ((i = fread(&bpp, 2, 1, file)) != 1) 
	{
		printf("Error reading bpp from %s.\n", strTexturePath);
		return 0;
	}

	if (bpp != 24)
	{
		printf("Bpp from %s is not 24: %u\n", strTexturePath, bpp);
		return 0;
	}

	// seek past the rest of the bitmap header.
	fseek(file, 24, SEEK_CUR);

	// read the data. 
	Data = (char *) malloc(size);
	if (Data == NULL)
	{
		printf("Error allocating memory for color-corrected image data");
		return 0;	
	}

	if ((i = fread(Data, size, 1, file)) != 1) 
	{
		printf("Error reading image data from %s.\n", strTexturePath);
		return 0;
	}

	for (i=0;i<size;i+=3) 
	{ 
		// reverse all of the colors. (bgr -> rgb)
		temp = Data[i];
		Data[i] = Data[i+2];
		Data[i+2] = temp;
	}

	// we're done.
	return true;
}

void cTexture::DestroyObject()
{
	if(ID > 0)
		glDeleteTextures(1, &ID);
}

void cTexture::UseTexture()
{
	if(ID > 0)
		glBindTexture(GL_TEXTURE_2D, ID);
}