//Matt H 12/3/11
//Texture class

#ifndef __TEXTURE__
#define __TEXTURE__

#include "Externals.h"

class cTexture
{	
	public:
		cTexture()
		{
			SizeX = 0; 
			SizeY = 0;

			strcpy(strFile, "ERROR: No Texture Path");
			ID = -1;

			Data = NULL;
			DataSize = -1;

			bValid = false;
		};

		~cTexture()
		{
			//Delete texture object
			DestroyObject();

			if(Data != NULL)
			{
				free(Data);
				Data = NULL;
			}
		};

		//Load texture function
		bool LoadFile_BMP(char *strTexturePath);
		int LoadTexture(char *strTexturePath);

		//Use texture functions
		void DestroyObject();
		void UseTexture();

		bool IsValid() 
		{
			return bValid;
		};

	private:
		//Texture variables
		int SizeX; 
		int SizeY;

		char strFile[128];
		unsigned int ID;

		char *Data;
		int DataSize;

		//boolean to state if texture is valid
		bool bValid;
};


#endif


