//Scene
/* Matthew Hannon 2217853 skinnym2@ku.edu */


#include <iostream>
#include <stdio.h>
//NOTE... 
#include <windows.h>

#include "Main.h"
#include "Log.h"
#include "Game.h"

void __cdecl ExitFunction()
{
	//Deinitalize 
	cChessGame::Get()->UninitalizeGame();
	CLog::Get()->UnLoad();
}














#include "Controller.h"
#include "Board_Renderer.h"

char g_Buffer[256];

int main(int argc, char* argv[])
{
	//Chessbase stuff
		
	cout << "Initalizing ChessBase - Matt Hannon\n\n";
	//will i finish this?fjfiojfjii I hope so.. progress has been made, but many stages and current issues to still face...
	atexit(ExitFunction);
	
	CLog::Get()->Load();

	//Start chess game
	if(cChessGame::Get()->InitalizeGame() != 1)
	{
		CLog::Get()->WriteError("Main: Failed to initialize chess game");
		return 0;
	}

	//Start a match 
	//Note: 0x00 now as place holder for potential later features
	if(cChessGame::Get()->BeginMatch(0x00) != 1)
	{
		CLog::Get()->WriteError("Main: Failed to begin match");
		return 0;
	}

	//Now initalize ChessRenderer
	// One-time initialization of the glut
	glutInit(&argc, argv);

	//Define the controller
	Controller c(argv[0]);

	vec3 Origin = {0, 0};

	cBoard_Renderer Board_Object(Origin);
	if(!Board_Object.InitalizeMap(&c))
	{
		cout << "ERROR: Unable to initalize the map!\n";
		return 0;
	}
	
	// Hand off control to the glut event handling loop:
	glutMainLoop();

	return 0;
}



